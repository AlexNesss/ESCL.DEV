-- phpMyAdmin SQL Dump
-- version 3.5.8.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Ноя 05 2014 г., 15:31
-- Версия сервера: 5.1.69
-- Версия PHP: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `ie_database_modificate`
--

-- --------------------------------------------------------

--
-- Структура таблицы `access`
--

CREATE TABLE IF NOT EXISTS `access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `desc` text NOT NULL,
  `type` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `password` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `date_create` int(11) NOT NULL,
  `day_counts` int(11) NOT NULL,
  `date_end` int(11) NOT NULL,
  `server` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `option` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `comment` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Структура таблицы `add_bans`
--

CREATE TABLE IF NOT EXISTS `add_bans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `s_id` int(11) NOT NULL,
  `nick` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `server` int(1) NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `docs` text COLLATE utf8_unicode_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` int(1) NOT NULL,
  `read` int(1) NOT NULL,
  `comment` varchar(2100) COLLATE utf8_unicode_ci NOT NULL,
  `admin_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `amx_admins_servers`
--

CREATE TABLE IF NOT EXISTS `amx_admins_servers` (
  `admin_id` int(11) NOT NULL DEFAULT '0',
  `server_id` int(11) NOT NULL DEFAULT '0',
  `custom_flags` varchar(32) NOT NULL,
  `use_static_bantime` enum('yes','no') NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`admin_id`,`server_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `amx_amxadmins`
--

CREATE TABLE IF NOT EXISTS `amx_amxadmins` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `access` varchar(32) DEFAULT NULL,
  `flags` varchar(32) DEFAULT NULL,
  `steamid` varchar(32) DEFAULT NULL,
  `nickname` varchar(32) DEFAULT NULL,
  `icq` int(9) DEFAULT NULL,
  `ashow` int(11) DEFAULT NULL,
  `created` int(11) DEFAULT NULL,
  `expired` int(11) DEFAULT NULL,
  `days` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `steamid` (`steamid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `amx_bans`
--

CREATE TABLE IF NOT EXISTS `amx_bans` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `player_ip` varchar(32) DEFAULT NULL,
  `player_id` varchar(35) DEFAULT NULL,
  `player_nick` varchar(100) DEFAULT 'Unknown',
  `admin_ip` varchar(32) DEFAULT NULL,
  `admin_id` varchar(35) DEFAULT 'Unknown',
  `admin_nick` varchar(100) DEFAULT 'Unknown',
  `ban_type` varchar(10) DEFAULT 'S',
  `ban_reason` varchar(100) DEFAULT NULL,
  `cs_ban_reason` varchar(100) DEFAULT NULL,
  `ban_created` int(11) DEFAULT NULL,
  `ban_length` int(11) DEFAULT NULL,
  `server_ip` varchar(32) DEFAULT NULL,
  `server_name` varchar(100) DEFAULT 'Unknown',
  `ban_kicks` int(11) NOT NULL DEFAULT '0',
  `expired` int(1) NOT NULL DEFAULT '0',
  `imported` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  KEY `player_id` (`player_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `amx_bans_edit`
--

CREATE TABLE IF NOT EXISTS `amx_bans_edit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid` int(11) NOT NULL,
  `edit_time` int(11) NOT NULL,
  `admin_nick` varchar(32) NOT NULL DEFAULT 'unknown',
  `edit_reason` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `amx_bbcode`
--

CREATE TABLE IF NOT EXISTS `amx_bbcode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `open_tag` varchar(32) DEFAULT NULL,
  `close_tag` varchar(32) DEFAULT NULL,
  `url` varchar(32) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `amx_bbcode`
--

INSERT INTO `amx_bbcode` (`id`, `open_tag`, `close_tag`, `url`, `name`) VALUES
(1, '[b]', '[/b]', 'bold.png', 'bold'),
(2, '[i]', '[/i]', 'italic.png', 'italic'),
(3, '[u]', '[/u]', 'underline.png', 'underline'),
(4, '[center]', '[/center]', 'center.png', 'center');

-- --------------------------------------------------------

--
-- Структура таблицы `amx_comments`
--

CREATE TABLE IF NOT EXISTS `amx_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(35) DEFAULT NULL,
  `comment` text,
  `email` varchar(100) DEFAULT NULL,
  `addr` varchar(32) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `bid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `amx_files`
--

CREATE TABLE IF NOT EXISTS `amx_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `upload_time` int(11) DEFAULT NULL,
  `down_count` int(11) DEFAULT NULL,
  `bid` int(11) DEFAULT NULL,
  `demo_file` varchar(100) DEFAULT NULL,
  `demo_real` varchar(100) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `comment` text,
  `name` varchar(64) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `addr` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `amx_flagged`
--

CREATE TABLE IF NOT EXISTS `amx_flagged` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `player_ip` varchar(32) DEFAULT NULL,
  `player_id` varchar(35) DEFAULT NULL,
  `player_nick` varchar(100) DEFAULT 'Unknown',
  `admin_ip` varchar(32) DEFAULT NULL,
  `admin_id` varchar(35) DEFAULT NULL,
  `admin_nick` varchar(100) DEFAULT 'Unknown',
  `reason` varchar(100) DEFAULT NULL,
  `created` int(11) DEFAULT NULL,
  `length` int(11) DEFAULT NULL,
  `server_ip` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`fid`),
  KEY `player_id` (`player_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Структура таблицы `amx_levels`
--

CREATE TABLE IF NOT EXISTS `amx_levels` (
  `level` int(12) NOT NULL DEFAULT '0',
  `bans_add` enum('yes','no') DEFAULT 'no',
  `bans_edit` enum('yes','no','own') DEFAULT 'no',
  `bans_delete` enum('yes','no','own') DEFAULT 'no',
  `bans_unban` enum('yes','no','own') DEFAULT 'no',
  `bans_import` enum('yes','no') DEFAULT 'no',
  `bans_export` enum('yes','no') DEFAULT 'no',
  `amxadmins_view` enum('yes','no') DEFAULT 'no',
  `amxadmins_edit` enum('yes','no') DEFAULT 'no',
  `webadmins_view` enum('yes','no') DEFAULT 'no',
  `webadmins_edit` enum('yes','no') DEFAULT 'no',
  `websettings_view` enum('yes','no') DEFAULT 'no',
  `websettings_edit` enum('yes','no') DEFAULT 'no',
  `permissions_edit` enum('yes','no') DEFAULT 'no',
  `prune_db` enum('yes','no') DEFAULT 'no',
  `servers_edit` enum('yes','no') DEFAULT 'no',
  `ip_view` enum('yes','no') DEFAULT 'no',
  PRIMARY KEY (`level`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `amx_levels`
--

INSERT INTO `amx_levels` (`level`, `bans_add`, `bans_edit`, `bans_delete`, `bans_unban`, `bans_import`, `bans_export`, `amxadmins_view`, `amxadmins_edit`, `webadmins_view`, `webadmins_edit`, `websettings_view`, `websettings_edit`, `permissions_edit`, `prune_db`, `servers_edit`, `ip_view`) VALUES
(1, 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes'),
(2, 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', 'no', 'no', 'no', 'no', 'no', 'no', 'yes');

-- --------------------------------------------------------

--
-- Структура таблицы `amx_logs`
--

CREATE TABLE IF NOT EXISTS `amx_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) DEFAULT NULL,
  `ip` varchar(32) DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  `action` varchar(64) DEFAULT NULL,
  `remarks` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `amx_modulconfig`
--

CREATE TABLE IF NOT EXISTS `amx_modulconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menuname` varchar(32) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `index` varchar(32) DEFAULT NULL,
  `activ` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `amx_modulconfig`
--

INSERT INTO `amx_modulconfig` (`id`, `menuname`, `name`, `index`, `activ`) VALUES
(1, '_MENUIMPORTEXPORT', 'iexport', '', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `amx_reasons`
--

CREATE TABLE IF NOT EXISTS `amx_reasons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reason` varchar(100) DEFAULT NULL,
  `static_bantime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `amx_reasons_set`
--

CREATE TABLE IF NOT EXISTS `amx_reasons_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setname` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `amx_reasons_to_set`
--

CREATE TABLE IF NOT EXISTS `amx_reasons_to_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setid` int(11) NOT NULL,
  `reasonid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `amx_serverinfo`
--

CREATE TABLE IF NOT EXISTS `amx_serverinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) DEFAULT NULL,
  `hostname` varchar(100) DEFAULT 'Unknown',
  `address` varchar(100) DEFAULT NULL,
  `gametype` varchar(32) DEFAULT NULL,
  `rcon` varchar(32) DEFAULT NULL,
  `amxban_version` varchar(32) DEFAULT NULL,
  `amxban_motd` varchar(250) DEFAULT NULL,
  `motd_delay` int(10) DEFAULT '10',
  `amxban_menu` int(10) NOT NULL DEFAULT '1',
  `reasons` int(10) DEFAULT NULL,
  `timezone_fixx` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `amx_smilies`
--

CREATE TABLE IF NOT EXISTS `amx_smilies` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `code` varchar(32) DEFAULT NULL,
  `url` varchar(32) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `amx_smilies`
--

INSERT INTO `amx_smilies` (`id`, `code`, `url`, `name`) VALUES
(1, ':D', 'big_smile.png', 'Big Grin'),
(2, '8)', 'cool.png', 'Cool'),
(3, ':/', 'hmm.png', 'Hmm'),
(4, 'lol', 'lol.png', 'lol'),
(5, ':(', 'mad.png', 'Mad'),
(6, ':|', 'neutral.png', 'Neutral'),
(7, ':roll:', 'roll.png', 'RollEyes'),
(8, ':*(', 'sad.png', 'Sad'),
(9, ':)', 'smile.png', 'Smilie'),
(10, ':P', 'tongue.png', 'Tongue'),
(11, ';)', 'wink.png', 'Wink'),
(12, ':O', 'yikes.png', 'Yikes');

-- --------------------------------------------------------

--
-- Структура таблицы `amx_usermenu`
--

CREATE TABLE IF NOT EXISTS `amx_usermenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pos` int(11) DEFAULT NULL,
  `activ` tinyint(1) NOT NULL DEFAULT '1',
  `lang_key` varchar(64) DEFAULT NULL,
  `url` varchar(64) DEFAULT NULL,
  `lang_key2` varchar(64) DEFAULT NULL,
  `url2` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `amx_usermenu`
--

INSERT INTO `amx_usermenu` (`id`, `pos`, `activ`, `lang_key`, `url`, `lang_key2`, `url2`) VALUES
(1, 1, 1, '_HOME', '/site/index', '_HOME', '/site/index'),
(2, 2, 1, '_BANLIST', '/bans/index', '_BANLIST', '/bans/index'),
(3, 3, 1, '_ADMLIST', '/amxadmins/index', '_ADMLIST', '/amxadmins/index'),
(5, 5, 1, '_SERVER', '/serverinfo/index', '_SERVER', '/serverinfo/index');

-- --------------------------------------------------------

--
-- Структура таблицы `amx_webadmins`
--

CREATE TABLE IF NOT EXISTS `amx_webadmins` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `level` int(11) DEFAULT '99',
  `logcode` varchar(64) DEFAULT NULL,
  `email` varchar(64) DEFAULT NULL,
  `last_action` int(11) DEFAULT NULL,
  `try` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`,`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `amx_webconfig`
--

CREATE TABLE IF NOT EXISTS `amx_webconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cookie` varchar(32) DEFAULT NULL,
  `bans_per_page` int(11) DEFAULT NULL,
  `design` varchar(32) DEFAULT NULL,
  `banner` varchar(64) DEFAULT NULL,
  `banner_url` varchar(128) NOT NULL,
  `default_lang` varchar(32) DEFAULT NULL,
  `start_page` varchar(64) DEFAULT NULL,
  `show_comment_count` int(1) DEFAULT '1',
  `show_demo_count` int(1) DEFAULT '1',
  `show_kick_count` int(1) DEFAULT '1',
  `demo_all` int(1) NOT NULL DEFAULT '0',
  `comment_all` int(1) NOT NULL DEFAULT '0',
  `use_capture` int(1) DEFAULT '1',
  `max_file_size` int(11) DEFAULT '2',
  `file_type` varchar(64) DEFAULT 'dem,zip,rar,jpg,gif',
  `auto_prune` int(1) NOT NULL DEFAULT '0',
  `max_offences` smallint(6) NOT NULL DEFAULT '10',
  `max_offences_reason` varchar(128) NOT NULL DEFAULT 'max offences reached',
  `use_demo` int(1) DEFAULT '1',
  `use_comment` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `amx_webconfig`
--

INSERT INTO `amx_webconfig` (`id`, `cookie`, `bans_per_page`, `design`, `banner`, `banner_url`, `default_lang`, `start_page`, `show_comment_count`, `show_demo_count`, `show_kick_count`, `demo_all`, `comment_all`, `use_capture`, `max_file_size`, `file_type`, `auto_prune`, `max_offences`, `max_offences_reason`, `use_demo`, `use_comment`) VALUES
(1, 'Забанен системой', 50, 'default', 'amxbans.png', 'http://www.escl-professional.ru', 'russian', '/site/index', 0, 0, 1, 1, 1, 1, 1024, 'dem,zip,rar,jpg,gif,png,bmp', 0, 5, 'max offences reached', 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `bans_com`
--

CREATE TABLE IF NOT EXISTS `bans_com` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bans_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `text` varchar(1100) COLLATE utf8_unicode_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `buy_order`
--

CREATE TABLE IF NOT EXISTS `buy_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number_order` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `server` varchar(20) NOT NULL,
  `value` varchar(50) NOT NULL,
  `option` varchar(128) NOT NULL,
  `srok` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `prolong` int(11) NOT NULL,
  `cost` double NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dialogs`
--

CREATE TABLE IF NOT EXISTS `dialogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from` int(11) NOT NULL,
  `invites` text COLLATE utf8_unicode_ci NOT NULL,
  `lastmsg` int(11) NOT NULL,
  `deleted` text COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` text COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `err_auth`
--

CREATE TABLE IF NOT EXISTS `err_auth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(100) NOT NULL,
  `count` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `forums_cat`
--

CREATE TABLE IF NOT EXISTS `forums_cat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `forums_cat`
--

INSERT INTO `forums_cat` (`id`, `name`) VALUES
(1, 'Основной раздел'),
(2, 'Игровые серверы');

-- --------------------------------------------------------

--
-- Структура таблицы `forums_for`
--

CREATE TABLE IF NOT EXISTS `forums_for` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` int(11) NOT NULL,
  `name` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `access` int(11) NOT NULL,
  `icon` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `forums_for`
--

INSERT INTO `forums_for` (`id`, `cat`, `name`, `access`, `icon`) VALUES
(1, 1, 'Общение', 0, 'smile.png'),
(2, 2, 'Название сервера', 0, 'cs.png'),
(10, 1, 'Для админов', 4, 'cs.png');

-- --------------------------------------------------------

--
-- Структура таблицы `forums_messages`
--

CREATE TABLE IF NOT EXISTS `forums_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `thread` int(11) NOT NULL,
  `text` varchar(10000) COLLATE utf8_unicode_ci NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  `ip` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `likes` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `forums_threads`
--

CREATE TABLE IF NOT EXISTS `forums_threads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `for` int(11) NOT NULL,
  `title` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(1) NOT NULL,
  `view` int(11) NOT NULL,
  `fpost` int(11) NOT NULL,
  `closed` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `friends`
--

CREATE TABLE IF NOT EXISTS `friends` (
  `id` int(11) NOT NULL,
  `friends` text NOT NULL,
  `invites` text NOT NULL,
  `toinvites` text NOT NULL,
  `blocked` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `group_id` int(2) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(7) NOT NULL,
  `class` varchar(40) NOT NULL,
  `access` text NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`group_id`, `group_name`, `color`, `class`, `access`) VALUES
(1, 'Забаненные', 'pink', 'group_ban', 'chat,forum,wall'),
(2, 'Пользователи', '', 'group_user', 'chat,chatmsg,newsmsg,forum,wall,wallmsg,,im,immsg'),
(3, 'Проверенные', '#6b8e23', 'group_verify', 'chat,chatmsg,newsmsg,forum,wall,wallmsg,im,immsg'),
(4, 'Администраторы', 'red', 'group_admin', 'chat,chatmsg,newsmsg,newsmsgdel,forum,wall,wallmsg,im,imdel,immsg'),
(5, 'Администратор сервера', '#3300ff', 'group_admin', 'chat,chatmsg,newsmsg,forum,wall,wallmsg,im,immsg'),
(6, 'Стример проекта', '#cc66cc', 'group_user', 'chat,chatmsg,newsmsg,forum,wall,wallmsg,im,immsg'),
(7, 'Модераторы', '#3366ff', 'group_verify', 'chat,chatmsg,newsmsg,newsmsgdel,forum,wall,wallmsg,im,immsg');

-- --------------------------------------------------------

--
-- Структура таблицы `log_auth`
--

CREATE TABLE IF NOT EXISTS `log_auth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `hash` varchar(100) NOT NULL,
  `browser` varchar(100) NOT NULL,
  `os` varchar(100) NOT NULL,
  `ip` varchar(100) NOT NULL,
  `lastseen` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `text` varchar(1000) CHARACTER SET utf8 DEFAULT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date` int(11) NOT NULL,
  `text` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `news_com`
--

CREATE TABLE IF NOT EXISTS `news_com` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `news_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `online`
--

CREATE TABLE IF NOT EXISTS `online` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `unix` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `id_user` int(10) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=34 ;

--
-- Дамп данных таблицы `online`
--

INSERT INTO `online` (`id`, `ip`, `unix`, `id_user`) VALUES
(33, '95.106.49.13', '1394211411', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `pm`
--

CREATE TABLE IF NOT EXISTS `pm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dialog` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `text` varchar(1100) COLLATE utf8_unicode_ci NOT NULL,
  `status` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `recovery`
--

CREATE TABLE IF NOT EXISTS `recovery` (
  `id` int(11) NOT NULL,
  `hash` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `servers`
--

CREATE TABLE IF NOT EXISTS `servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `hostname` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `port` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `admins` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `map` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `players` int(11) NOT NULL,
  `maxplayers` int(11) NOT NULL,
  `playerslist` text COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `pay` int(11) NOT NULL DEFAULT '0',
  `getbans` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `skills`
--

CREATE TABLE IF NOT EXISTS `skills` (
  `skill_id` int(2) NOT NULL AUTO_INCREMENT,
  `skill_name` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(7) NOT NULL,
  `class` varchar(40) NOT NULL,
  PRIMARY KEY (`skill_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `skills`
--

INSERT INTO `skills` (`skill_id`, `skill_name`, `color`, `class`) VALUES
(1, 'Low skill [LS]', 'grey', 'skill_low'),
(2, 'Medium skill [MS]', 'yellow', 'skill_medium'),
(3, 'Amateur skill [AS]', 'green', 'skill_amateur'),
(4, 'High skill [HS]', 'red', 'skill_high'),
(5, 'Semi PRO [SS]', 'blue', 'skill_semi'),
(6, 'PRO skill [PS]', 'black', 'skill_pro'),
(7, 'Elite skill [ES]', 'black', 'skill_elite');

-- --------------------------------------------------------

--
-- Структура таблицы `smiles`
--

CREATE TABLE IF NOT EXISTS `smiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `img` text NOT NULL,
  `access` varchar(40) NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Дамп данных таблицы `smiles`
--

INSERT INTO `smiles` (`id`, `name`, `img`, `access`, `type`) VALUES
(1, ':D', 'biggrin.gif', '0,1,2,3,4', 1),
(2, ':)', 'smile.gif', '0,1,2,3,4', 1),
(3, ':(', 'bad.gif', '0,1,2,3,4', 1),
(4, ':o0', 'blink.gif', '0,1,2,3,4', 1),
(5, ':P', 'tongue.gif', '0,1,2,3,4', 1),
(6, ':nea', 'nea.gif', '0,1,2,3,4', 1),
(7, ':pardon', 'pardon.gif', '0,1,2,3,4', 1),
(8, ':oboje', 'scare3.gif', '0,1,2,3,4', 1),
(9, ':mat', 'mad.gif', '0,1,2,3,4', 1),
(10, ':shout', 'shout.gif', '0,1,2,3,4', 1),
(11, ':fool', 'fool.gif', '0,1,2,3,4', 1),
(12, ':kulak', 'kulak.gif', '0,1,2,3,4', 1),
(13, ':ilove', 'ilove.png', '0,1,2,3,4', 0),
(14, ':drink', 'drinks.gif', '0,1,2,3,4', 1),
(15, ':rolf', 'rofl.gif', '0,1,2,3,4', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `stats`
--

CREATE TABLE IF NOT EXISTS `stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_id` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `map` varchar(50) NOT NULL,
  `players` int(11) NOT NULL,
  `maxplayers` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `stats_players`
--

CREATE TABLE IF NOT EXISTS `stats_players` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `frags` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `server` int(11) NOT NULL,
  `fseen` int(11) NOT NULL,
  `lseen` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rank` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tarifs`
--

CREATE TABLE IF NOT EXISTS `tarifs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `server_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` varchar(300) NOT NULL,
  `flags` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) CHARACTER SET latin1 NOT NULL,
  `email` varchar(30) CHARACTER SET latin1 NOT NULL,
  `name` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `nick` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `group_id` int(11) NOT NULL,
  `skill_id` int(11) NOT NULL,
  `date_reg` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `hash` text COLLATE utf8_unicode_ci NOT NULL,
  `vk` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `signature` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `steamid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `access` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `wall`
--

CREATE TABLE IF NOT EXISTS `wall` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(60) NOT NULL,
  `content` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(40) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `wall_likes`
--

CREATE TABLE IF NOT EXISTS `wall_likes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wall_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
