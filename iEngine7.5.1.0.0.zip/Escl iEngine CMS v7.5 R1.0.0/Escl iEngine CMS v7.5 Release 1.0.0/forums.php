<?php
session_start();
define ('BYESCL', true);
require_once "core/maincore.php";
$page = 'forum';
# Преобразуем входящие $_GET параметры в число
if (!empty($_GET['for'])){
    $escaped_for = intval($_GET['for']);
}
if (!empty($_GET['cat'])){
    $escaped_category = intval($_GET['cat']);
}
$nav[] = array('name' => 'Форумы', 'url' => '/forums');
# Создание новой темы
if ($userinfo['group'] > 0 AND !empty($_POST['name_forum']) AND !empty($_POST['input_text']) AND !empty($_GET['for']) AND !empty($_GET['act']) AND $_GET['act'] == 'new') {
	# Фильтруем $_POST данные
	$nameforum = mysql_real_escape_string($eng->stripinput($_POST['name_forum']));
	$textforum = mysql_real_escape_string($eng->stripinput($_POST['input_text']));
	if(!empty($textforum)) {
		# Оборачиваем IP пользователя в переменную
		$ip = USER_IP;
		# Добавляем тему
		$sql = mysql_query("INSERT INTO `forums_threads` (`id`, `for`, `title`, `status`, `view`) VALUES (NULL, '{$escaped_for}', '{$nameforum}', '1', '0')");
		# Записываем номер созданной темы
		$thread_insert_id = mysql_insert_id();
		# Добавляем сообщение
		mysql_query("INSERT INTO `forums_messages` (`id`, `thread`, `text`, `time`, `user_id`, `ip`) VALUES (NULL, '{$thread_insert_id}', '{$textforum}', CURRENT_TIMESTAMP, '{$userinfo['id']}', '{$ip}')");
		# Записываем номер первого сообщения
		$fpost_insert_id = mysql_insert_id();
		# Добавляем номер первого сообщения
		mysql_query("UPDATE  `forums_threads` SET  `fpost` =  {$fpost_insert_id} WHERE  `forums_threads`.`id` = {$thread_insert_id}");
		# Отправляем на страницу темы
		header("Location: ".BASEDIR."topic_".$thread_insert_id."");
	} else {
		header("Location: http://".$_SERVER['SERVER_NAME']."");
	}
	exit();
}

require_once TPL."header.php";

if ($userinfo['group'] > 0) {
	# Страница создания темы
    if (!empty($_GET['for']) AND !empty($_GET['act']) AND $_GET['act'] == 'new') {
		# Ищем форум с указанным номером
	    $sql = mysql_query("SELECT id FROM `forums_for` WHERE `id` = {$escaped_for}");
		# Если форум есть то отображаем форму добавления темы
	    if (mysql_num_rows($sql) > 0) {
            echo '<form method="POST" class="form-horizontal" action=""><fieldset><legend>Новая тема</legend>
   		    		    <div class="control-group"><label class="control-label" for="name_forum">Название:&nbsp;&nbsp;&nbsp;</label><input maxlength="30" class="span6" type="text" name="name_forum" id="name_forum" value="" ></div>
           	            '.$eng->bb_panel().'
						<textarea maxlength="10000" style="height:70px;" class="span6" name="input_text" id="input_text" rows="5"></textarea>
						<div class="form-actions"><input type="submit" value="Создать тему" class="btn btn-info"></div>
       	          </fieldset></form>';
	    # Если форума нет то выводим ошибку
	    } else {
		    echo $eng->msg("2", "Форума не существует", "2"); 
		}
	}
	# Просмотров форумов
    else if (!empty($_GET['for'])) {
		# Ищем форум с данным номером
	    $sql = mysql_query("SELECT * FROM `forums_for` WHERE `id` = {$escaped_for}");
		# Если форум есть то
		if (mysql_num_rows($sql) > 0) {
			# Ссылка на создание новой темы
		    echo '<a class="btn" style="float:right; font-weight: normal;" href="'.$_SERVER['REQUEST_URI'].'_new">Новая тема</a><br /><br />';
    		# Непонятный человеческому глазу код по поиску первой страницы форума
			if (isset($_GET['page'])) $page=(intval($_GET['page'])-1); else $page=0;
            $start=abs($page*20);
			# Есть ли темы в разделе
			$sql = mysql_query("SELECT * FROM `forums_threads` WHERE `for` = {$escaped_for} LIMIT 1");
			if (mysql_num_rows($sql) > 0) {
				# Ищем темы в форуме с определенной записи
				$sql = mysql_query("SELECT * FROM `forums_threads` WHERE `for` = {$escaped_for} ORDER BY `id` DESC LIMIT $start,20");
				# Если темы найдены то
				if (mysql_num_rows($sql) > 0) {
					# Массив состояний темы (открыта, закреплена, закрыта, горячая)
					$statusthreads = array("1"=>"", "2"=>"info", "3"=>"error", "4"=>"warning");
					# Выводим темы
					while($row=mysql_fetch_array($sql)) {
						# Выбираем все сообщения
						$sql_lastmsgar = mysql_query("SELECT * FROM `forums_messages` WHERE `thread` = {$row['id']}");
						$row_thff = mysql_fetch_array($sql_lastmsgar);
						$sql_lastmsg = mysql_query("SELECT * FROM `forums_messages` WHERE `thread` = {$row['id']} ORDER BY `id` DESC LIMIT 1");
						$row_th = mysql_fetch_assoc($sql_lastmsg);
						$sql_firstmsg = mysql_query("SELECT * FROM `forums_messages` WHERE `thread` = {$row['id']} ORDER BY `id` ASC LIMIT 1");
						$row_thf = mysql_fetch_assoc($sql_firstmsg);
						//массивы юзеров соответственно топикстертера и последнего ответившего
						$arrf = $us->array_user($row_thf['user_id']);
						$arr = $us->array_user($row_th['user_id']);
						//устанавливаем статус темы
						$status = $statusthreads[$row['status']];
						# Время отправки последнего сообщения
						$date = $eng->showtime(strtotime($row_th['time']), 1); 
						# Количество ответов без учета того, кто открыл тему
						$num_msg = mysql_num_rows($sql_lastmsgar)-1;
						# Если сообщений более 20 то тема становится горячей, если она не закрыта
						if ($num_msg > 20 AND $row['status'] != 2) { $status = $statusthreads[4]; }
						# Если тема закрыта то придаем ей цвет
						if ($row['closed'] == 1) { $status = $statusthreads[3]; }
						if ($row['status'] == 2) {
							$englist_up[$row_th['id']] = '<tr class="'.$status.'"><td><i class="icon-star-empty"></i> <a href="http://'.$_SERVER['SERVER_NAME'].'/topic_'.$row['id'].'"> '.$row['title'].'</a><br />Автор: <a href="http://'.$_SERVER['SERVER_NAME'].'/profile_'.$arrf[0].'">'.$us->username($arrf['0'], '1').'</a></td><td>Просмотров: '.$row['view'].'<br /> Ответов: '.$num_msg.'</td><td><i class="icon-time"></i> '.$date.'<br /><a style="font-weight: normal;" href="http://'.$_SERVER['SERVER_NAME'].'/topic_'.$row['id'].'_new">Посл. сообщение:</a> <a href="http://bymirror.ru/profile_'.$arr[0].'">'.$us->username($arr['0'], '1').'</a></td></tr>';
						} else {
							$englist[$row_th['id']] = '<tr class="'.$status.'"><td><a href="http://'.$_SERVER['SERVER_NAME'].'/topic_'.$row['id'].'"> '.$row['title'].'</a><br />Автор: <a href="http://'.$_SERVER['SERVER_NAME'].'/profile_'.$arrf[0].'">'.$us->username($arrf['0'], '1').'</a></td><td>Просмотров: '.$row['view'].'<br /> Ответов: '.$num_msg.'</td><td><i class="icon-time"></i> '.$date.'<br /><a style="font-weight: normal;" href="http://'.$_SERVER['SERVER_NAME'].'/topic_'.$row['id'].'_new">Посл. сообщение:</a> <a href="http://bymirror.ru/profile_'.$arr[0].'">'.$us->username($arr['0'], '1').'</a></td></tr>';
						}
					}
					echo '<table class="table table-bordered"><thead><th>Название</th><th>Статистика</th><th>Информация</th></thead><tbody>';
					# Выводим закрепленные
					if (isset($englist_up) AND count($englist_up) > 0) {
						krsort($englist_up);
						foreach ($englist_up as $showlist)
						{
							echo $showlist;
						}
					}
					# Выводим обычные	
					if (isset($englist) AND count($englist) > 0) {				
						krsort($englist);				
						foreach ($englist as $showlist)
						{
							echo $showlist;
						}
					}
					echo '</tbody></table>';
					# Мозговыносящие операции по определению нумерации страниц
					$sql=mysql_query("SELECT count(*) FROM `forums_threads` WHERE `for` = {$escaped_for}");
					$row=mysql_fetch_row($sql);
					$total_rows=$row[0];
					$num_pages=ceil($total_rows/20);
					if ($num_pages > 1) {
						echo '<div class="pagination pagination-centered"><ul>';
						for($i=1;$i<=$num_pages;$i++) {
							if ($i-1 == $page) {
								echo '<li class="active"><a>'.$i.'</a></li>';
							} else {
								echo '<li><a href="http://'.$_SERVER['SERVER_NAME'].'/forums_for_'.$escaped_for.'_page'.$i.'">'.$i."</a></li>";
							}
						}
						echo "</ul></div>\n";
					}
				} else {
					echo $eng->msg("3", "На данной странице темы отсутствуют", "3");
				}
			} else {
				echo $eng->msg("3", "Ни одной темы еще не создано", "3");
			}
		} else {
		    echo $eng->msg("2", "Форума не существует", "2");
		}
	}
	# Главная страница форума
	else 
	{
        # Если присутствует $_GET запрос на категорию
	    if (!empty($_GET['cat'])) {
			$sql = mysql_query("SELECT * FROM `forums_cat` WHERE `id` = {$escaped_category}");
		# Иначе собираем все категории
		} else {
			$sql = mysql_query("SELECT * FROM `forums_cat`");
		}
		# Закидываем в массив список категорий
    	while($row = mysql_fetch_array($sql)) {
    		$cat[$row['id']] = array("id"=> $row['id'], "name"=> $row['name']);
        }
        # Собираем список форумов
        $sql_f = mysql_query("SELECT * FROM `forums_for`");
		# Закидываем в массив список форумов
    	while($row = mysql_fetch_array($sql_f)) {
    		$for[$row['id']] = array("id"=> $row['id'], "cat"=> $row['cat'], "name"=> $row['name'], "access"=> $row['access'], "icon"=> $row['icon']);
        }
    	# Выводим результат
		if(isset($cat)) {
			foreach($cat as $arrcat) 
			{ 
				echo '<table class="table table-bordered"><thead><th width="350px">'.$arrcat['name'].'</th><th>Последнее сообщение</th></thead><tbody>'; 
				# Выводим $for ассоциативным массивом
				if(isset($for)) {
					foreach($for as $key => $arrfor)
					{
						# Если номер категории совпадает с номером форума то
						if($arrfor['cat'] == $arrcat['id']) {
							# Если права доступа равны 0, либо группа пользователя больше или равна уровню доступа
							if ($arrfor['access'] == 0 OR $userinfo['group'] >= $arrfor['access']) {
								# Количество тем в форуме
								$sql_threads = mysql_query("SELECT id FROM `forums_threads` WHERE `for` = {$arrfor['id']} ");
								# Последнее сообщение в форуме
								$sql_lastmsg = mysql_query("SELECT user_id,thread,time FROM `forums_messages` WHERE `thread` IN (SELECT id FROM `forums_threads` WHERE `for` = {$arrfor['id']}) ORDER BY `id` DESC LIMIT 1");
								if(mysql_num_rows($sql_lastmsg) > 0) { 
									# Получаем массив последнего сообщения
									$row = mysql_fetch_array($sql_lastmsg);
									# Ищем тему по последнему сообщению
									$sql_lastthread = mysql_query("SELECT * FROM `forums_threads` WHERE `id` = {$row['thread']}");
									# Получаем массив темы
									$row_t = mysql_fetch_array($sql_lastthread);
									# Получаем массив пользователя
									$arr = $us->array_user($row['user_id']);
									# Преобразуем дату последнего ответа в нормальный вид
									$date = $eng->showtime(strtotime($row['time']), 1); 
								}
								# Количество сообщений в форуме
								$sql_msg = mysql_query("SELECT id FROM `forums_messages` WHERE `thread` IN (SELECT id FROM `forums_threads` WHERE `for` = {$arrfor['id']})");
								# Иконка форума
								if (!empty($arrfor['icon'])) { 
									$icon = $arrfor['icon']; 
								} else { 
									$icon = 'noicon.jpg'; 
								}
								echo '<tr><td><div style="float:left; margin-right:5px;"><img src="http://'.$_SERVER['SERVER_NAME'].'/main/img/icons/'.$icon.'"></div> <div style="float:left;"><a href="http://'.$_SERVER['SERVER_NAME'].'/forums_for_'.$arrfor['id'].'">'.$arrfor['name'].'</a><br /> Тем: '.mysql_num_rows($sql_threads).' Сообщений: '.mysql_num_rows($sql_msg).'</div></td><td width="40%">'; 
								# Если сообщения найдены то
								if(mysql_num_rows($sql_lastmsg) > 0) { 
									echo '<a class="icon-play" href="http://'.$_SERVER['SERVER_NAME'].'/topic_'.$row_t['id'].'_new"></a> <a href="http://'.$_SERVER['SERVER_NAME'].'/topic_'.$row_t['id'].'">'.$row_t['title'].'</a><br /> от <a href="http://bymirror.ru/profile_'.$arr[0].'">'.$us->username($arr['0'], '1').'</a> '.$date.''; 
								# Иначе оповещение, что их нет
								} else { 
									echo 'Сообщений нет'; 
								} 
								echo '</td></tr>';
							}
						}
						
					}
				}
				echo '</tbody></table>';
			} 
		}
		# Категория отсутствует
		if (mysql_num_rows($sql) == 0 AND !empty($_GET['cat'])) {
		    echo $eng->msg("2", "Категории не существует", "2");
		} else if (empty($_GET['cat']) AND !isset($cat)) {
		    echo $eng->msg("3", "Разделы еще не созданы", "3");			
		}
		# Статистика форума
		if (empty($_GET['cat'])) {
			$sql_1 = mysql_query("SELECT `user_id`, COUNT(user_id) AS posts FROM forums_messages GROUP BY `user_id` ORDER BY posts DESC LIMIT 5");
			$sql_2 = mysql_query("SELECT `thread`, COUNT(thread) AS messages FROM forums_messages GROUP BY `thread` ORDER BY messages DESC LIMIT 5");
			$sql_3 = mysql_query("SELECT * FROM `users` ORDER BY `id` DESC LIMIT 5");
			if(mysql_num_rows($sql_2) != 0) {
				echo '<table border="0" width="100%" cellspacing="1" class="table table-bordered"><thead> 
				<tr> 
				<th width="33%"><center>Самые активные</center></th> 
				<th width="34%"><center>Популярные темы</center></th> 
				<th width="33%"><center>Новички сайта</center></th> 
				</tr></thead> 
				<tbody><tr>'; 
				echo '<td class="gTableBody1" style="padding:10px;">';
				while($row=mysql_fetch_array($sql_1)) {
					$query = mysql_query("SELECT * FROM `users` WHERE `id` = {$row['user_id']}");
					$row_u = mysql_fetch_assoc($query);
					$username = $row_u['login'];
					echo '<span><img src="/main/img/strlk.gif"> <a href="/profile_'.$row['user_id'].'">'.$username.'</a></span>  <span style="float:right;">( '.$row['posts'].' )</span><br />';
				}
				echo '</td>';
				echo '<td class="gTableBody1" style="padding:10px;">';
				while($row=mysql_fetch_array($sql_2)) {
					$query = mysql_query("SELECT * FROM `forums_threads` WHERE `id` = {$row['thread']}");
					$row_u = mysql_fetch_assoc($query);
					$titletopic = mb_substr($row_u['title'],0,17,"UTF-8");
					$messages = $row['messages']-1;
					echo '<span><img src="/main/img/strlk.gif"> <a href="/topic_'.$row['thread'].'">'.$titletopic.'</a></span>  <span style="float:right;">( '.$messages.' )</span><br />';
				}
				echo '</td>';
				echo '<td class="gTableBody1" style="padding:10px;">';
				while($row=mysql_fetch_array($sql_3)) {
					$login = mb_substr($row['login'],0,11,"UTF-8");;
					echo '<span><img src="/main/img/strlk.gif"> <a href="/profile_'.$row['id'].'">'.$login.'</a></span>  <span style="float:right;">( '.date("d.m.y", strtotime($row['date_reg'])).' )</span><br />';
				}
				echo '</td>';
				echo '</tr>
				</tbody>
				</table>';
			}
		}
    }
} else {
    echo $eng->msg("2", "Вы не авторизованы", "2"); 
}
require_once TPL."footer.php";
?>