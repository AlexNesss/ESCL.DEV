<?php
session_start();
define ('BYESCL', true);

require_once "core/maincore.php";

$load = (isset($_GET['v']) ? $_GET['v'] : "");

switch ($load) 
{
    case 'news':
        require_once('modules/news/main.php');
        break;
    case 'profile':
        require_once('modules/profile/main.php');
        break;
    case 'im':
        require_once('modules/im/main.php');
        break;
    case 'users':
        require_once('modules/users/main.php');
        break; 
    case 'userpanel':
        require_once('modules/gmzone/main.php');
        break; 
	case 'pay':
        require_once('modules/pay/main.php');
        break;	
	case 'settings':
        require_once('modules/settings/main.php');
        break;
	case 'friends':
        require_once('modules/friends/main.php');
        break;	
    case 'auth':
        require_once('modules/auth/main.php');
        break; 
    case 'bans':
        require_once('modules/bans/main.php');
        break; 	
	case 'stats':
        require_once('modules/stats/main.php');
        break;	
	case 'logs':
        require_once('modules/pages/logs.php');
        break;	
	case 'alist':
        require_once('modules/pages/alist.php');
        break;	
	case 'admins':
        require_once('modules/admins/main.php');
        break;	
    case 'reg':
        require_once('modules/reg/main.php');
        break; 	
	case 'lostpwd':
        require_once('modules/lostpwd/main.php');
        break;	
	case 'paysuccess':
        require_once('modules/pages/paysuccess.php');
        break;	
	case 'payerror':
        require_once('modules/pages/payerror.php');
        break;			
	case 'error':
        require_once('modules/pages/error.php');
        break;		
    default:
        require_once('modules/index/main.php');
}

#Верх сайта
require_once TPL."header.php";

#Основной блок
echo $tpl->content;

#Низ сайта
require_once TPL."footer.php";