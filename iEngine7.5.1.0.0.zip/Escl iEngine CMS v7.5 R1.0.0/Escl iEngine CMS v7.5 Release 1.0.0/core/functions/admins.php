<?php if (!defined('BYESCL'))			exit('Нет доступа');

	# Массив серверов
	/* [  $gameservers["Название"] = array( "хост", "логин", "пароль", "путь до users.ini", "флаги по умолчанию");  ] */
    $gameservers["Название сервера"] = array( "Хост FTP", "Логин FTP", "Пароль FTP", "Путь до users.ini начиная с папки cstrike или addons (в зависимости от подключения по FTP)", "abcdefghijklmnopqrstu");
	# Сервер по умолчанию
	$default = '1';

function deleteacc($num) {
	$num = intval($num);
	$sql = mysql_query("SELECT * FROM `accounts` WHERE `id` = {$num}");
	if(mysql_num_rows($sql) > 0) {
		$row = mysql_fetch_assoc($sql);
		$sql = mysql_query("DELETE FROM `accounts` WHERE `id` = {$num}");
		$result = upload_config ($row['server'],generate_config($row['server']));
		if($sql) $itog[0] = true; else $itog[0] = false;
		if($result[0]) $itog[1] = true; else $itog[1] = false;
		return array($itog[0], $itog[1]);
	} else {
		return array(false, false);
	}
}

function format_serverlist($servers,$current)
{
	if (!is_array($servers) || count($servers)<1)
	{
		return "<b>Серверы отсутствуют</b>";
	}
	$list = "";
	if (!empty($current))
	{
		foreach ($servers as $name=>$serv)
		{
			$sel = "";
			if ($current==$name)
			{
				$sel = ' selected="selected"';
			}
			$list .= "  <option value=".$name."".$sel.">".$name."</option>\r\n";
		}
	} else {
		$list = "  <option value=".$current.">".$current."</option>\r\n";
	}
	return "<select name='selected_server'>\r\n".$list."</select>\r\n";
}

function generate_config($server)
{
	global $us,$db;
	
	$sql = $db->query("SELECT * FROM accounts WHERE `server`= '{$server}' AND (`date_end` > ".time()." OR `date_end` = 0)");
	$config = "";
	
	if ($db->num_rows($sql))
	{
		while ($row = $db->fetch_array($sql))
		{
				$datestart = date("d.m.y",$row['date_create']);
				
				if(!$row['date_end'])
					$accstatus = 'Навсегда';
				else
					$accstatus = date("d.m.y",$row['date_end']);
				switch($row['type'])
				{
					case "steamid":
						$type = "ac";
						break;
					case "ip":
						$type = "ad";
						break;
					case "nick":
						$type = "a";
						break;
				}
				
				$config .= '"'.$row['value'].'" "'.$row['password'].'" "'.$row['option'].'" "'.$type.'" ; "'.$row['comment'].'" "'.$us->username($row['user_id'], 0).'" "'.$datestart.'" "'.$accstatus.'"'."\r\n";
		}
	}
	return $config;
}
	
function upload_config ($server,$config_text)
{
	global $gameservers, $tpm_directory;
	# Создаем временный файл
	$local_tmp_configfile = tempnam($tpm_directory, "");
	if ($local_tmp_configfile===false)
	{
		$message = 'Внутренняя ошибка генерации конфигурации (возможно недоступен временный каталог)';
		return array(false,$message);
	}
	# Открываем временный файл
	$handle = fopen($local_tmp_configfile, "w");
	if (!$handle)
	{
		$message = 'Внутренняя ошибка генерации конфигурации (возможно он недоступен для записи)';
		return array(false,$message);
	}
	# Записываем в файл текст и закрываем его
	fwrite($handle, $config_text);
	fclose($handle);
	# Название файла, в который будем записывать
	$remote_file = 'users.ini';
	# Если отсутствует двоеточие то присываиваем самостоятельно порт, иначе разбиваем хост на массив
	if(strpos( $gameservers[$server][0],":") === false )
	{
		$ftp_ip = $gameservers[$server][0];
		$ftp_port = 21;
	} else {
		$strings = explode(":",$gameservers[$server][0] );
		$ftp_ip = $strings[0];
		$ftp_port = $strings[1];
	}
	# Будем считать количество ошибок с нуля
	$err = 0;
	# Открытие FTP соединения 
	$conn_id = ftp_connect($ftp_ip, $ftp_port);
	if ($conn_id){
		# Авторизация
		$login_result = ftp_login($conn_id, $gameservers[$server][1], $gameservers[$server][2]);
		if ($login_result)
		{   
			# Переходим в папку
			$chdir = ftp_chdir($conn_id, $gameservers[$server][3]);
			if ($chdir)
			{
				# Загрузка файла $local_tmp_configfile и сохранение его как $remote_file
				if ($res = ftp_put($conn_id, $remote_file, $local_tmp_configfile, FTP_BINARY)) {
					$message = 'Файл конфигурации успешно загружен на '.$server.'';
				} else {
					$message = 'Ошибка загрузки файла конфигурации! Сервер: '.$server.'';
					$err++;
				}
			} else {
				$message = 'Не могу перейти в каталог настроек! Сервер: '.$server.'';
				$err++;
			}
		} else {
			$message = 'Ошибка авторизации на FTP во время обновления конфигурации! Сервер: '.$server.'';
			$err++;
		}
		ftp_close($conn_id);
	} else {
		$message = 'Не могу подключиться к серверу для обновления конфигурации! Сервер: '.$gameservers[$server][0].'';
		$err++;
	}
	# Удаляем временный локальный файл конфига
	unlink($local_tmp_configfile);
	# Возвращаем результат
	if($err > 0) {
		return array(false,$message);
	} else {
		return array(true,$message);
	}
}
?>