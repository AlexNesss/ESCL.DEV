<?php
session_start();
define ('BYESCL', true);
define("CLASSDIR", "../");

require_once CLASSDIR."core/maincore.php";
require_once CLASSDIR."core/functions/lgsl_protocol.php";
require_once CLASSDIR."core/functions/admins.php";

if(empty($_GET['cron']) OR (!empty($_GET['cron']) AND $_GET['cron'] != 'qQ321')) 
	exit('Нет доступа');

$sql = $db->query("SELECT * FROM `servers`");

if($db->num_rows($sql))
{
  
	while($row = $db->fetch_array($sql)) 
	{
		$data = lgsl_query_live($row['ip'],$row['port'], 's');
		$players = lgsl_query_live($row['ip'],$row['port'], 'p');
		if($players['p']) 
		{
			unset($score); unset($kills);
			foreach ($players['p'] AS $key => $kills) 
				$score[$key]  = $kills['frags'];
				
			array_multisort($score, SORT_DESC, $players['p']);
		}		

		$nowplayers = (!empty($players['p']) ? count($players['p']) : 0);
		$listplayers = ($nowplayers ? serialize($players['p']) : '');	
		
		if(!empty($players['p'])) 
		{	
			$names = array();	
			$gonow = $players['p'];	
			
			unset($key); unset($value);
			
			foreach($gonow AS $key => $value)
				$names[] = "'".$key."'";
			
			if(!empty($row['playerslist']))
			{
				$arr = array();
				$go = unserialize($row['playerslist']);

				unset($key); unset($value);
				foreach($gonow AS $key => $value)
				{
					if (array_key_exists($key, $go))
					{
						$nfrags = ($value['frags']-$go[$key]['frags']);
						$ntime = ($value['time']-$go[$key]['time']);
						$sqlfrags = 0;
						$sqltime = 0;	
						if($nfrags >= 0)
						{
							if($ntime >= 0)
								$sqlfrags = $nfrags;
							else if($value['frags'] >= 0)
								$sqlfrags = $value['frags'];
						} else {
							if($ntime >= 0)
								$sqlfrags = 0; // страдаем при /rs
							else if($value['frags'] >= 0)
								$sqlfrags = $value['frags'];
						}
						
						$sqltime = (($ntime >= 0) ? $ntime : $value['time']);
						
						$arr[$key] = array('name' => $key, 'frags' => $sqlfrags, 'time' => $sqltime);
					} else
						$arr[$key] = array('name' => $key, 'frags' => $value['frags'], 'time' => $value['time']);
				}
				
				$sqlnames = implode(',', $names);
				$nquery = $db->query("SELECT * FROM `stats_players` WHERE `server` = '{$row['id']}' AND `name` IN({$sqlnames})");
				while($vrow = $db->fetch_array($nquery))
				{	
					if(isset($arr[$vrow['name']]['frags']) AND isset($arr[$vrow['name']]['time']))
						$db->query("UPDATE `stats_players` SET `frags` = `frags`+{$arr[$vrow['name']]['frags']}, `time` = `time`+{$arr[$vrow['name']]['time']}, `lseen` = '".time()."' WHERE `server` = '{$row['id']}' AND `name` = '{$vrow['name']}'") or die(mysql_error());
					unset($arr[$vrow['name']]);		
				}
				
				if(!empty($arr))
				{
					unset($key); unset($value);
					foreach($arr AS $key => $value)
						$db->query("INSERT INTO `stats_players` (`id`,`name`,`frags`,`time`,`server`,`fseen`,`lseen`,`user_id`) VALUES (NULL,'{$value['name']}','{$value['frags']}', '{$value['time']}','{$row['id']}','".time()."','".time()."','0')");
				}
			} else {
				$sqlnames = implode(',', $names);
				$nquery = $db->query("SELECT * FROM `stats_players` WHERE `server` = '{$row['id']}' AND `name` IN({$sqlnames})");
				while($vrow = $db->fetch_array($nquery))
				{
					if(isset($gonow[$vrow['name']]['frags']) AND isset($gonow[$vrow['name']]['time']))
						$db->query("UPDATE `stats_players` SET `frags` = `frags`+{$gonow[$vrow['name']]['frags']}, `time` = `time`+{$gonow[$vrow['name']]['time']}, `lseen` = '".time()."' WHERE `server` = '{$row['id']}' AND `name` = '{$vrow['name']}'") or die(mysql_error());
					unset($gonow[$vrow['name']]);
				}
				if(!empty($gonow))
				{
					unset($key); unset($value);
					foreach($gonow AS $key => $value)
						$db->query("INSERT INTO `stats_players` (`id`,`name`,`frags`,`time`,`server`,`fseen`,`lseen`,`user_id`) VALUES (NULL,'{$value['name']}','{$value['frags']}', '{$value['time']}','{$row['id']}','".time()."','".time()."','0')") or die(mysql_error());
				}
			}
		}
		$check = $db->query("UPDATE `servers` SET `hostname` = '{$data['s']['HostName']}', `map` = '{$data['s']['map']}', `players` = '{$nowplayers}', `maxplayers` = '{$data['s']['MaxPlayers']}', `status` = '{$data['s']['status']}', `playerslist` = '{$listplayers}' WHERE `id` = {$row['id']}");
		$db->query("INSERT INTO `stats` (`id`, `server_id`, `timestamp`, `map`, `players`, `maxplayers`, `status`) VALUES (NULL, '{$row['id']}', '".time()."', '{$data['s']['Map']}', '{$nowplayers}', '{$data['s']['MaxPlayers']}', '{$data['s']['status']}')");
	}
}

if(!empty($gameservers)) {
	unset($key); unset($value);
	foreach($gameservers AS $key => $value)
		$servers[] = $key;
		
	foreach($servers AS $name) 
	{
		$result = upload_config ($name,generate_config($name));
		if($result[0])
			echo '<font color=green>Удача при обновлении админов сервера '.$name.'</font>: '.$result[1].'<br />';
		else
			echo '<font color=red>Неудача при обновлении админов сервера '.$name.'</font>: '.$result[1].'<br />'; 
	}
}

$info = '<div class="well"><table width="100%">';
$sql = $db->query("SELECT count(*) FROM `users`");
$row = $db->fetch_row($sql);
$info .= '<tr><td width="33%">Всего пользователей: '.$row[0].'</td>';
$sql = $db->query("SELECT count(*) FROM `pm`");
$row = $db->fetch_row($sql);
$info .= '<td width="33%">Личных сообщений: '.$row[0].'</td>';
$sql = $db->query("SELECT count(*) FROM `messages`");
$row = $db->fetch_row($sql);
$sql1 = $db->query("SELECT count(*) FROM `messages` WHERE DATE_FORMAT(`time`, '%Y-%c-%e') = CURDATE()"); 
$row1 = $db->fetch_row($sql1);
$info .= '<td width="33%">Сообщений в чате: '.$row[0].' <sup>+ '.$row1[0].'</sup></td></tr>';
$sql = $db->query("SELECT count(*) FROM `news`");
$row = $db->fetch_row($sql);
$info .= '<tr><td width="33%">Всего новостей: '.$row[0].'</td>';
$sql = $db->query("SELECT count(*) FROM `add_bans` WHERE `type` != 0");
$row = $db->fetch_row($sql);
$info .= '<td width="33%">Рассмотрено банов: '.$row[0].'</td>';
$sql = $db->query("SELECT count(*) FROM `news_com`");
$row = $db->fetch_row($sql);
$info .= '<td width="33%">Оставлено комментариев: '.$row[0].'</td></tr>';
$sql = $db->query("SELECT count(*) FROM `forums_threads`");
$row = $db->fetch_row($sql);
$info .= '<tr><td width="33%">Всего тем: '.$row[0].'</td>';
$sql = $db->query("SELECT count(*) FROM `forums_messages`");
$row = $db->fetch_row($sql);
$info .= '<td width="33%">Сообщений на форуме: '.$row[0].'</td>';
$sql = $db->query("SELECT count(*) FROM `accounts`");
$row = $db->fetch_row($sql);
$info .= '<td width="33%">Игровые админ/вип: '.$row[0].'</td></tr>';
$info .= '</table></div>';
file_put_contents($_SERVER['DOCUMENT_ROOT'].'/tpl/other/info.txt', $info);