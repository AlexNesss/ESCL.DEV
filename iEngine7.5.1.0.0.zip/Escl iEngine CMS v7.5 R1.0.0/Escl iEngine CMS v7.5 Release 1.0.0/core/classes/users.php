<?php if (!defined('BYESCL'))			exit('Нет доступа');

class Users
{
	# escl iengine 
	/*
	Описание: Авторизация пользователей в системе
	Параметры: Остутствуют
	*/
	static function chauth()
	{
		global $db;
		if (isset($_COOKIE["id"]) && isset($_COOKIE["hash"])) 
		{
			$id = $db->escape($_COOKIE['id']);
			$hash = $db->escape($_COOKIE['hash']);
			$sql = $db->query("SELECT `users`.*, `groups`.`access` AS `gaccess` FROM `users`,`groups` WHERE `users`.`id` = '{$id}' AND FIND_IN_SET('{$hash}', `users`.`hash`) AND `users`.`group_id` = `groups`.`group_id`");
			if ($db->num_rows($sql) == 1) 
			{
				$row = $db->fetch_array($sql);
				$access = explode(",", $row['access']);
				$gaccess = explode(",", $row['gaccess']);
				return array('group' => $row['group_id'], 'login' => $row['login'], 'id' => $row['id'], 'access' => $access, 'gaccess' => $gaccess);
			} else
				return array('group' => 0, 'id' => 0, 'access' => array(), 'gaccess' => array());
		} else
			return array('group' => 0, 'id' => 0, 'access' => array(), 'gaccess' => array());
	}
	
	# escl iengine 
	/*
	Описание: Поиск определенного права доступа пользователя
	Параметры: $access (массив или текст) - параметр для поиска прав доступа в массиве
	*/
	static function asearch($access) 
	{
		global $userinfo;
		if(is_array($access)) 
		{
			for ($x=0; $x<count($access); $x++)
				if(!in_array($access[$x], $userinfo['access'])) return false;
			return true;
		} else 
			return in_array($access, $userinfo['access']);
	}

	# escl iengine 
	/*
	Описание: Поиск определенного права доступа группы
	Параметры: $access (массив или текст) - параметр для поиска прав доступа в массиве
	*/
	static function agsearch($access) 
	{
		global $userinfo;
		if(is_array($access)) 
		{
			for ($x=0; $x<count($access); $x++)
				if(!in_array($access[$x], $userinfo['gaccess'])) return false;
			return true;
		} else 
			return in_array($access, $userinfo['gaccess']);
	}
	
	# escl iengine  
	/*
	Описание: Вывод ника пользователя в соответствии с группой, либо без
	Параметры: $id (число)   - номер пользователя 
			   $mode (число) - переключатель ~ 1 - вывод ника с учетом класса группы 0 - без учета класса
	*/	
	static function uname($id, $mode = 0) 
	{
		global $db;
		$sql = $db->query("SELECT `users`.`login`, `users`.`id`, `groups`.`class` AS `class` FROM `users`, `groups` WHERE `id` = '{$id}' AND `users`.`group_id` = `groups`.`group_id`");
		if ($db->num_rows($sql) == 1) 
		{
			$row = $db->fetch_array($sql);
			if($mode == 1)
				return "<span id='username".$row['id']."' class='".$row['class']."'>".$row['login']."</span>";
			else
				return $row['login'];
		} else 
			return '...';
	}
	
	# escl iengine  
	/*
	Описание: Отбор уникальных ID пользователей и вывод ников
	Параметры: $users_pre (массив)  - номера пользователей
			   $mode (число) 		- переключатель ~ 1 - вывод ников с учетом класса группы 0 - без учета класса
	*/
	static function ausers($users_pre, $mode = 0) 
	{
		global $db;
		$users_pre = implode(',', array_unique($users_pre));
		$sql = $db->query("SELECT `users`.`login`,`users`.`id`, `groups`.`class` FROM `users`,`groups` WHERE `users`.`id` IN({$users_pre}) AND `users`.`group_id` = `groups`.`group_id`");
		while($row = $db->fetch_array($sql)) 
		{
			if($mode == 1)
				$users[$row['id']] = "<span id='username".$row['id']."' class='".$row['class']."'>".$row['login']."</span>";
			else 
				$users[$row['id']] = $row['login'];
		}
		return $users;
	}
	
	# escl iengine  
	/*
	Описание: Вывод названия группы
	Параметры: $id (число)  - номер группы
			   $mode (число) - переключатель ~ 1 - вывод названия группы с учетом цвета 0 - без учета цвета
	*/	
	static function gname($id, $mode = 0) 
	{
		global $db;
		$sql = $db->query("SELECT * FROM  `groups` WHERE  `group_id` = '{$id}'");
		if($db->num_rows($sql) == 1) 
		{
			$row = $db->fetch_array($sql);
			if($mode == 1)
				return '<span class="'.$row['class'].'">'.$row['group_name'].'</font>';			
			else
				return $row['group_name'];
		} else
			return '...';
	}

	# escl iengine  
	/*
	Описание: Вывод список групп
	Параметры: Отсутствуют
	*/	
	static function gnamelist() 
	{
		global $db;
		$sql = $db->query("SELECT * FROM  `groups`");
		$groups = array();
		if($db->num_rows($sql) > 0)
		{
			while($row = $db->fetch_array($sql))
			{
				$groups[$row['group_id']] = '<span class="'.$row['class'].'">'.$row['group_name'].'</font>';
			}
		}
		return $groups;
	}
	
	# escl iengine  
	/*
	Описание: Ссылка на аватар пользователя
	Параметры: $id (число)  - номер пользователя
	*/	
	static function avatar($id) 
	{
		$filename = $_SERVER['DOCUMENT_ROOT'].BASEDIR.'/main/avatar/'.$id.'.jpg';
		if (file_exists($filename))
			return SITEDIR.BASEDIR.'/main/avatar/'.$id.'.jpg';
		else
			return SITEDIR.BASEDIR.'/main/avatar/noavatar.jpg';
	}
	
	# escl iengine  
	/*
	Описание: Список пользователей на сайте
	Параметры: Отсутствуют
	*/	
	static function who_online() 
	{
		global $db,$userinfo,$us,$eng;
		$db->query("DELETE FROM `online` WHERE `unix`+900 < ".time()." OR `ip` = '".USER_IP."' OR `id_user` = '{$userinfo['id']}'");
		if($userinfo['group'] == 0)
			$sql_insert = "INSERT INTO `online` VALUES ('','".USER_IP."','".time()."','')";
		else
			$sql_insert = "INSERT INTO `online` VALUES ('','".USER_IP."','".time()."','{$userinfo['id']}')";		
		$db->query($sql_insert);
		
		$sql = $db->query("SELECT * FROM `online`");
		$result = '';
		$numg = 0;
		if ($db->num_rows($sql) > 0) 
		{
			while($row = $db->fetch_array($sql)) 
			{
				if($row['id_user'] != 0)
				{
					//if($row['id_user'] != 1)
					//{
						$prepareusers[] = $row['id_user'];
						$user[] = $row;
					//}
				} else 
					$numg++;
			}
			if(!empty($prepareusers))
			{
				$hn = array();
				$query1 = $db->query("SELECT * FROM `servers`");
				while($rw1 = $db->fetch_array($query1))
				{	
					$hn[$rw1['id']] = $rw1['hostname'];
				}
				$players = implode(",", $prepareusers);
				$query2 = $db->query("SELECT * FROM `stats_players` WHERE `user_id` IN({$players}) AND `lseen` > '".(time()-300)."'");
				$pl = array();
				while($rw = $db->fetch_array($query2))
				{
						$pl[$rw['user_id']] = array('name' =>$rw['name'], 'hn' => $hn[$rw['server']]);
				}
				$users = $us->ausers($prepareusers, 1);
				foreach($prepareusers AS $key => $value) 
				{
					if (isset($pl[$value]))
					{
						//$var = '<span class=\'tooltips\'> <a href=\''.SITEDIR.''.BASEDIR.'/profile_'.$value.'\'><img id=\'status\' src=\''.IMG.'round-green.png\'> '.$users[$value].'<el>'.$pl[$value]['name'].' сейчас на сервере '.$pl[$value]['hn'].'</el></a></span>';
						$var = '<span><span><i class=\'icon-chevron-right\'></i> <a href=\''.SITEDIR.''.BASEDIR.'/profile_'.$value.'\'>'.$users[$value].'</a></span> <span class=\'pull-right\' style=\'color:green;\'><b>В игре</b></span></span>';
						if(!empty($userslist))
							array_unshift($userslist, $var);
						else
							$userslist[] = $var;
					} else {
						//$var = '<span><a href=\''.SITEDIR.''.BASEDIR.'/profile_'.$value.'\'>'.$users[$value].'</a></span>';
						$var = '<span><span><i class=\'icon-chevron-right\'></i> <a href=\''.SITEDIR.''.BASEDIR.'/profile_'.$value.'\'>'.$users[$value].'</a></span> <span class=\'pull-right\' style=\'color:#00596B;\'><b>На сайте</b></span></span>';
						$userslist[] = $var;
					}
					
				}
				$result .= implode('<br />', $userslist);
			} else 
				$result .= '<center>Только '.$eng->declOfNum($numg, array('гость','гостя','гостей')).'</center>';
		}
		return $result; 
	}	
	
	# escl iengine  
	/*
	Описание: Получение полной информации о пользователе
	Параметры: $ids (число или массив)  - номер пользователя
	*/	
	static function arr_users($ids) 
	{
		global $db;
		if(is_array($ids)) 
		{
			$users_pre = implode(',', array_unique($ids));
			$sql = $db->query("SELECT * FROM `users` WHERE `id` IN({$ids})");
			while($row = $db->fetch_array($sql)) 
			{
				$users[$row['id']] = $row;
			}
			return $users;
		} else {		
			$sql = $db->query("SELECT * FROM `users` WHERE `id` = '{$ids}'");
			if($db->num_rows($sql) == 1)
				return $db->fetch_array($sql);
			else
				return '...';
		}
	}
	
	# escl iengine  
	/*
	Описание: Получение статуса пользователя
	Параметры: $ids (число или массив)  - номер пользователя
	*/		
	static function ustatus($ids) 
	{
		global $db;
		if(is_array($ids)) 
		{
			$users_pre = implode(',', array_unique($ids));
			$sql = $db->query("SELECT * FROM `users` WHERE `id` IN({$users_pre})");
			while($row = $db->fetch_array($sql)) 
			{
				if($row['status'] == 1)
					$users[$row['id']] = '<img id="status" src="'.IMG.'round-green.png" />';
				else 
					$users[$row['id']] = '<img id="status" src="'.IMG.'round-grey.png" />';
			}
			return $users;
		} else {
			$sql = $db->query("SELECT * FROM `users` WHERE `id` = '{$ids}' AND `status` = 1");
			if ($db->num_rows($sql) > 0)
				return '<img id="status" src="'.IMG.'round-green.png" />';
			else 
				return '<img id="status" src="'.IMG.'round-grey.png" />';
		}
	}
	
	#Старые функции
	static function userstatusicon($intid)
	{
		$intid = intval($intid);
		$sql = mysql_query("SELECT * FROM  `online` WHERE  `id_user` = {$intid}");
		if (mysql_num_rows($sql) > 0) {
			return '<img id="status" src="'.IMG.'round-green.png" />';
		} else {
			return '<img id="status" src="'.IMG.'round-grey.png" />';
		}
	}
	static function userstatus($id) {
		global $db;
		$sql = $db->query("SELECT * FROM  `online` WHERE  `id_user` = {$id}");
		if ($db->num_rows($sql) > 0)
			return "#34c924";
		else
			return "#808080";
	}
	static function array_user($intid) {
		global $db;
		$intid = intval($intid);
		$sql = $db->query("SELECT * FROM `users` WHERE `id` = '{$intid}'");
		if(mysql_num_rows($sql) == '1') {
			$row = mysql_fetch_row($sql);
			return $row;
		} else {
			return;
		}
	}
	static function online_users() {
		global $user_id, $user_auth;
		$wine = 900;
		$ip = USER_IP;
		$result_update = mysql_query("DELETE FROM online WHERE `unix`+$wine < ".time()." OR `ip` = '$ip'") or die(mysql_error());
		if ($user_auth > 0) {
			$sql_users = mysql_query("SELECT * FROM `online` WHERE `id_user` = {$user_id}") or die(mysql_error());
			if (mysql_num_rows($sql_users) == 0) {
				$sql_insert = "INSERT INTO online VALUES ('','$ip','".time()."','$user_id')";
			} else {
				$sql_insert = "INSERT INTO online VALUES ('','$ip','".time()."','')";
			}
		} else {
			$sql_insert = "INSERT INTO online VALUES ('','$ip','".time()."','')";
		}
		$result_insert = mysql_query($sql_insert) or die(mysql_error());
		$sql = mysql_query("SELECT * FROM online WHERE id_user != '0'") or die(mysql_error());
		if (mysql_num_rows($sql) > 0) {
			while($row = mysql_fetch_array($sql)) {
				$userslist[] = '<a href="'.BASEDIR.'profile_'.$row['id_user'].'">'.Users::username($row['id_user'],1).'</a>';
			}
			echo '<br />Авторизованные пользователи: ';
			echo implode(', ', $userslist);
		}
	}
	static function checkauth()
	{
		if (isset($_COOKIE["id"]) && isset($_COOKIE["hash"])){
			$escaped_id = mysql_real_escape_string($_COOKIE['id']);
			$escaped_hash = mysql_real_escape_string($_COOKIE['hash']);
			$sql = mysql_query("SELECT * FROM `users` WHERE id= '{$escaped_id}' AND hash= '{$escaped_hash}'") or die(mysql_error());
			if (mysql_num_rows($sql) == '1') {
				$row = mysql_fetch_assoc($sql);
				return array($row['group_id'], $row['login'], $row['email'], md5($row['email']), $row['name'], $row['nick'], $row['date_reg'], $row['id'], $row['password'], $row['vk'], $row['steamid']);
			} else {
				return array(0);
			}
		} else {
			return array(0);
		}
	}
	
	static function username($intid,$status) {
		$intid = intval($intid);
		$sql = mysql_query("SELECT `users`.`login`,`users`.`group_id`, `users`.`id`, `groups`.`color` AS color FROM `users`, `groups` WHERE `id` = {$intid} AND `users`.`group_id`= `groups`.`group_id`") or die(mysql_error());
		if (mysql_num_rows($sql) > 0) {
			$row = mysql_fetch_assoc($sql);
			if($status == '1')
				$username = '<font id="username'.$row['id'].'" color="'.$row['color'].'">'.$row['login'].'</font>';
			else if($status == '0')
				$username = $row['login'];
		} else { 
			$username = 'Ошибка';
		}
		return $username;
	}
	static function prepareusers($prepareusers) {
		global $db;
		$prepareusers = array_unique($prepareusers);
		$prepareusers = implode(',', $prepareusers);
		$sql = $db->query("SELECT `users`.`login`,`users`.`id`, `groups`.`color` FROM `users`,`groups` WHERE `users`.`id` IN({$prepareusers}) AND `users`.`group_id` = `groups`.`group_id`");
		while($row_u = $db->fetch_array($sql)) {
			$users[$row_u['id']] = '<font id="username'.$row_u['id'].'" color="'.$row_u['color'].'">'.$row_u['login'].'</font>';
		}	
		return $users;
	}	
	static function groupname($intid, $status) {
		$intid = intval($intid);
		$sql = mysql_query("SELECT * FROM  `groups` WHERE  `group_id` = {$intid}") or die(mysql_error());
		if(mysql_num_rows($sql) == '1') {
			$row = mysql_fetch_assoc($sql);
			if($status == '1' AND $row['group_id'] > 2) {
				return "<font color='".$row['color']."'>".$row['group_name']."</font>";			
			} else {
				return $row['group_name'];
			}
		} else {
			return "Ошибка группа для пользователя не указана";
		}
	}
	static function skillname($intid, $status) {
		$intid = intval($intid);
		$sql = mysql_query("SELECT * FROM  `skills` WHERE  `skill_id` = {$intid}") or die(mysql_error());
		if(mysql_num_rows($sql) == '1') {
			$row = mysql_fetch_assoc($sql);
			if($status == '1' AND $row['skill_id'] > 2) {
				return "<font color='".$row['color']."'>".$row['skill_name']."</font>";			
			} else {
				return $row['skill_name'];
			}
		} else {
			return "Ошибка график скилла не указан";
		}
	}
}
?>