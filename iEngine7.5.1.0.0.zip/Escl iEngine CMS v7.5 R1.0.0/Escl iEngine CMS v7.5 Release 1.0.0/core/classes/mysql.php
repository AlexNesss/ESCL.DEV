<?php if (!defined('BYESCL'))			exit('Нет доступа');

class DataBase 
{
	private $db_serv = 'host.database.com';
	private $db_user = 'database_user';
	private $db_name = 'database_name';
	private $db_pass = 'database_password';
	public $db_prefix = '';
	private $count = 0;

    public function __construct()
    {
		$dbconnect = mysql_connect($this->db_serv, $this->db_user, $this->db_pass);
		$dbselect = mysql_select_db($this->db_name);
		mysql_set_charset('utf8');
		if (!$dbconnect)
			exit("<div style='font-family:Verdana;font-size:11px;text-align:center;'><b>Не могу подключиться к MySQL</b><br />".mysql_errno()." : ".mysql_error()."</div>");
		elseif(!$dbselect)
			exit("<div style='font-family:Verdana;font-size:11px;text-align:center;'><b>Не могу подключиться к MySQL базе данных</b><br />".mysql_errno()." : ".mysql_error()."</div>");
    }
	
    public function query($query)
    {
		$this->count++;
		return mysql_query($query);
    }

    public function fetch_array($result)
    {
		return mysql_fetch_array($result, MYSQL_ASSOC);
	}
	
	public function fetch_row($result)
    {
		return mysql_fetch_array($result, MYSQL_NUM);
	}

    public function num_rows($result)
    {
		return mysql_num_rows($result);
    }

    public function escape($result)
    {
		return mysql_real_escape_string($result);
	}
	
    public function get_count()
    {
		return $this->count;
    }
}