<?php if (!defined('BYESCL'))			exit('Нет доступа');

error_reporting(E_ALL);
ini_set('display_errors', '1');

# Калькулятор вывода генерации страницы
$time = microtime();
$time = explode(' ', $time);
$time = $time[1] + $time[0];
$start = $time;

# Часовой пояс
date_default_timezone_set('Europe/Moscow');

# Константы
if (!defined("BASEDIR")) define("BASEDIR", "");
if (!defined("SITEDIR")) define("SITEDIR", "http://www.domain.com/");
if (!defined("CLASSDIR")) define("CLASSDIR", "");
define("SITENAME", "Name of project");
define("DEFKEY", "Name of project");
define("DEFDESC", "Name of project");
define("JS", SITEDIR."/main/js/");
define("CSS", SITEDIR."/main/css/");
define("IMG", SITEDIR."/main/img/");
define("TPL", BASEDIR."tpl/");
define("USER_IP", $_SERVER['REMOTE_ADDR']);
define("QUOTES_GPC", (ini_get('magic_quotes_gpc') ? TRUE : FALSE));

# Переменные
$sitename = 'Name of project';
$version = 'Escl_iEngineCMS';
$wmr = 'R145938920018';

# Подключаемые файлы
require_once CLASSDIR."core/classes/mysql.php";
require_once CLASSDIR."core/classes/engine.php";
require_once CLASSDIR."core/classes/users.php";
require_once CLASSDIR."core/classes/tpl.php";

$db = new DataBase();
$eng = new Engine();
$us = new Users();
$tpl = new Tpl();

# Авторизация
$userinfo = $us->chauth();