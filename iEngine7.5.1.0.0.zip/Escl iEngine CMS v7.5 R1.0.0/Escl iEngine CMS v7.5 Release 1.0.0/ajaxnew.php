<?php
session_start();
define ('BYESCL', true);
require_once "core/maincore.php";
$page = 'ajaxnew';

Header("Cache-Control: no-cache, must-revalidate");
Header("Pragma: no-cache");
Header("Content-Type: text/javascript; charset=utf-8");

if(isset($_POST['act'])) 
{
	switch ($_POST['act'])
	{
		case "send_chat" :
			send_chat();
			break;
		case "load_chat" :
			load_chat();
			break;
		case "load_old_chat" :
			load_old_chat();
			break;
		case "messages_im_del" :
			messages_im_del();
			break;
		case "pm_msg" :
			pm_msg();
			break;
		case "like_post" :
			like_post();
			break;
		case "send_im" :
			send_im();
			break;
		case "messages_im_check" :
			messages_im_check();
			break;
		case "messages_im" :
			messages_im();
			break;
		case "messages_im_load" :
			messages_im_load();
			break;
		case "messages_forum_del" :
			messages_forum_del();
			break;
		default :
			exit();
	}
} else
	echo 'Что вы тут забыли?';

function like_post() 
{
    global $userinfo, $us;
	$result = false;
    if ($userinfo['group'] > 0) {
		$postid = intval($_POST['postid']);
        $sql = mysql_query("SELECT * FROM `forums_messages` WHERE `id` = {$postid}");
		if(mysql_num_rows($sql) > 0) {
			$row = mysql_fetch_assoc($sql);
			$arrlikes = explode(",", $row['likes']);
			if (!in_array($userinfo['id'], $arrlikes) AND !in_array($row['user_id'], $arrlikes)) {
				if(!empty($row['likes'])) {
					$likes = $row['likes'].','.$userinfo['id'].'';
					$result = '$("#like_post" + '.$postid.').append(", <a href=\"'.BASEDIR.'/profile_'.$userinfo['id'].'\">'.mysql_real_escape_string($us->username($userinfo['id'], 1)).'</a>")';
				} else {
					$likes = $userinfo['id'];
					$result = '$("#like_post" + '.$postid.').append("<a href=\"'.BASEDIR.'/profile_'.$userinfo['id'].'\">'.mysql_real_escape_string($us->username($userinfo['id'], 1)).'</a>")';
				}
				mysql_query("UPDATE `forums_messages` SET `likes` =  '{$likes}' WHERE `id` = {$postid}");
			}
		}
    }
	echo $result;
}
function pm_msg() {
    global $userinfo;
    if ($userinfo['group'] > 0) {
        $sql = mysql_query("SELECT count(*) AS `count` FROM `pm` WHERE `status` = 0 AND `to_user_id` = {$userinfo['id']}");
		$row = mysql_fetch_array($sql);
        echo $row['count'];
    } else {
        echo 0;
    }
}
function messages_forum_del() {
	global $userinfo;
	if ($userinfo['group'] > 0 AND !empty($_POST['npost'])) {
		$npost = intval($_POST['npost']);
		$query = mysql_query ("SELECT * FROM `forums_messages` WHERE `id` = {$npost}");
		if(mysql_num_rows($query) > 0) {
			$row = mysql_fetch_assoc($query);
			$sql = mysql_query ("SELECT * FROM `forums_threads` WHERE `fpost` = {$row['id']}");
			if(mysql_num_rows($sql) > 0) {
				if($userinfo['group'] == 4 OR $row['user_id'] == $userinfo['id']) {
					mysql_query ("DELETE FROM `forums_threads` WHERE `id` = {$row['thread']}");
					mysql_query ("DELETE FROM `forums_messages` WHERE `thread` = {$row['thread']}");
				}
			} else {
				if($userinfo['group'] == 4 OR $row['user_id'] == $userinfo['id']) {
					mysql_query ("DELETE FROM `forums_messages` WHERE `id` = {$npost}");
				}
			}
		}
	}
}
function send_chat()
{
    global $userinfo, $eng;
	if ($userinfo['group']) 
	{
	    $text = $eng->stripinput($_POST['text']);
		$text = trim($text);
		if (!empty($text))
	        mysql_query("INSERT INTO messages (text,user_id,time) VALUES ('{$text}', '{$userinfo['id']}', CURRENT_TIMESTAMP)");
	}
}

function load_chat()
{
	# Получаем POST  данные и глобальные переменные
	$last_message_id = intval($_POST['last']);
	global $userinfo, $us, $eng;
	# Получаем все сообщения, которые больше $last_message_id
	$sql = mysql_query("SELECT * FROM messages WHERE ( id > $last_message_id ) ORDER BY id DESC LIMIT 80");
	# Если появились новые сообщения то
	if( mysql_num_rows($sql) > 0 )
	{
		$getsmiles = $eng->getsmiles();
		$js = 'var chat = $("#chatLineHolder");';
		# Создаем пустой массив сообщений
		$messages = array();
		# Получаем полный массив сообщений
		while ( $row = mysql_fetch_array($sql) )
		{
			$messages[] = array_merge(array($row['id']), array($row['text'].''), array(''.$row['time'].''), $us->array_user($row['user_id']));
		}
		# Получаем ID последнего сообщения
		$last_message_id = $messages[0][0];
		# Переворачиваем массив
		$messages = array_reverse($messages);
		# Выводим сообщения
		foreach ( $messages as $value )
		{
			$date = $eng->showtime(strtotime($value['2']), 0);
			$chat = mysql_real_escape_string($eng->replacechat($eng->replace_smiles($value['1'], $getsmiles['search'], $getsmiles['replace'])));
			$js .= 'chat.prepend("<div class=\"chat chat-626 rounded\" id=\"'.$value[0].'\"><span class=\"gravatar\"><a target=\"_blank\" href=\"http://'.$_SERVER['SERVER_NAME'].'/profile_'.$value[3] .'\"><img src=\"'.$us->avatar($value[3]).'\" width=\"23\" height=\"23\" ></a></span><span class=\"author\" onclick=\"chat_to(\''.$value['3'].'\')\">'.mysql_real_escape_string($us->username($value['3'], 1)).':</span><span title=\"'.$date.'\" class=\"text\">'.$chat.'</span><span class=\"time\">'.$date.'</span></div>");';
		}
		# Записываем в переменную номер последнего сообщения
		$js .= "last_message_id = $last_message_id;";
		$js .= "last_message_id = $last_message_id;";
		# Выводим результат
		echo $js;
	}
}

function load_old_chat()
{
	# Получаем POST  данные и глобальные переменные
	$last_message_id = intval($_POST['last']);
	global $userinfo, $us, $eng;
	# Получаем все сообщения, которые больше $last_message_id
	$sql = mysql_query("SELECT * FROM messages WHERE ( id < $last_message_id ) ORDER BY id DESC LIMIT 80");
	# Если появились новые сообщения то
	if( mysql_num_rows($sql) > 0 )
	{
		$getsmiles = $eng->getsmiles();
		$js = 'var chat = $("#chatLineHolder");';
		# Создаем пустой массив сообщений
		$messages = array();
		# Получаем полный массив сообщений
		while ( $row = mysql_fetch_array($sql) )
		{
			$messages[] = array_merge(array($row['id']), array($row['text']), array($row['time']), $us->array_user($row['user_id']));
		}
		# Выводим сообщения
		foreach ( $messages as $value )
		{
			$date = $eng->showtime(strtotime($value['2']), 0);
			$chat = mysql_real_escape_string($eng->replacechat($eng->replace_smiles($value['1'], $getsmiles['search'], $getsmiles['replace'])));
			$js .= 'chat.append("<div class=\"chat chat-626 rounded\" id=\"'.$value[0].'\"><span class=\"gravatar\"><a target=\"_blank\" href=\"http://'.$_SERVER['SERVER_NAME'].'/profile_'.$value[3] .'\"><img src=\"'.$us->avatar($value[3]).'\" width=\"23\" height=\"23\" ></a></span><span class=\"author\" onclick=\"chat_to(\''.$value['3'].'\')\">'.mysql_real_escape_string($us->username($value['3'], 1)).':</span><span title=\"'.$date.'\" class=\"text\">'.$chat.'</span><span class=\"time\">'.$date.'</span></div>");';
		}
		# Выводим результат
		echo $js;
	}
}

function send_im()
{
    global $userinfo, $eng;
	if ($userinfo['group'] > 0 AND !empty($_POST['text']) AND !empty($_POST['dialog'])) {
		$textpm = $eng->stripinput($_POST['text']);
		$escaped_dialog = intval($_POST['dialog']);
		$query = mysql_query ("SELECT * FROM `dialogs` WHERE `id` = {$escaped_dialog}");
		$row = mysql_fetch_assoc($query);
		if (mysql_num_rows($query) > 0 AND $row['from'] == $userinfo['id'] OR $row['to'] == $userinfo['id']) {
			if ($row['from'] == $userinfo['id']) {
			    $to_id = $row['to'];
			} else {
				$to_id = $row['from'];
			}
			$textpm = trim($textpm);
			if (!empty($textpm)) {
                mysql_query ("INSERT INTO `pm` (`id` ,`dialog` ,`user_id` ,`to_user_id` ,`text` ,`status`)VALUES (NULL ,  '{$escaped_dialog}',  '{$userinfo['id']}', '{$to_id}',  '{$textpm}',  '0')");
	        }
		}
	}
}

function messages_im() {
	# Получаем POST  данные и глобальные переменные
	$last_message_id = intval($_POST['last']);
	$escaped_dialog = intval($_POST['dialog']);
	global $userinfo, $us, $eng;
	# Существует ли диалог с данным ID
	$sql_d = mysql_query("SELECT * FROM dialogs WHERE id = {$escaped_dialog} ORDER BY id DESC") or die(mysql_error());
	# Если существует то
	if (mysql_num_rows($sql_d) > 0 AND $userinfo['group'] > 0) {
		# Получаем все сообщения из диалога которые больше $last_message_id
		$sql = mysql_query("SELECT * FROM pm WHERE dialog = {$escaped_dialog} AND ( id > $last_message_id ) ORDER BY id DESC LIMIT 150") or die(mysql_error());
		# Получаем ассоциативный массив самого диалога (пользователи входящие в него и номер)
		$rowd = mysql_fetch_assoc($sql_d);
		# Если я или собеседник имеют ID как у меня то
		if ($rowd['from'] == $userinfo['id'] OR $rowd['to'] == $userinfo['id']) {
			# Если сообщений в диалоге больше 0 то
			if (mysql_num_rows($sql) > 0) {
				# Задаем id блока в котором будут выводится сообщения
				$js = 'var pm = $("#allmessages");';
				# Создаем пустой массив сообщений
				$messages = array();
				# Получаем полный массив сообщений
				while($row = mysql_fetch_array($sql)) {
					$messages[] = array_merge(array(''.$row['text'].''), array(''.$row['id'].''), array(''.$row['date'].''), array(''.$row['status'].''), $us->array_user($row['user_id']));
				}
				# Получаем ID последнего сообщения
				$last_message_id = $messages[0][1];	
				# Переворачиваем массив
				$messages = array_reverse($messages);
				# Выводим сообщения
				foreach ($messages as $value)
				{
					# Если это сообщение не мое и оно не просмотрено то делаем его просмотренным
					if($value[4] != $userinfo['id'] AND $value[3] == 0) {
						mysql_query("UPDATE pm SET status = 1 WHERE id = {$value[1]}");
					}
					# Дата отправления сообщения
					$date = $eng->showtime(strtotime($value['2']), 0); 				
					$js .= 'pm.prepend("<div class=\"messages msg'.$value[1].'\">';
					$js .= '<div ';
					if($value[4] != $userinfo['id']) { 
						$js .= 'class=\"msg_item\" onmouseover=\"$(this).animate({backgroundColor: \'rgba(242, 247, 249, 255)\'})\" '; 
					} else { 
						$js .= 'class=\"msg_item my_msg\" '; 
					}
					if ($value[3] == '0') { 
						$js .= 'style=\"background-color: #BDDBF9;\"'; 
					} else { 
						$js .= 'style=\"background-color: #F2F7F9;\"'; 
					}
					$js .= '\">';
					$js .= '<div class=\"mi_iwrap\"><img src=\"'.$us->avatar($value['4']).'\" class=\"mi_img\"></div>';
					$js .= '<div class=\"mi_cont\">';
					$js .= '<div class=\"mi_head\">';
					if ($value[4] == $userinfo['id'] OR $userinfo['group'] == 4) {
						$js .= '<p class=\"mi_date\">'.$date.' <a class=\"icon-remove\" href=\"javascript:void(0)\" onclick=\"delete_pm('.$value[1].')\"></a></p>';
					} else {
						$js .= '<p class=\"mi_date\">'.$date.'</p>';
					}
					$js .= '<a class=\"mi_author\" tarPOST=\"_blank\" href=\"'.BASEDIR.'profile_'.$value['4'].'\">'.mysql_real_escape_string($us->username($value['4'], 1)).'</a>';
					$js .= '</div>';
					$js .= '<div class=\"mi_body\">';
					$js .= '<div class=\"mi_text\">'.mysql_real_escape_string($eng->smiles($value['0'], 1, 0)).'</div>';
					$js .= '</div>';
					$js .= '</div>';
					$js .= '</div>';
					$js .= '</div>");';
				}
				# Записываем в переменную номер последнего сообщения
				$js .= "last_message_id = $last_message_id;";
				# Выводим результат
				echo $js;
			}
		}
	}
}

function messages_im_del() {
	global $userinfo;
    $del_pm = intval($_POST['id_del']);
	$escaped_dialog = intval($_POST['dialog']);
    if ($userinfo['group'] == 4) {
        $sql = mysql_query("SELECT * FROM `dialogs` WHERE `id` = {$escaped_dialog}") or die(mysql_error());
	    if (mysql_num_rows($sql) > 0)
	    { 
            mysql_query("DELETE FROM `pm` WHERE `id` = {$del_pm}") or die(mysql_error());
		}
	} else {
        $sql = mysql_query("SELECT * FROM `dialogs` WHERE `id` = {$escaped_dialog} AND `from` = {$userinfo['id']} OR `to` = {$userinfo['id']}") or die(mysql_error());
	    if (mysql_num_rows($sql) > 0)
	    { 
	        mysql_query("DELETE FROM `pm` WHERE `id` = {$del_pm}") or die(mysql_error());
        }
	}
}

function messages_im_check() {
	$escaped_dialog = intval($_POST['dialog']);
	global $userinfo;
	//узнаем есть ли диалог с данным айди
	$sqld = mysql_query("SELECT * FROM dialogs WHERE id = {$escaped_dialog} ORDER BY id DESC") or die(mysql_error());
	# Получаем ассоциативный массив самого диалога (пользователи входящие в него и номер)
	$sql = mysql_query("SELECT * FROM pm WHERE dialog = {$escaped_dialog} AND `user_id` = {$userinfo['id']} ORDER BY id DESC LIMIT 1") or die(mysql_error());
	$rowd = mysql_fetch_assoc($sqld);
	if (mysql_num_rows($sqld) > 0 AND $rowd['from'] == $userinfo['id'] OR $rowd['to'] == $userinfo['id'] AND mysql_num_rows($sql) > 0) {
		$row = mysql_fetch_assoc($sql);
		if ($row['status'] == 1) { echo 'true'; }
	}
}

function messages_im_load() {
	# Получаем POST  данные и глобальные переменные
	$first_message_id = intval($_POST['first']);
	$escaped_dialog = intval($_POST['dialog']);
	global $userinfo, $us, $eng;
	# Существует ли диалог с данным ID
	$sql_d = mysql_query("SELECT * FROM dialogs WHERE id = {$escaped_dialog} ORDER BY id DESC") or die(mysql_error());
	# Если существует то
	if (mysql_num_rows($sql_d) > 0 AND $userinfo['group'] > 0) {
		# Получаем все сообщения из диалога которые больше $last_message_id
		$sql = mysql_query("SELECT * FROM `pm` WHERE `dialog` = {$escaped_dialog} AND `id` < $first_message_id ORDER BY `id` DESC LIMIT 30") or die(mysql_error());
		# Получаем ассоциативный массив самого диалога (пользователи входящие в него и номер)
		$rowd = mysql_fetch_assoc($sql_d);
		# Если я или собеседник имеют ID как у меня то
		if ($rowd['from'] == $userinfo['id'] OR $rowd['to'] == $userinfo['id']) {
			# Если сообщений в диалоге больше 0 то
			if (mysql_num_rows($sql) > 0) {
				# Задаем id блока в котором будут выводится сообщения
				$js = 'var pm = $("#allmessages");';
				# Создаем пустой массив сообщений
				$messages = array();
				# Получаем полный массив сообщений
				while($row = mysql_fetch_array($sql)) {
					$messages[] = array_merge(array(''.$row['text'].''), array(''.$row['id'].''), array(''.$row['date'].''), array(''.$row['status'].''), $us->array_user($row['user_id']));
				}
				# Получаем ID первого сообщения			
				$first_message_id = $messages[mysql_num_rows($sql)-1][1];
				# Выводим сообщения
				foreach ($messages as $value)
				{
					# Если это сообщение не мое и оно не просмотрено то делаем его просмотренным
					if($value[4] != $userinfo['id'] AND $value[3] == 0) {
						mysql_query("UPDATE pm SET status = 1 WHERE id = {$value[1]}");
					}
					# Дата отправления сообщения
					$date = $eng->showtime(strtotime($value['2']), 0); 				
					$js .= 'pm.append("<div class=\"messages msg'.$value[1].'\">';
					$js .= '<div ';
					if($value[4] != $userinfo['id']) { 
						$js .= 'class=\"msg_item\" onmouseover=\"$(this).animate({backgroundColor: \'rgba(242, 247, 249, 255)\'})\" '; 
					} else { 
						$js .= 'class=\"msg_item my_msg\" '; 
					}
					if ($value[3] == '0') { 
						$js .= 'style=\"background-color: #BDDBF9;\"'; 
					} else { 
						$js .= 'style=\"background-color: #F2F7F9;\"'; 
					}
					$js .= '\">';
					$js .= '<div class=\"mi_iwrap\"><img src=\"'.$us->avatar($value['4']).'\" class=\"mi_img\"></div>';
					$js .= '<div class=\"mi_cont\">';
					$js .= '<div class=\"mi_head\">';
					if ($value[4] == $userinfo['id'] OR $userinfo['group'] == 4) {
						$js .= '<p class=\"mi_date\">'.$date.' <a class=\"icon-remove\" href=\"javascript:void(0)\" onclick=\"delete_pm('.$value[1].')\"></a></p>';
					} else {
						$js .= '<p class=\"mi_date\">'.$date.'</p>';
					}
					$js .= '<a class=\"mi_author\" tarPOST=\"_blank\" href=\"'.BASEDIR.'profile_'.$value['4'].'\">'.mysql_real_escape_string($us->username($value['4'], 1)).'</a>';
					$js .= '</div>';
					$js .= '<div class=\"mi_body\">';
					$js .= '<div class=\"mi_text\">'.mysql_real_escape_string($eng->smiles($value['0'], 1, 0)).'</div>';
					$js .= '</div>';
					$js .= '</div>';
					$js .= '</div>';
					$js .= '</div>");';
				}
				# Записываем в переменную номер последнего сообщения
				$js .= "first_message_id = $first_message_id;";
				# Если сообщений меньше 30 то скрываем див
				if (mysql_num_rows($sql) < 30) {
					$js .= "first_message_id_end = true;";
				} else {
					$js .= "first_message_id_end = false;";
				}
				# Выводим результат
				echo $js;
			}
		}
	}
}