<?php if (!defined('BYESCL'))			exit('Нет доступа');

function format_serverlist($servers)
{
	if (!is_array($servers) || count($servers)<1)
		return "<b>Серверы отсутствуют</b>";
		
	$list = "";
	
	foreach ($servers as $name => $serv)
		$list .= "<label class='radio'><input type='radio' name='server' value='".$name."'> ".$serv['name']." (".$serv['ipport'].")</label>\r\n";
	
	return "\r\n".$list."\r\n";
}
	
function viewform()
{
	global $db, $eng, $us, $userinfo;
	
	if(!$userinfo['group'])
		return $result = $eng->msg("3", "Пройдите <a target='_blank' href='/reg'>Регистрацию</a>, чтобы приобрести админ/вип", "3");
	
	$gameservers = array();
	$sql = $db->query('SELECT * FROM `servers` WHERE `pay` = "1"');
	while($row = $db->fetch_array($sql))
		$gameservers[$row['id']] = array('name' => $row['hostname'], 'ipport' => $row['ip'].':'.$row['port']);
	
	$result = '<div id="buyerror"></div>
		<form class="form-horizontal" id="formbuy" method="POST" action="/modules/ajax/pay/create_order.php" autocomplete="off">
			<fieldset>
				<input type="hidden" name="act" value="get_status" />
			</fieldset>
			<fieldset>
			<div class="control-group">
				<label class="control-label">Выберите сервер: </label>
				<div class="controls">
					'.format_serverlist($gameservers).'
				</div>
			</div>
			</fieldset>
			<div id="buycontent"></div>
			<div id="loading" class="hide">
				<center><img src="/main/img/preloading.gif" /></center>
			</div>
		</form>';
	return $result;
}