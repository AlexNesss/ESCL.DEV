<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'pay';

#Заголовок страницы
$tpl->changeTitle('Покупка админ/вип');

#Навигация
$nav[] = array('url' => '/pay', 'name' => 'Покупка админ/вип');

#Подключаем файл функций
require_once "modules/pay/function.php";

if(empty($tpl->content))
{
	$javascript[] = 'pay.js';
	$tpl->content = viewform();
}