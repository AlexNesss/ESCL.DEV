<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'users';

#Заголовок страницы
$tpl->changeTitle('Список пользователей');
	
#Подключаем файл функций
require_once "modules/users/function.php";

if ($userinfo['group'])
{
    if (!empty($_POST['search']))
	{
		$search = $eng->input($_POST['search']);
		$tpl->content .= searchusers($search);
		$nav[] = array('name' => 'Список пользователей', 'url' => '/users');
		$nav[] = array('name' => 'Результаты поиска');
	} else {
		$nav[] = array('name' => 'Список пользователей');
		$tpl->content .= viewusers();
	}
} else
	$tpl->content .= $eng->msg(2, "Вы не авторизованы", 2); 