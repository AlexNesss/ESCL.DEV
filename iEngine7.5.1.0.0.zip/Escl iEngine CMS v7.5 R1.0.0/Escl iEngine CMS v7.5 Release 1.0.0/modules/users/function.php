<?php if (!defined('BYESCL'))			exit('Нет доступа');

# bymirror v2 
/*
Описание: Выводит полный список пользователей
Параметры: Остутствуют
*/
function viewusers()
{
	global $db, $us, $eng, $msg;
	
	$page_sel = (isset($_GET['page']) ? (intval($_GET['page'])-1) : 0);
	
	$sql = $db->query("SELECT * FROM `users` ORDER BY `id` ASC LIMIT ".abs($page_sel*20).",20");
	$result = '<form class="input-append pagination-centered" method="POST">
			<input type="text" name="search" class="span3" required>
			<input type="submit" value="Поиск" class="btn">
		</form><br />';
	if ($db->num_rows($sql)) 
	{	
		$groups = $us->gnamelist();
		$result .= '<table class="table table-bordered">
			<thead>
				<th>Ник</th>
				<th>Группа</th>
				<th>Скилл</th>
				<th>Действие</th>
			</thead>
		<tbody>';
		while($row = $db->fetch_array($sql)) 
		{
			$result .= '<tr>
							<td><img class="avatarmini" src="'.$us->avatar($row['id']).'"/> <a href="'.SITEDIR.''.BASEDIR.'/profile_'.$row['id'].'">'.$row['login'].'</td>
							<td>'.$groups[$row['group_id']].'</td> 
							<td>'.$us->skillname($row['skill_id'], 0).'</td> 
							<td><a href="'.SITEDIR.''.BASEDIR.'/createdialog_'.$row['id'].'">Отправить ЛС</a></td>
						</tr>';
		}
		$result .= '</tbody>
		</table>';
		$sql = $db->query("SELECT count(*) FROM `users`");
		$row = $db->fetch_row($sql);
		$total_rows = $row[0];
		$result .= $eng->pagination($total_rows, 20, $page_sel, '/users_page');
	} else
		$result .= $eng->msg(3, "На данной странице пользователей не найдено", 3); 
	return $result;
}

# bymirror v2 
/*
Описание: Находит пользователей
Параметры: $search (слово) - фраза для поиска
*/
function searchusers($search)
{
	global $db, $us, $eng, $msg;
	$search = $eng->input($search);
	$result = '<form class="input-append pagination-centered" method="POST">
		<input type="text" name="search" value="'.$search.'" class="span3" required>
		<input type="submit" value="Поиск" class="btn">
	</form><br />';
	if(strlen($search) < 3)
		return $result.$eng->msg(2, "Длина ника для поиска должна быть не менее 3 символов", 2);
	$sql = $db->query("SELECT * FROM `users` WHERE `login` LIKE '%{$search}%' ORDER BY `id` ASC LIMIT 50");
	$num_rows = $db->num_rows($sql);
	if ($num_rows) 
	{
		$groups = $us->gnamelist();
		$result .= '<div class="pagination-centered">Найдено записей: '.$num_rows.'</div><br />
			<table class="table table-bordered">
				<thead>
					<th>Ник</th>
					<th>Группа</th>
					<th>Действие</th>
				</thead>
			  <tbody>';
		while($row = $db->fetch_array($sql)) 
		{
			$result .= '<tr>
					<td><img class="avatarmini" src="'.$us->avatar($row['id']).'"/> <a href="'.SITEDIR.''.BASEDIR.'/profile_'.$row['id'].'">'.$row['login'].'</td> 
					<td>'.$groups[$row['group_id']].'</td>
					<td><a href="'.SITEDIR.''.BASEDIR.'/createdialog_'.$row['id'].'">Отправить ЛС</a></td>
				  </tr>';
		}
		$result .= '</tbody>
		</table>';
	} else 
		$result .= $eng->msg(3, "Результатов не найдено", 3);
	return $result;
}