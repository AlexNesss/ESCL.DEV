<?php if (!defined('BYESCL'))			exit('Нет доступа');


# bymirror v2 
/*
Описание: Выводит информацию о всех серверах
Параметры: Остутствуют
*/
function viewserver()
{
	global $db,$eng;
	$result = '';
	$stats = array();
	$hostnames = array();
	$sql = $db->query("SELECT * FROM `servers`");
	if($db->num_rows($sql) > 0)
	{
		while($row = $db->fetch_array($sql))
		{
			$query = $db->query("SELECT * FROM `stats` WHERE `server_id` = '{$row['id']}' ORDER BY `id` DESC LIMIT 288");
			while($row2 = $db->fetch_array($query))
			{
				$row2['map'] = trim($row2['map']);
				if($row2['map'] != '-' AND !empty($row2['map']))
					$stats[$row['id']]['map'][] = $row2['map'];
				$stats[$row['id']]['players'][] = $row2['players'];
				$stats[$row['id']]['maxplayers'][] = $row2['maxplayers'];
				$stats[$row['id']]['status'][] = $row2['status'];
				$stats[$row['id']]['timestamp'][] = $row2['timestamp'];
			}
			$stats[$row['id']]['hostname'] = $row['hostname'];
			$stats[$row['id']]['ip'] = $row['ip'].':'.$row['port'];
			$stats[$row['id']]['infomaxplayers'] = $row['maxplayers'];
			$stats[$row['id']]['infoplayers'] = $row['players'];
			$stats[$row['id']]['infomap'] = $row['map'];
			$hostnames[] = $row['hostname'];
		}
		$result .= '<ul id="myTab" class="nav nav-pills">';
		for($i = 0; $i<count($hostnames);$i++)
		{
			if($i==0)
				$result .= '<li class="active"><a href="#serv'.($i+1).'" data-toggle="tab">'.$hostnames[$i].'</a></li>';
			else
				$result .= '<li><a href="#serv'.($i+1).'" data-toggle="tab">'.$hostnames[$i].'</a></li>';
		}
		$result .= '</ul>';
		$result .= '<div id="myTabContent" class="tab-content">';
		$numq = 1;
		foreach($stats AS $key => $value)
		{
			if($numq==1)
				$active = 'fade in active';
			else
				$active = 'fade';
			$result .= '<div class="tab-pane '.$active.'" id="serv'.$numq.'">';
			$result .= '<h2>Информация о сервере: '.$stats[$key]['hostname'] .'</h2>';
			$minpl = min($stats[$key]['players']);
			$maxpl = max($stats[$key]['players']);
			$cuptime = array_count_values($stats[$key]['status']);
			if(isset($cuptime[0]))
			{
				$uptime = 100-round($cuptime[0]/count($stats[$key]['status'])*100);
			} else
				$uptime = 100;
			if($uptime == 100)
				$uptime = '<font color="green"><b>100</b></font>';
			else 
				$uptime = '<font color="red"><b>'.$uptime.'</b></font>';
			$result .= '<div class="alert alert-info alert-block">
			Адрес сервера: '.$stats[$key]['ip'].'<br />
			Карта: '.$stats[$key]['infomap'].'<br />
			Играет: '.$stats[$key]['infoplayers'].' из '.$stats[$key]['infomaxplayers'].'<br />
			Аптайм: '.$uptime.' % <a class="btn pull-right" href="'.SITEDIR.''.BASEDIR.'/stats_'.$key.'">Подробнее</a><br /><br />
			Минимальное количество игроков за сутки: '.$minpl.'<br />
			Максимальное количество игроков за сутки: '.$maxpl.' (слотов '.$stats[$key]['infomaxplayers'].')
			</div>';
			$cmaps = array_count_values($stats[$key]['map']);
			if(count($cmaps) > 0)
			{
				arsort($cmaps);
				$cmapsnum = 0;
				$msum = array_sum($cmaps);
				$result .= '<h4>Топ 10 карт за сутки</h4>
				<table class="table table-striped table-bordered table-condensed">
				<thead><tr><th width="50px">#</th><th>Карта</th><th width="180px">% от общего времени</th></tr></thead><tbody>';
				foreach ($cmaps AS $mkey => $mvalue)
				{
					$permap = round(($mvalue/$msum)*100);
					if($permap > 50)
						$permap = '<font color="red"><b>'.$permap.'</b></font>';
					$result .= '<tr><td>'.($cmapsnum+1).'</td><td>'.$mkey.'</td> <td>'.$permap .' %</td></tr>';
					$cmapsnum++;
					if($cmapsnum == 10)
						break;
				}
				$result .= '</tbody></table>';
			}
			$sql = $db->query("SELECT * FROM `stats_players` WHERE `server` = '{$key}' ORDER BY `frags` DESC LIMIT 10");
			if($db->num_rows($sql) > 0)
			{
				$num = 1;
				$result .= '<br /><h4>Топ 10 игроков</h4>'; 
				$result .= '<table class="table table-striped table-bordered table-condensed">
				<thead><tr><th>#</th><th>Ник</th><th>Фрагов</th><th>Сыграно</th><th width="120px">Коэффициент</th><th>Первый раз</th><th>Последний раз</th></tr></thead><tbody>';
				while($row = $db->fetch_array($sql))
				{	
					$maketime1 = round($row['time']/3600);
					$maketime2 = round($row['time']/60);
					
					if($maketime1 > 0)
						$time = $eng->declOfNum($maketime1, array('час','часа','часов'));
					else {
						$time = $eng->declOfNum($maketime2, array('минута','минуты','минут'));
					}
					if($row['lseen'] > (time()-300))
						$lseen = '<font color="green"><b>Играет</b></font>';
					else
						$lseen = $eng->showtime($row['lseen'], 1);
						
					if($maketime2 != 0)
						$coeff = round($row['frags']/$maketime2,2);
					else
						$coeff = 0;
					$fseen = $eng->showtime($row['fseen'], 1);
					$row['name'] = ($row['user_id'] ? '<a href="/profile_'.$row['user_id'].'">'.$row['name'].'</a>' : $row['name']);
					$result .= '<tr><td>'.$num.'</td><td>'.$row['name'].'</td><td>'.$row['frags'].'</td><td>'.$time.'</td><td>'.$coeff.'</td><td>'.$fseen.'</td><td>'.$lseen.'</td></tr>';
					$num++;
				}
				$result .= '</tbody></table>';
			}
			$result .= '</div>';
			$numq++;
		}
		$result .= '</div>';
	}
	return $result;
}

# bymirror v2 
/*
Описание: Выводит информацию о конкретном сервере
Параметры: Остутствуют
*/
function viewoneserver($serverid)
{
	global $db,$eng,$msg,$nav;
	$serverid = intval($serverid);
	$result = '';
	$stats = array();
	$sql = $db->query("SELECT * FROM `servers` WHERE `id` = '{$serverid}'");
	if($db->num_rows($sql) > 0)
	{
		while($row = $db->fetch_array($sql))
		{
			$query = $db->query("SELECT * FROM `stats` WHERE `server_id` = '{$serverid}' ORDER BY `id` DESC LIMIT 288");
			while($row2 = $db->fetch_array($query))
			{
				$row2['map'] = trim($row2['map']);
				if($row2['map'] != '-' AND !empty($row2['map']))
					$stats[$row['id']]['map'][] = $row2['map'];
				$stats[$row['id']]['players'][] = $row2['players'];
				$stats[$row['id']]['maxplayers'][] = $row2['maxplayers'];
				$stats[$row['id']]['status'][] = $row2['status'];
				$stats[$row['id']]['timestamp'][] = $row2['timestamp'];
			}
			$stats[$row['id']]['hostname'] = $row['hostname'];
			$stats[$row['id']]['ip'] = $row['ip'].':'.$row['port'];
			$stats[$row['id']]['infomaxplayers'] = $row['maxplayers'];
			$stats[$row['id']]['infoplayers'] = $row['players'];
			$stats[$row['id']]['infomap'] = $row['map'];
			$nav[] = array('name' => $row['hostname']);
		}
		
		foreach($stats AS $key => $value)
		{
			$result .= '<h2>Информация о сервере: '.$stats[$key]['hostname'] .'</h2>';
			$minpl = min($stats[$key]['players']);
			$maxpl = max($stats[$key]['players']);
			$cuptime = array_count_values($stats[$key]['status']);
			if(isset($cuptime[0]))
			{
				$uptime = 100-round($cuptime[0]/count($stats[$key]['status'])*100);
			} else
				$uptime = 100;
			if($uptime == 100)
				$uptime = '<font color="green"><b>100</b></font>';
			else 
				$uptime = '<font color="red"><b>'.$uptime.'</b></font>';
			$result .= '<div class="alert alert-info alert-block">
			Адрес сервера: '.$stats[$key]['ip'].'<br />
			Карта: '.$stats[$key]['infomap'].'<br />
			Играет: '.$stats[$key]['infoplayers'].' из '.$stats[$key]['infomaxplayers'].'<br />
			Аптайм: '.$uptime.' %<br /><br />
			Минимальное количество игроков за сутки: '.$minpl.'<br />
			Максимальное количество игроков за сутки: '.$maxpl.' (слотов '.$stats[$key]['infomaxplayers'].')
			</div>';
			$cmaps = array_count_values($stats[$key]['map']);
			if(count($cmaps) > 0)
			{
				arsort($cmaps);
				$cmapsnum = 0;
				$msum = array_sum($cmaps);
				$result .= '<h4>Топ 20 карт за сутки</h4>
				<table class="table table-striped table-bordered table-condensed">
				<thead><tr><th width="50px">#</th><th>Карта</th><th width="180px">% от общего времени</th></tr></thead></body>';
				foreach ($cmaps AS $mkey => $mvalue)
				{
					$permap = round(($mvalue/$msum)*100);
					if($permap > 50)
						$permap = '<font color="red"><b>'.$permap.'</b></font>';
					$result .= '<tr><td>'.($cmapsnum+1).'</td><td>'.$mkey.'</td> <td>'.$permap .' %</td></tr>';
					$cmapsnum++;
					if($cmapsnum == 20)
						break;
				}
				$result .= '</tbody></table>';
			}
			if (isset($_GET['page'])) $page_sel=(intval($_GET['page'])-1); else $page_sel=0;
			$sql = $db->query("SELECT * FROM `stats_players` WHERE `server` = '{$key}' ORDER BY `frags` DESC LIMIT ".abs($page_sel*100).",100");
			if($db->num_rows($sql) > 0)
			{
				if($page_sel == 0)
					$num = 1;
				else 
					$num = ($page_sel*100+1);
				$result .= '<br /><h4>Топ игроков с '.$num.' по '.($num+99).'</h4>'; 
				$result .= '<table class="table table-striped table-bordered table-condensed">
				<thead><tr><th>#</th><th>Ник</th><th>Фрагов</th><th>Сыграно</td><th width="120px">Коэффициент</th><th>Первый раз</th><th>Последний раз</th></tr></thead><tbody>';
				while($row = $db->fetch_array($sql))
				{	
					$maketime1 = round($row['time']/3600);
					$maketime2 = round($row['time']/60);
					
					if($maketime1 > 0)
						$time = $eng->declOfNum($maketime1, array('час','часа','часов'));
					else {
						$time = $eng->declOfNum($maketime2, array('минута','минуты','минут'));
					}
					if($row['lseen'] > (time()-300))
						$lseen = '<font color="green"><b>Играет</b></font>';
					else
						$lseen = $eng->showtime($row['lseen'], 1);
						
					if($maketime2 != 0)
						$coeff = round($row['frags']/$maketime2,2);
					else
						$coeff = 0;
					$fseen = $eng->showtime($row['fseen'], 1);
					$row['name'] = ($row['user_id'] ? '<a href="/profile_'.$row['user_id'].'">'.$row['name'].'</a>' : $row['name']);
					$result .= '<tr><td>'.$num.'</td><td>'.$row['name'].'</td><td>'.$row['frags'].'</td><td>'.$time.'</td><td>'.$coeff.'</td><td>'.$fseen.'</td><td>'.$lseen.'</td></tr>';
					$num++;
				}
				$result .= '</tbody></table>';
			} else 
				$result .= $eng->msg(3, "Игроков на данной странице не найдено", 3);
			$sql = $db->query("SELECT count(*) FROM `stats_players` WHERE `server` = '{$key}'");
			$row = $db->fetch_row($sql);
			$total_rows = $row[0];
			$result .= $eng->pagination($total_rows, 100, $page_sel, '/stats_'.$key.'_page');
		}
	}
	return $result;	
}