<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'stats';

#Заголовок страницы
$tpl->changeTitle('Статистика');
	
#Подключаем файл функций
require_once "modules/stats/function.php";

if($userinfo['group'] == 4 AND isset($_GET['val']))
{
	$nav[] = array('name' => 'Присваивание профиля');
	if(!empty($_POST['uid']) AND !empty($_POST['name']))
	{
		$uid = intval($_POST['uid']);
		$uname = mysql_real_escape_string($_POST['name']);
		$db->query("UPDATE `stats_players` SET `user_id` = '{$uid}' WHERE `name` = '{$uname}'");
		$tpl->content .= '<div class="alert alert-success"><b>iE7_ID привязан УСПЕШНО!</b></br>Игровой профиль был присвоен</br>Ник в игре: <b>'.htmlspecialchars($uname, ENT_QUOTES).'</b></br>ID пользователя: <b>'.$uid.'</b></div>';
	} else {
		$tpl->content .= '<form method="POST" class="form-horizontal">
		  <div class="control-group">
			<label class="control-label">Ник в игре:</label>
			<div class="controls">
			  <input type="text" name="name" >
			</div>
		  </div>
		  <div class="control-group">
			<label class="control-label">ID на сайте:</label>
			<div class="controls">
			  <input type="text" name="uid">
			</div>
		  </div>
		  <div class="control-group">
			<div class="controls">
			  <button type="submit" class="btn">Отправить</button>
			</div>
		  </div>
		</form>';
	}
	
} else if(!empty($_GET['id']))
{
	$nav[] = array('name' => 'Статистика', 'url' => '/stats');
	$tpl->content .= viewoneserver($_GET['id']);
} else {
	$nav[] = array('name' => 'Статистика');
	$tpl->content .= viewserver();
}