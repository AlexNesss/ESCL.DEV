<?php if (!defined('BYESCL'))			exit('Нет доступа');
ini_set('pcre.backtrack_limit', 1024*1024);

# Часовой пояс
date_default_timezone_set('Europe/Moscow');

function viewbans($id)
{
	global $db,$userinfo,$us,$eng;
	
	$page_sel = (isset($_GET['page']) ? (intval($_GET['page'])-1) : 0);
	
	$sql = $db->query("SELECT * FROM `servers` WHERE `id` = '{$id}'");
	
	if(!$db->num_rows($sql))
		return $eng->msg(2,'Сервер не найден', 2);
		
	$row = $db->fetch_array($sql);
	
	$ip = $row['ip'].':'.$row['port'];
	
	$sql = $db->query("SELECT * FROM `amx_bans` WHERE `server_ip` = '{$ip}' ORDER BY `ban_created` DESC LIMIT ".abs($page_sel*30).",30");

	if(!$db->num_rows($sql))
		return $eng->msg(2,'Банов не найдено', 2);
	
	$groups = $us->gnamelist();

	$result = '<table class="table table-bordered">
				<thead>
					<th><center><span class="text-error btn btn-block btn-inverse btn-small"><i class="icon-edit icon-white"></i> Разбан</span></center></th>
					<th><center><span class="text-error btn btn-block btn-inverse btn-small"><i class="icon-user icon-white"></i> Ник игрока</span></center></th>
					<th><center><span class="text-error btn btn-block btn-inverse btn-small"><i class="icon-star-empty icon-white"></i> Администратор</span></center></th>
					<th><center><span class="text-error btn btn-block btn-inverse btn-small"><i class="icon-tasks icon-white"></i> STEAM:ID игрока</span></center></th>
					<th><center><span class="text-error btn btn-block btn-inverse btn-small"><i class="icon-globe icon-white"></i> IP игрока</span></center></th>
					<th><center><span class="text-error btn btn-block btn-inverse btn-small"><i class="icon-comment icon-white"></i> Причина</span></center></th>
					<th><center><span class="text-error btn btn-block btn-inverse btn-small"><i class="icon-fire icon-white"></i> Забанен на</span></center></th>
				</thead>
			<tbody>';
	$num = 1;
	while($row = $db->fetch_array($sql))
	{
	$unban = $row['ban_length'];
	if($unban == 1440) {$unban = $unban/1440 . " день";}
	if($unban >= 10080) {$unban = $unban/1440 . " дней";}
	if($unban == 5) {$unban = "5 минут";}
	if($unban == 30) {$unban = "30 минут";}
	if($unban == 60) {$unban = $unban/60 . " час";}
	if($unban == 120) {$unban = $unban/60 . " часа";}
	if($unban == 180) {$unban = $unban/60 . " часа";}
	if($unban == 300) {$unban = $unban/60 . " часов";}
	if($unban == 720) {$unban = $unban/60 . " часов";}
	if (intval($row['ban_length']) == 0) {$unban = "Навсегда";}
	if (intval($row['ban_length']) == -1) {$unban = "Разбанен";}
	$blablabla = $row['ban_length'];
	if($blablabla == 0) { $blablabla = "background-color: #DDC2C2;margin-bottom:20px;"; }
	if($blablabla == -1) { $blablabla = "background-color: #CFDDC2;margin-bottom:20px;"; }
			$result .= "<tr>
				<td><center><a class='btn btn-mini' href='/unban.php?act=create'>Подать заявку</a></center></td>
				<td><span class='label label-inverse'>{$row['player_nick']}</span></td>
				<td><span class='label label-warning'>{$row['admin_nick']}</span></td> 
				<td><center>{$row['player_id']}</center></td>
				<td><center>{$row['player_ip']}</center></td>
				<td><span class='label label-info'>{$row['ban_reason']}</span></td>
				<td><span class='label label-important'>{$unban}</span></td>
			</tr>";	
	$num++;
	}
	$result .= '</tbody>
	</table>';
	
	$sql = $db->query("SELECT count(*) FROM `amx_bans` WHERE `server_ip` = '{$ip}'");
	$row = $db->fetch_row($sql);
	$total_rows = $row[0];
	$result .= $eng->pagination($total_rows, 30, $page_sel, '/bans_'.$id.'_page');		
	
	return $result;
}