<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'bans';

#Заголовок страницы
$tpl->changeTitle('Банлист / Name of project');
	
$nav[] = array('name' => 'Банлист / Name of project');
		
#Подключаем файл функций
require_once "modules/bans/function.php";

if(!empty($_GET['id']))
{
	$id = intval($_GET['id']);
	$tpl->content .= viewbans($id);	
} else
	$tpl->content .= $eng->msg(2,'Сервер не найден', 2);