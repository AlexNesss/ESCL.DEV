<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'news';

#Заголовок страницы
$tpl->changeTitle('Новости');

#Навигация
$nav[] = array('url' => '/news', 'name' => 'Новости');

#Подключаем файл функций
require_once "modules/news/function.php";

#Получаем $_GET
if(!empty($_GET['id']))
	$newsid = intval($_GET['id']);
	
#Присутствует ли $_POST запрос
if($userinfo['group'] AND !empty($_POST))
	require_once "modules/news/action.php";

#Если переменная $tpl->content пустая то делаем дальнейшие действия
if(empty($tpl->content))
{
	#Подключаем JS
	$javascript[] = 'autoresize.jquery.js';
	
	#Редактирование сообщения
	if(!empty($newsid) AND !empty($_GET['postid'])) 
	{
		$getsmiles = $eng->getsmiles();
		$postid = intval($_GET['postid']);
		$tpl->content = $tpl->parse("news/editnews.tpl",editpostnews($postid));
	#Страница новости
	} else if(!empty($newsid)) {
		$getsmiles = $eng->getsmiles();
		$tpl->content = $tpl->parse("news/viewnews.tpl",viewnews($newsid));
	#Список новостей
	} else
		$tpl->content = $tpl->parse("news/listnews.tpl",listnews());
}