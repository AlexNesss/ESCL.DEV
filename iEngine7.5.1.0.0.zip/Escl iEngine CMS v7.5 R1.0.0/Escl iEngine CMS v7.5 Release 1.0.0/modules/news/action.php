<?php if (!defined('BYESCL'))			exit('Нет доступа');

switch($_POST){
 case !empty($_POST['id_del']):
	#Удаление комментария новости
    $del_id = intval($_POST['id_del']);
	$sql = $db->query("SELECT * FROM `news_com` WHERE `id` = '{$del_id}' ORDER BY `id` DESC");
	$row = $db->fetch_array($sql);
	if ($db->num_rows($sql) AND ($userinfo['id'] == $row['user_id'] OR $us->agsearch('newsmsgdel')))
	{
        $sql = $db->query("DELETE FROM `news_com` WHERE `id` = '{$del_id}'");
		$eng->log("[Новости] В " . date('H:i:s d.m.Y') . " удален комментарий пользователем № ".$userinfo['id']."\n\n", "news");	
	}
	break;
 case !empty($_POST['input_text']):
 	if ($us->agsearch('newsmsg'))
	{
		#Добавление комментария
		$text = $eng->input($_POST['input_text']);
		$sql = $db->query("SELECT * FROM `news` WHERE `id` = '{$newsid}'");
		if ($db->num_rows($sql) > 0)
			$sql = $db->query("INSERT INTO `news_com` (`id` ,`news_id` ,`user_id`, `text`, `date`) VALUES (NULL ,  '{$newsid}',  '{$userinfo['id']}',  '{$text}',  '".time()."')");
			$eng->log("[Новости] В " . date('H:i:s d.m.Y') . " добавлен комментарий пользователем № ".$userinfo['id'].": [ Новость № ".$newsid." ]\n\n", "news");
	}
	break;
 case (!empty($_POST['edit_text']) AND !empty($_POST['postid'])):
	#Редактирование комментария
	$postid = intval($_POST['postid']);
	$text = $eng->input($_POST['edit_text']);
	$sql = $db->query("SELECT * FROM `news` WHERE `id` = '{$newsid}'");
	if ($db->num_rows($sql) > 0)
		$sql = $db->query("UPDATE `news_com` SET `text` = '{$text}' WHERE `id` = '{$postid}'");
	header("Refresh:2; url=".SITEDIR."".BASEDIR."/news_".$newsid."#form_msg");
	$nav[] = array('name' => 'Действие');
	$tpl->content .= $eng->msg("1", "Комментарий успешно изменен", "1");	
	break;
}