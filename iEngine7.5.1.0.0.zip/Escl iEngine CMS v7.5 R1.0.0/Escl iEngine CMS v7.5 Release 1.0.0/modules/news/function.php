<?php if (!defined('BYESCL'))			exit('Нет доступа');

/*
Описание: Выводит полный список новостей
Параметры: Остутствуют
*/
function listnews() 
{
	global $db, $eng, $us;
	
	$page_sel = (isset($_GET['page']) ? (intval($_GET['page'])-1) : 0);
	
	$sql = $db->query("SELECT * FROM `news` ORDER BY `id` DESC LIMIT ".abs($page_sel*20).", 20");
	
	if ($db->num_rows($sql)) 
	{
		$news = array();
		$count = array();
		$prepareusers = array();
		$msgnum = array();
		
		while($row = $db->fetch_array($sql)) 
		{
			$news[] = $row;
			$count[] = $row['id'];
			$prepareusers[] = $row['user_id'];
        }
		
		$users = $us->ausers($prepareusers, 0);
		$count = implode(',', $count);
		$sql_count = $db->query("SELECT `news_id`, count(*) AS `count` FROM `news_com` WHERE `news_id` IN({$count}) GROUP BY `news_id`");
		
		
		while($row_count = $db->fetch_array($sql_count)) 
			$msgnum[$row_count['news_id']] = $row_count['count'];
			
		foreach($news AS $key => $value) 
		{
		    $value['date'] = $eng->showtime($value['date'], 1);
			$value['com'] = (isset($msgnum[$value['id']]) ? $msgnum[$value['id']] : 0);	
			$value['login'] = $users[$value['user_id']];				
			$result['news'][] = $value;
		}
		
		$sql = $db->query("SELECT count(*) FROM `news`");
        $row = $db->fetch_row($sql);
        $total_rows = $row[0];
		$result['pagination'] = $eng->pagination($total_rows, 20, $page_sel, '/news_page');
	} else
		$result['infomsg'] = $eng->msg("3", "Новостей не найдено", "3");
		
	return $result;
}

# bymirror v2 
/*
Описание: Вывод определенной новости
Параметры: Остутствуют
*/
function viewnews($newsid) 
{
	global $db, $eng, $us, $userinfo, $getsmiles, $tpl;
	
	$newsid = intval($newsid);
	$sql = $db->query("SELECT * FROM `news` WHERE `id` = '{$newsid}'");
	
	if ($db->num_rows($sql)) 
	{
		$row = $db->fetch_array($sql);
		
		$tpl->changeTitle($row['name']);
		
		$result['name'] = $row['name'];
		$result['text'] = $row['text'];
		$result['newsid'] = $newsid;
		
		$sql = $db->query("SELECT * FROM `news_com` WHERE `news_id` = '{$newsid}'");
		
		if ($us->agsearch('newsmsg'))
		{
			$result['postmsg'] = true;
			$result['bbpanel'] = file_get_contents('tpl/other/bbnews.txt');
			$result['smiles'] = $eng->viewsmiles($getsmiles['img'], 'InsertSmile');
		}
		
		if ($db->num_rows($sql)) 
		{
			$page_sel = (isset($_GET['page']) ? (intval($_GET['page'])-1) : 0);
			$sql = $db->query("SELECT * FROM `news_com` WHERE `news_id` = '{$newsid}' ORDER BY `id` DESC LIMIT ".abs($page_sel*20).",20");
			if ($db->num_rows($sql)) 
			{
				$comments = array();
				$prepareusers = array();
				while($row = $db->fetch_array($sql)) 
				{
					$comments[] = $row;
					$prepareusers[] = $row['user_id'];
				}
				$users = $us->ausers($prepareusers, 1);
				foreach($comments AS $key => $value) 
				{
					$result['comnews'][] = array('id' => $value['id'],
												 'user_id' => $value['user_id'],
												 'login' => $users[$value['user_id']],		
												 'avatar' => $us->avatar($value['user_id']),
												 'date' => $eng->showtime($value['date'], 1),
												 'text' => replacenews($eng->replace_smiles($value['text'], $getsmiles['search'], $getsmiles['replace'])),
												 'deledit' => ($us->agsearch('newsmsgdel') OR ($userinfo['group'] > 0 AND $value['user_id'] == $userinfo['id'])));
				}
			} else 
				$result['infomsg'] .= $eng->msg("3", "Комментариев на данной странице нет", "3");
				
			$sql = $db->query("SELECT count(*) FROM `news_com` WHERE `news_id` = '{$newsid}'");
			$row = $db->fetch_row($sql);
			$total_rows = $row[0];
			$result['pagination'] = $eng->pagination($total_rows, 20, $page_sel, '/news_'.$newsid.'_page');
		}
	} else
		$result['infomsg'] = $eng->msg("2", "Новость не найдена", "2");
	
	return $result;
}
 
# bymirror v2 
/*
Описание: Форма редактирование комментария
Параметры: $postid (число)   - номер комментария
*/	
function editpostnews($postid) 
{
	global $db, $eng, $getsmiles, $nav;
	
	$postid = intval($postid);
	
	$sql = $db->query("SELECT * FROM `news_com` WHERE `id` = '{$postid}'");
	
	if($db->num_rows($sql)) 
	{
		$nav[] = array('name' => 'Редактирование комментария');
		$row = $db->fetch_array($sql);
		$result = array('bbpanel' => file_get_contents('tpl/other/bbnews.txt'),
						'smiles' => $eng->viewsmiles($getsmiles['img'], 'InsertSmile'),
						'text' => $eng->editinput($row['text']),
						'id' => $row['id'],
						'news_id' => $row['news_id']);
	} else
		$result['infomsg'] = $eng->msg("2", "Комментарий не найден", "2");
		
	return $result;
}

# bymirror v2 
/*
Описание: Замена тегов в комментариях к новостям
Параметры: $text (текст)   - текст сообщения
*/	
function replacenews($text) 
{
	$str_search = array(
		"#\[b\](.+?)\[\/b\]#is",
		"#\[i\](.+?)\[\/i\]#is",
		"#\[u\](.+?)\[\/u\]#is",
		"#\[url=((?:http|https):\/\/[^\s]+)\](.+?)\[\/url\]#is",
		"#\[url\]((?:http|https):\/\/[^\s]+)\[\/url\]#is",
		"#\[img\](https?://.*?\.(?:jpg|jpeg|gif|png|bmp))\[\/img\]#is",
		"#\[size=([1-9]|1[0-9]|20)\](.+?)\[\/size\]#is",
		"#\[color=(\#[0-9A-F]{6}|[a-z]+)\](.*?)\[\/color\]#is"
	);
	$str_replace = array(
		"<b>\\1</b>",
		"<i>\\1</i>",
		"<span style='text-decoration:underline'>\\1</span>",
		"<a rel='nofollow' target='_blank' href='\\1'>\\2</a>",
		"<a rel='nofollow' target='_blank' href='\\1'>\\1</a>",
		'<a class="fancybox" rel="group" href="\\1"><img class="fancyimg" src="\\1" alt="Изображение" /></a>',
		"<span style='font-size:\\1px'>\\2</span>",
		"<span style='color:\\1'>\\2</span>"
	);
	
	return preg_replace($str_search, $str_replace, $text);
}