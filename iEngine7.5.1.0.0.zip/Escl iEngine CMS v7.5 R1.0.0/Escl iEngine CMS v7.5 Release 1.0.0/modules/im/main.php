<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'im';

#Заголовок страницы
$tpl->changeTitle('Личные сообщения');
	
#Подключаем файл функций
require_once "modules/im/function.php";

#Необходимые переменные
if (!empty($_GET['dialog']))
    $escaped_dialog = intval($_GET['dialog']);

if($userinfo['group'] AND $us->agsearch('im'))
{
	$getsmiles = $eng->getsmiles();
	if(!empty($_GET['todialog']))
	{
		$nav[] = array('name' => 'Личные сообщения', 'url' => '/im');
		$tpl->content .= todialog($_GET['todialog']);	
	} else if(!empty($_GET['dialog']))
	{
		if(isset($_GET['addusers']))
		{
			$nav[] = array('name' => 'Личные сообщения', 'url' => '/im');
			$tpl->content .= addtodialog($_GET['dialog']);	
		} else {
			$javascript[] = 'im.js';
			$nav[] = array('name' => 'Личные сообщения', 'url' => '/im');
			$tpl->content .= viewdialog($_GET['dialog']);	
		}		
	} else if(isset($_GET['act']) AND $_GET['act'] = 'create' AND !empty($_GET['type'])) {
		$nav[] = array('name' => 'Личные сообщения', 'url' => '/im');
		$nav[] = array('name' => 'Создание беседы');
		$tpl->content .= createdialog($_GET['type']);	
	} else {
		$nav[] = array('name' => 'Личные сообщения');
		$tpl->content .= listmessages();
	}
} else
	$tpl->content .= $eng->msg(2,'Вы не авторизованы, либо у вас нет прав доступа', 2);
?>