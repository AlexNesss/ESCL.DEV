<?php if (!defined('BYESCL'))			exit('Нет доступа');

# bymirror v2 
/*
Описание: Переход к диалогу
Параметры: $user_id (число) - к беседе с кем переходим
*/
function todialog($user_id) 
{
	global $db,$userinfo,$eng;
	
	$id = intval($user_id);
	if($id == $userinfo['id'])
		$result = '<div class="alert alert-error"><b>Ошибка!</b></br>Вы не можете перейти в диалог с самим собой</div>';
	else {
		$sql = $db->query("SELECT * FROM `dialogs` WHERE (`from` = '{$userinfo['id']}' AND `invites` = '{$id}') OR (`from` = '{$id}' AND `invites` = '{$userinfo['id']}')");
		if($db->num_rows($sql) > 0)
		{
			$row = $db->fetch_array($sql);
			header("Location: ".SITEDIR."".BASEDIR."/dialog_".$row['id']."");
		} else {
			$sql = $db->query("SELECT count(*) AS `count` FROM `users` WHERE `id` = '{$id}'");
			$row = $db->fetch_array($sql);
			if($row['count'] == 1)
			{
				$sql = $db->query("INSERT INTO `dialogs` (`id`, `from`, `invites`, `lastmsg`, `deleted`, `timestamp`, `count`, `title`, `type`) VALUES (NULL, '{$userinfo['id']}', '{$id}', '0', '', '', '2', '', 'dialog')");
				header("Location: ".SITEDIR."".BASEDIR."/dialog_".mysql_insert_id()."");
			} else
				$result = '<div class="alert alert-error"><b>Ошибка!</b></br>Пользователь не существует</div>';
		}
	}
	return $result;	
}

# bymirror v2 
/*
Описание: Создание диалога или диалога
Параметры: $type (число) - тип диалога
*/
function createdialog($type) 
{
	global $db,$userinfo;
	if($type == 1)
	{
		if(!empty($_POST['numusers']))
		{
			$id = intval($_POST['numusers']);
			if($id == $userinfo['id'])
				$result = '<div class="alert alert-error"><b>Ошибка!</b></br>Вы не можете создать диалог с самим собой</div>';
			else {
				$sql = $db->query("SELECT * FROM `dialogs` WHERE (`from` = '{$userinfo['id']}' AND `invites` = '{$id}') OR (`from` = '{$id}' AND `invites` = '{$userinfo['id']}')");
				if($db->num_rows($sql) > 0)
				{
					$row = $db->fetch_array($sql);
					header("Location: ".SITEDIR."".BASEDIR."/dialog_".$row['id']."");
				} else {
					$sql = $db->query("SELECT count(*) AS `count` FROM `users` WHERE `id` = '{$id}'");
					$row = $db->fetch_array($sql);
					if($row['count'] == 1)
					{
						$sql = $db->query("INSERT INTO `dialogs` (`id`, `from`, `invites`, `lastmsg`, `deleted`, `timestamp`, `count`, `title`, `type`) VALUES (NULL, '{$userinfo['id']}', '{$id}', '0', '', '', '2', '', 'dialog')");
						header("Location: ".SITEDIR."".BASEDIR."/dialog_".mysql_insert_id()."");
					} else
						$result = '<div class="alert alert-error"><b>Ошибка!</b></br>Пользователь не существует</div>';
				}
			}
		} else {
			$result = '<span class="span4"><h2>Создать новый диалог</h2>';
			$result .= '<form method="POST">
					Введите ID (номер) пользователя, которого бы вы хотели пригласить в диалог:<br />
					<div class="input-append">
					<input type="text" name="numusers" placeholder="1" autocomplete="off" required> <a target="_blank" href="'.SITEDIR.''.BASEDIR.'/users" class="btn btn-success"><i class="icon-search"></i></a>
					</div><br />
					<input class="btn btn-success" type="submit" value="Создать">
			</form>';
			$result .= '</span>';
		}		
	} else if($type == 2) {
		if(!empty($_POST['numusers']) AND !empty($_POST['titletalk']))
		{
			$nums = array_unique(explode(",", $_POST['numusers']));
			$count = count($nums);
			if($count == 0 OR $count > 4)
			    $result = '<div class="alert alert-error"><b>Ошибка!</b></br>Выбрано недопустимое количество пользователей</div>';
			else if (in_array($userinfo['id'], $nums))
				$result = '<div class="alert alert-error"><b>Ошибка!</b></br>Вы не можете пригласить самого себя</div>';
			else {
				$list = array();
				for($i = 0;$i < $count;$i++)
				{
					$list[] = intval($nums[$i]);
				}
				$nlist = implode(',', $list);
				$sql = $db->query("SELECT count(*) AS `count` FROM `users` WHERE `id` IN({$nlist})");
				$row = $db->fetch_array($sql);
				if($row['count'] == $count)
				{
					$titletalk = htmlspecialchars(mb_substr($_POST['titletalk'], 0, 20, 'UTF-8'));
					$timestamp = mb_substr(str_repeat(time().',', $count), 0, -1);
					$sql = $db->query("INSERT INTO `dialogs` (`id`, `from`, `invites`, `lastmsg`, `deleted`, `timestamp`, `count`, `title`, `type`) VALUES (NULL, '{$userinfo['id']}', '{$nlist}', '0', '', '{$timestamp}', '".($count+1)."', '{$titletalk}', 'talk');");
					header("Location: ".SITEDIR."".BASEDIR."/dialog_".mysql_insert_id()."");
				} else
					$result = '<div class="alert alert-error"><b>Ошибка!</b></br>Не все пользователи существуют</div>';
			}
		} else {
			$result = '<span class="span4"><h2>Создать новый диалог</h2>';
			$result .= '<form method="POST">
					Название диалога (до 20 символов):
					<input type="text" name="titletalk" placeholder="Новый диалог" autocomplete="off" required><br />
					Введите ID (номера) пользователей через запятую в поле ниже, которых бы вы хотели пригласить в диалог:<br />
					<div class="input-append">
					<input type="text" name="numusers" placeholder="1,2,3,4" autocomplete="off" required> <a target="_blank" href="'.SITEDIR.''.BASEDIR.'/users" class="btn btn-success"><i class="icon-search"></i></a>
					</div>
					<sup>* Максимальное количество участников - 4 человека</sup><br /><br />
					<input class="btn btn-success" type="submit" value="Создать">
			</form>';
			$result .= '</span>';
		}
	} else
		$result = '<div class="alert alert-error"><b>Ошибка!</b></br>Указанный тип диалога не существует</div>';
	return $result;
}

# bymirror v2 
/*
Описание: Добавление в диалог пользователей
Параметры: $id (число) - номер диалога
*/
function addtodialog($id) 
{
	global $db,$userinfo,$us,$nav,$eng;
	$result = '';
	$sql = $db->query("SELECT * FROM `dialogs` WHERE `id` = '{$id}' AND `type` = 'talk' AND `from` = '{$userinfo['id']}'");
	if($db->num_rows($sql) > 0)
	{
		$nav[] = array('name' => 'Управление беседой');
		$result .= $eng->msg(3,'В разработке', 3);
		$result .= '<span class="span4"><h2>Список участников</h2><div class="leftblock"><div class="bodyblock">';
		$row = $db->fetch_array($sql);
		$invites = explode(",", $row['invites']);
		$timestamp = explode(",", $row['timestamp']);
		$invusers = $us->ausers($invites, 1);
		$num = 0;
		$result .= '# &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ник<span class="pull-right">Присоединился</span><br />';
		foreach($invusers AS $key => $value)
		{
			$result .= '<input id="optionsCheckbox2" type="checkbox" name="ulist" value="'.$key.'" /> &nbsp;<img width="20px" src="'.$us->avatar($key).'" /> '.$value.' <span class="pull-right">'.$eng->showtime($timestamp[$num], 1).'</span><br />';
			$num++;
		}
		$result .= '</div></div><br /><input class="btn" onclick="delfind()" type="submit" value="Удалить выделенных из диалога"><br /><br /><input class="btn btn-danger" type="submit" value="Удалить диалог (Безвозвратно)"><br /><br /><a href="'.SITEDIR.''.BASEDIR.'/dialog_'.$id.'" style="font-weight: normal;" class="btn btn-warning"><i class="icon-circle-arrow-left"></i> Обратно в диалог</a></span>';
		if($row['count'] < 4)
		{
			$result .= '<span class="span4"><span class="span4"><h2>Добавить новых</h2>';
			$result .= '<form>
					Введите ID (номера) пользователей через запятую в поле ниже, которых бы вы хотели пригласить в диалог:<br />
					<div class="input-append">
					<input type="text" placeholder="1,2,3,4"/> <a target="_blank" href="'.SITEDIR.''.BASEDIR.'/users" class="btn btn-success"><i class="icon-search"></i></a>
					</div>
					<sup>* Максимальное количество участников - 4 человека</sup><br /><br />
					<input class="btn btn-success" type="submit" value="Добавить новых">
			</form>';
			$result .= '</span>';
		}
		/*$result .= '
		<script type="text/javascript">
		function delfind()
		{
			var radios = $(\'input:checked\');
			var values = new Array(); 
			for (var i = 0; i < radios.length; i++) {
				values[i] = radios[i].value;			
			}
			if(values == "")
			alert("Пусто")
			else
			alert(values)
			$.ajax({
				url: "/modules/ajax/im/send.php",
				dataType: "html",
				type: "POST",
				data: { 
					act: "im_post",
					dialog: dialog,
					text: $("#input_text").val()
				},
				success: function(data) {
					newLoad_im();		
				},
				beforeSend: function(xhr, opts){
					if(values == "")
					{
						alert("Пусто")
						xhr.abort();
					}
				},
				complete: function() {
					$("#input_text").val("");
					$("#input_text").focus();
				}
			});
		}
		</script>';*/
	} else
		$result = $eng->msg(2,'диалога не существует, либо у вас нет прав доступа', 2);
	return $result;
}

# bymirror v2 
/*
Описание: Просмотр диалога
Параметры: $id (число) - номер диалога
*/
function viewdialog($id) 
{
	global $db,$userinfo,$us,$eng,$getsmiles,$tpl,$nav;
	$id = intval($id);
	$result = '';
	$sql = $db->query("SELECT * FROM `dialogs` WHERE `id` = '{$id}' AND !FIND_IN_SET('{$userinfo['id']}',`deleted`) AND (`from` = '{$userinfo['id']}' OR FIND_IN_SET('{$userinfo['id']}',`invites`))");
	if($db->num_rows($sql) > 0)
	{
		#Делаем все лс прочитанными
		$db->query("UPDATE `pm` SET `status` = concat(`status`, ',{$userinfo['id']}') WHERE `dialog` = '{$id}' AND !FIND_IN_SET('{$userinfo['id']}',`status`)");
		$row = $db->fetch_array($sql);
		$type = $row['type'];
		if($type == 'dialog')
		{
			if($row['from'] == $userinfo['id'])
				$guest = $row['invites'];
			else
				$guest = $row['from'];
			$title = 'Диалог с '.$us->uname($guest);
		} else {
			$title = $row['title'];
			$invites = explode(",", $row['invites']);
			$invusers = $us->ausers($invites, 1);
			$viewinfotalk = implode(", ", $invusers);
		}
		$nav[] = array('name' => $title);
		$tpl->changeTitle($title.' &raquo; Личные сообщения');
		$query = "SELECT * FROM `pm` WHERE `dialog` = '{$id}' ORDER BY `id` DESC LIMIT 30"; 
		if($row['type'] == 'talk' AND $row['from'] != $userinfo['id'])
		{
			$talks = explode(",", $row['invites']);
			$tm = explode(",", $row['timestamp']);
			$find = array_search($userinfo['id'], $talks);
			$timeset = $tm[$find];
			$query = "SELECT * FROM `pm` WHERE `dialog` = '{$id}' AND `date` > '{$timeset}' ORDER BY `id` DESC LIMIT 30"; 
		}
		if($row['type'] == 'talk')
		{
			$result .= '<pre>В диалоге присутствуют: '.$viewinfotalk.' и вы';
			if($row['from'] == $userinfo['id'])
			{
					$result .= ' <a href="'.SITEDIR.''.BASEDIR.'/dialog_add_'.$id.'"><font class="pull-right" color="green">[Настройки]</a></font>';
			}
			$result .= '</pre>';
		}
		$sql = $db->query($query);
		if($us->agsearch('immsg'))
		$result .= '<div class="create_message">
		<form method="post" name="form_msg" id="form_msg">
			<div class="iwrap">
				<input autocomplete="off" maxlength="1000" id="input_text" name="input_text" type="text">
			</div>
			<div class="ibwrap">
				<input type="submit" class="btn btn-info" value="Отправить" />
				<p class="smiles">
					'.$eng->viewsmiles($getsmiles['img'], 'InsertSmile').'
				</p>
			</div>
		</form>
		<span style="color:red" id="input_textf"></span>
		</div>';
		$result .= '<script type="text/javascript">var dialog = '.$id.';</script>
		<div id="allmessages">';
		if($db->num_rows($sql) > 0)
		{
			$messages = array();
			$prepareusers = array();
			
			while($row = $db->fetch_array($sql))
			{
				$messages[] = $row;
				$prepareusers[] = $row['user_id'];
			}
			$users = $us->ausers($prepareusers, 1);
			foreach($messages AS $key => $value) 
			{
				$date = $eng->showtime($value['date'], 0); 				
				$result .= '
				<div id="'.$value['id'].'" class="messages"';
				$views = explode(",", $value['status']);
				if($type == 'talk' AND count($views) == 1)
					$result .= ' style="background-color: #BDDBF9;"';
				if($type == 'dialog' AND ($value['user_id'] == $userinfo['id'] AND count($views) == 1) OR ($value['user_id'] != $userinfo['id'] AND !array_key_exists($userinfo['id'], $views)))
					$result .= ' style="background-color: #BDDBF9;"';
				$result .= '>
					<div class="msg_item">
						<div class="mi_iwrap">
							<img src="'.$us->avatar($value['user_id']).'" class="mi_img">
						</div>
						<div class="mi_cont">
							<div class="mi_head">
								<p class="mi_date">';
								if($value['user_id'] == $userinfo['id'] OR $us->agsearch('im'))
									$result .= '<span class="icon-remove pmdel" onclick="delete_pm('.$value['id'].')"></span> ';
								$result .= $date.'</p>
								<a class="mi_author" target="_blank" href="'.SITEDIR.''.BASEDIR.'/profile_'.$value['user_id'].'">'.$users[$value['user_id']].'</a>
							</div>
							<div class="mi_body">
								<div class="mi_text">'.$eng->replace_smiles($value['text'], $getsmiles['search'], $getsmiles['replace']).'</div>
							</div>
						</div>
					</div>
				</div>';			
			}
			$result .= '</div>';
			if($db->num_rows($sql) == 30) 
			{
				$result .= '<div id="load">
				<span onclick="oldLoad_im()">Загрузить еще</span>
					<img src="'.IMG.'loading.gif" id="imgLoad">
				</div>';
			}
		} else
			$result .= '<div id="0" class="messages"></div>
			</div>';
	} else
		$result = '<div class="alert alert-error"><b>Ошибка!</b></br>Диалога не существует, либо у вас нет прав доступа</div>';
	return $result;
}

# bymirror v2 
/*
Описание: Вывод списка сообщений
Параметры: Остутствуют
*/
function listmessages() 
{
	global $db,$us,$eng,$userinfo,$getsmiles;
	if (isset($_GET['page'])) $page_sel=(intval($_GET['page'])-1); else $page_sel=0;
	$result = '<div class="pull-right">
						<a href="'.SITEDIR.''.BASEDIR.'/create_dialog"><button class="btn">Создать диалог</button></a> 
						<a href="'.SITEDIR.''.BASEDIR.'/create_talk"><button class="btn">Создать групповой диалог</button></a>
				   </div><br /><br />';
	$sql = $db->query("SELECT * FROM `dialogs` WHERE `lastmsg` != '0' AND !FIND_IN_SET('{$userinfo['id']}',`deleted`) AND (`from` = '{$userinfo['id']}' OR FIND_IN_SET('{$userinfo['id']}',`invites`)) ORDER BY `lastmsg` DESC LIMIT ".abs($page_sel*20).", 20");
	if ($db->num_rows($sql) > 0) 
	{
		$lastnum = array();
		$messages = array();
		$prepareusers = array();
		
		while($row = $db->fetch_array($sql))
		{
			$messages[$row['id']]['pm'] = $row;
			$lastnum[] = $row['lastmsg'];
			$prepareusers[] = $row['from'];
			$invites = explode(",", $row['invites']);
			if(count($invites) > 1)
			{
				for($i=0;$i<count($invites);$i++)
					$prepareusers[] = $invites[$i];
			} else 
				$prepareusers[] = $row['invites'];
		}
		
		$values = implode(",", $lastnum);
		$sql = $db->query("SELECT * FROM `pm` WHERE `id` IN ({$values}) ORDER BY `id` DESC");
		while($row = $db->fetch_array($sql))
			$messages[$row['dialog']]['msg'] = $row;
		$users = $us->ausers($prepareusers, 0);
		$result .= '<table id="pm_msg" class="table table-condensed table-striped">
					<thead class="table-bordered">
						<tr>
							<th width="170px">Пользователь</th>
							<th>Последний ответ</th>
						</tr>
					</thead>
					<tbody class="table-bordered">';
		foreach($messages AS $key => $value) 
		{
			if($value['pm']['type'] == 'dialog')
			{
				if($value['pm']['invites'] == $userinfo['id']) 
					$guest = $value['pm']['from'];
				else 
					$guest = $value['pm']['invites'];
				$leftitle = $users[$guest];
				$leftava = $us->avatar($guest);
			} else if($value['pm']['type'] == 'talk') {
				$leftitle = $value['pm']['title'];
				$leftava = IMG.'talk.png';
			}
			if(strlen($value['msg']['text']) > 60)
				$value['msg']['text'] = mb_substr($value['msg']['text'], 0, 60, 'UTF-8').' ...';
			$result .= '<tr data-href="'.SITEDIR.''.BASEDIR.'/dialog_'.$value['msg']['dialog'].'">
							<td scope="row"><a href="'.BASEDIR.'dialog_'.$value['msg']['dialog'].'"><img class="avatarmini" src="'.$leftava.'"/>'.$leftitle.'</a></td>
							<td';
							$explmsg = explode(',', $value['msg']['status']);
							if ($value['msg']['user_id'] != $userinfo['id'] AND !in_array($userinfo['id'], $explmsg))
								$result .= ' class="msginfo"';
							$result .= '><img class="avatarmini" src="'.$us->avatar($value['msg']['user_id']).'"/>'.$users[$value['msg']['user_id']].': '.$eng->replace_smiles($value['msg']['text'], $getsmiles['search'], $getsmiles['replace']).'</td>
						</tr>';
			
		}
		
		$result .= '</tbody>
		</table>';
		$sql = $db->query("SELECT count(*) FROM `dialogs` WHERE `lastmsg` != '0' AND !FIND_IN_SET('{$userinfo['id']}',`deleted`) AND `from` = '{$userinfo['id']}' OR FIND_IN_SET('{$userinfo['id']}',`invites`)");
        $row = $db->fetch_row($sql);
        $total_rows = $row[0];
		$result .= $eng->pagination($total_rows, 20, $page_sel, '/im_page');
	} else
		$result .= $eng->msg(3, "Сообщений не найдено", 3); 

	return $result;
}
?>