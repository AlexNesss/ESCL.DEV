<?php if (!defined('BYESCL'))			exit('Нет доступа');

if ($userinfo['id'] != $escaped_uid) {
	$sqlus = $db->query("SELECT * FROM `users` WHERE `id` = '{$escaped_uid}'");
	if (mysql_num_rows($sqlus)) {
		$sql = $db->query("SELECT * FROM dialogs WHERE `to` = '{$userinfo['id']}' AND `from` = '{$escaped_uid}' OR `to` = '{$escaped_uid}' AND `from` = '{$userinfo['id']}'");
		if (!mysql_num_rows($sql)) {
			$db->query("INSERT INTO `dialogs` (`id`, `from`, `to`) VALUES (NULL, '{$userinfo['id']}', '{$escaped_uid}')");
			$sql = $db->query("SELECT * FROM dialogs WHERE `to` = '{$userinfo['id']}' AND `from` = '{$escaped_uid}' OR `to` = '{$escaped_uid}' AND `from` = '{$userinfo['id']}'");
		}
		$row = mysql_fetch_assoc($sql);
		echo $eng->redirect("http://".$_SERVER['SERVER_NAME']."/dialog_".$row['id']."");
	}
} else
	echo $eng->redirect("http://".$_SERVER['SERVER_NAME']."/im");