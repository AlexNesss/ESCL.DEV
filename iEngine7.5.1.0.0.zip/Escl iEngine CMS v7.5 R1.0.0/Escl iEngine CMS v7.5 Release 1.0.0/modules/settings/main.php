<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'settings';

#Заголовок страницы
$tpl->changeTitle('Настройки');

if ($userinfo['group'] > 0)
{
	$nav[] = array('name' => '<a href="http://'.$_SERVER['SERVER_NAME'].'">Главная</a><span class="divider">/</span></li><li><a href="settings">Настройки</a>');
	# Удаление аватара
	if(isset($_POST['deleteavatar'])) {
		$filename = $_SERVER['DOCUMENT_ROOT'].'/main/avatar/'.$userinfo['id'].'.jpg';
		if (file_exists($filename)) {
			unlink($filename);
			$tpl->content .= $eng->msg("1", 'Изображение удалено', "1");
			$tpl->content .= '<meta http-equiv="refresh" content="2;URL=http://'.$_SERVER['SERVER_NAME'].'/settings">';
		}
	}
	# Загрузка аватара
	else if(!empty($_FILES['avatar'])){
		# Считаем количество ошибок
		$f_err     = 0; 
		# Разрешенные форматы изображения
		$types     = array('.jpg', '.JPG', '.jpeg');
		# Максимальный размер загружаемой картинки
		$max_size  = 5020500; 
		# Директория загрузки аватара
		$path      = 'main/avatar/';
		# Название файла
		$fname     = $_FILES['avatar']['name'];
		# Тип загружаемого файла
		$ext       = substr($fname, strpos($fname, '.'), strlen($fname) - 1);
		# Валидно ли название картинки
		if (!preg_match('/^[a-zA-Zа-яёА-ЯЁ0-9._ ]+$/i', $fname)) {
			$f_err++;
			$mess = 'Некорректное название картинки';
		} 		
		# Проверка формата
		if (!in_array($ext, $types)) {
			$f_err++;
			$mess = 'Загружаемая картинка не соответствует нужному формату!';
		}
		# Проверка размера файла
		if (filesize($_FILES['avatar']['tmp_name']) > $max_size) {
			$f_err++;
			$mess = 'Размер загружаемой картинки превышает 5 Mb';
		}

		# Если файл успешно прошел проверку перемещаем его в заданную директорию из временной
		if ($f_err == 0) {
			# Путь к загруженному файлу
			$source_src = $_FILES['avatar']['tmp_name'];
			# Получаем параметры загруженного файла
			$params = getimagesize($source_src);
			switch ($params[2]) {
				case 1:
					$source = imagecreatefromgif($source_src);
					break;
				case 2:
					$source = imagecreatefromjpeg($source_src);
					break;
			}
			# Миниатюра загруженного изображения
			$resource = imagecreatetruecolor(80, 80);
			imagecopyresampled($resource, $source, 0, 0, 0, 0, 80, 80, $params[0], $params[1]);
			imagejpeg($resource, $path . $userinfo['id'].".jpg", 100);
			# Права доступа
			chmod("$source_src", 0644);
			$tpl->content .= $eng->msg("1", 'Изображение загружено', "1");
			$tpl->content .= '<meta http-equiv="refresh" content="3;URL=http://'.$_SERVER['SERVER_NAME'].'/settings">';
		} else {
			$tpl->content .= $eng->msg("2", $mess, "2");
		}
	}
	# Изменение пароля пользователя
	else if (isset($_POST['password']) AND isset($_POST['password1']) AND isset($_POST['password2'])) {
		# Присваиваем переменным значение
		$password = $_POST['password'];
		$password1 = $_POST['password1'];
		$password2 = $_POST['password2'];
		# Хешируем пароли + делаем их безопасными (коряво, но как есть) 
		$mdPassword = md5(trim(htmlspecialchars(stripslashes($password))));
		$mdPassword1 = md5(trim(htmlspecialchars(stripslashes($password1))));
		$mdPassword2 = md5(trim(htmlspecialchars(stripslashes($password2))));
		# Создаем пустой массив ошибок
		$err = array();
		$sql1 = mysql_query("SELECT * FROM users WHERE `id`='{$userinfo['id']}'") or die(mysql_error());
		$row1 = mysql_fetch_assoc($sql1);
		$user_pass = $row1['password'];
		if ($mdPassword != $user_pass)
		{
			$err[] = 'Текущий пароль неверный';
		}
		# пароли не совпадают
		if ($mdPassword1 != $mdPassword2)
		{
			$err[] = 'Пароли не совпадают';
		}
		# проверка на длину пароля
		if(strlen($password1) < 6)
		{
			$err[] = 'Длина нового пароля должна быть не менее 6 символов';
		}
		# Если ошибок нет
		if(count($err) == 0) {
			$sql = mysql_query ("UPDATE `users` SET  `password` =  '{$mdPassword1}' WHERE id = '{$userinfo['id']}'");
			if ($sql)
			{
				$tpl->content .= $eng->msg("1", "Вы успешно сменили пароль. Через 5 секунд вы будете перемещены на главную, для повторной авторизации", "2");
				$redirect = '/logout';
			} else {
				$tpl->content .= $eng->msg("2", "Смена пароля не удалась", "2");
				$redirect = '/changepassword';
			}
		# Если ошибки есть
		} else {
			$errormsg = '';
			foreach($err AS $error)
			{
				$errormsg .= $error."<br>";
			}
			$tpl->content .= $eng->msg("2", $errormsg, "2");
			$redirect = '/changepassword';
		}
		$tpl->content .= '<meta http-equiv="refresh" content="3;URL=http://'.$_SERVER['SERVER_NAME'].''.$redirect.'">';
	}
	
	# Изменение данных пользователя
	else if (isset($_POST['login']) AND isset($_POST['email']) AND isset($_POST['name']) AND isset($_POST['nick']))	{
		# Присваиваем переменным значение
		$login = $_POST['login'];
	    $email = $_POST['email'];
        $name = $_POST['name'];
        $nick = $_POST['nick'];
		if (isset($_POST['steamid'])) { 
			$steamid = $_POST['steamid']; 
			$steamid = trim(htmlspecialchars(stripslashes($steamid)));
		}
        if (isset($_POST['vk'])) { 
			$vk = $_POST['vk']; 
			$vk = trim(htmlspecialchars(stripslashes($vk)));
		}
		# Делаем переменные безопасными для использования
		$login = trim(htmlspecialchars(stripslashes($login), ENT_QUOTES));
		$email = trim(htmlspecialchars(stripslashes($email), ENT_QUOTES));
		$name = trim(htmlspecialchars(stripslashes($name), ENT_QUOTES));
		$nick = trim(htmlspecialchars(stripslashes($nick), ENT_QUOTES));
		# Создаем пустой массив ошибок
		$err = array();
		# Все ли данные введены
		if (empty($email) OR empty($name) OR empty($nick) OR empty($login)) 
		{
			$tpl->content .= $eng->msg("2", "Вы ввели не всю информацию", "2"); 
			$tpl->content .= '<meta http-equiv="refresh" content="3;URL=http://'.$_SERVER['SERVER_NAME'].'/settings">';
		}
		# Есть ли пользователь с введенным логином
		$sql = mysql_query("SELECT * FROM users WHERE login = '{$login}'") or die(mysql_error());
		if ((mysql_num_rows($sql) > 0) && ($userinfo['login'] !== $login)) {
			$err[] = 'Введённый вами логин уже зарегистрирован';
		}
		# Есть ли пользователь с введенным почтовым ящиком
		$sql = mysql_query("SELECT id, email FROM users WHERE email='{$email}'") or die(mysql_error());
		$sql1 = mysql_query("SELECT * FROM users WHERE `id`='{$userinfo['id']}'") or die(mysql_error());
		$row1 = mysql_fetch_assoc($sql1);
		$user_mail = $row1['email'];
		if (mysql_num_rows($sql) > 0 AND $user_mail != $email) {
			$err[] = 'Введённый вами почтовый ящик уже зарегистрирован';
		}
		# Валиден ли логин
		if (!preg_match('/^[a-z0-9_+-\s]+$/i', $login) OR strlen($login) < 3 OR strlen($login) > 15) {
			$err[] = 'Логин не должен содержать запрещенные символы и его длина должна быть от 3 до 15 символов';
		} 
		# Валиден ли почтовый ящик
		if(!preg_match("/^[A-Z0-9._-]+@[A-Z0-9.-]{1,61}\.[A-Z]{2,6}$/i", $email))//if(!filter_var($email, FILTER_VALIDATE_EMAIL))
		{		
			$err[] = 'Формат почтового ящика не корректен';
		} 
		# Валидность SteamID
		if(!empty($steamid) AND !preg_match("/^STEAM_0:[01]:[0-9]{5,10}$/", $steamid)) 
		{
			$err[] = 'Неверный SteamID';
		}
		# Валидна ли ссылка на профиль в контакте
		if(!empty($vk) AND !preg_match("/http:\/\/vk\.com\/[a-zA-Z0-9_.]{1,40}$/", $vk)){ 
			$err[] = 'Формат ссылки на профиль ВКонтакте не корректен';
		}
		# Если ошибок нет
		if(count($err) == 0) {
			$sql = mysql_query ("UPDATE `users` SET  `login` =  '{$login}', `email` =  '{$email}', `name` =  '{$name}', `nick` =  '{$nick}', `steamid` =  '{$steamid}', `vk` =  '{$vk}' WHERE id = '{$userinfo['id']}'");
			if ($sql)
			{
				$tpl->content .= $eng->msg("1", "Ваши данные успешно обновлены", "1");
				$redirect = '/settings';
			} else {
				$tpl->content .= $eng->msg("2", "Данные не были обновлены", "2");
				$redirect = '/settings';
			}
		# Если ошибки есть
		} else {
			$errormsg = '';
			foreach($err AS $error)
			{
				$errormsg .= $error."<br>";
			}
			$tpl->content .= $eng->msg("2", $errormsg, "2");
			$redirect = '/settings';
		}
		$tpl->content .= '<meta http-equiv="refresh" content="3;URL=http://'.$_SERVER['SERVER_NAME'].''.$redirect.'">';
	} else if(isset($_POST['input_text'])) {
		$signature = mysql_real_escape_string($eng->stripinput($_POST['input_text']));
		$signature = substr($signature,0,300);
		$db->query("UPDATE  `users` SET  `signature` =  '{$signature}' WHERE `id` = {$userinfo['id']}");
		$tpl->content .=  $eng->msg("1", "Подпись успешно обновлена", "1"); 
		$tpl->content .=  '<meta http-equiv="refresh" content="2;URL=http://'.$_SERVER['SERVER_NAME'].'/settings">';
	} else {
		$filename = $_SERVER['DOCUMENT_ROOT'].'/main/avatar/'.$userinfo['id'].'.jpg'; 
		if (file_exists($filename)) {
			$tpl->content .=  '
			<legend>Установка аватара</legend>
			<div class="form-horizontal well">
				<form action="" method="post" enctype="multipart/form-data">
					<div class="control-group">
						<img style="-webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px;" src="'.$us->avatar($userinfo['id']).'"/>
						<input type="file" name="avatar" style="margin-left:10px;">
						<input type="submit" class="btn btn-info" value="Загрузить"></div>
				</form>
				<form action="" method="post">
				<input type="submit" class="btn btn-info" name="deleteavatar" value="Удалить"> <font color="red" style="margin-left:5px;">* Разрешено загружать аватар с расширением jpg, jpeg</font></form></div>';
		} else {
			$tpl->content .=  '
			<legend>Установка аватара</legend>
			<div class="form-horizontal well">
				<form action="" method="post" enctype="multipart/form-data">
					<div class="control-group">
						<img style="-webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px;" src="'.$us->avatar($userinfo['id']).'"/>
						<input type="file" name="avatar" style="margin-left:10px;">
						<input type="submit" class="btn btn-info" value="Загрузить"></div>
				</form>
				<form action="" method="post">
				<font color="red" style="margin-left:5px;">* Разрешено загружать аватар с расширением jpg, jpeg</font></form></div>';
		}
		
		$sql = mysql_query("SELECT * FROM `users` WHERE `id` = '{$userinfo['id']}'");
		$row = mysql_fetch_array($sql);
		$tpl->content .=  '<legend>Профиль</legend><form class="form-horizontal" action="" method="post" autocomplete="off">
		<div class="control-group">
			<label class="control-label" for="login">Логин: </label>
			<div class="controls">
				<input name="login" id="login" pattern="[A-Za-z0-9_+-\s]{3,}" type="text" size="15" maxlength="15" value="'.$row['login'].'" required>
			</div>
		</div>		
		<div class="control-group">
			<label class="control-label" for="email">Почтовый ящик: </label>
			<div class="controls">
				<input name="email" id="email" type="email" pattern="^[A-Za-z0-9](([_\.\-]?[a-zA-Z0-9]+)*)@([A-Za-z0-9]+)(([\.\-]?[a-zA-Z0-9]+)*)\.([A-Za-z]{2,})$" size="15" value="'.$row['email'].'" required> 
			</div>
		</div>
		<div class="control-group">
			<label class="control-label" for="name">Имя: </label>
			<div class="controls">
				<input name="name" id="name" type="text" size="15" maxlength="15" value="'.$row['name'].'" required>
			</div>
		</div>
		<div class="control-group">
			<label class="control-label" for="nick">Ник в игре: </label>
			<div class="controls">
				<input name="nick" id="nick" type="text" size="15" maxlength="25" value="'.$row['nick'].'" required>
			</div>
		</div>
		<div class="control-group">
		    <label class="control-label" for="steamid">SteamID: </label>
		    <div class="controls">
				<input name="steamid" id="steamid" type="text" pattern="^STEAM_0:[01]:[0-9]{5,10}$" size="15" maxlength="60" type="text" value="'.$row['steamid'].'">
			</div>
		</div>
		<div class="control-group">
			<label class="control-label" for="vk">В контакте: </label>
			<div class="controls">
				<input name="vk" id="vk" type="text" pattern="http:\/\/vk\.com\/[a-zA-Z0-9_.]{1,40}$" size="15" maxlength="60" type="text" value="'.$row['vk'].'">
			</div>
		</div>
		<div class="control-group">
			<div class="controls">
				<input type="submit" class="btn btn-info" name="submit" value="Подтвердить">
			</div>
		</div>
		</form>';
		
		$tpl->content .=  '<legend>Смена пароля</legend><form class="form-horizontal" action="" method="post" autocomplete="off">
		<div class="control-group">
			<label class="control-label" for="password">Текущий пароль: </label>
			<div class="controls">
				<input id="password" name="password" type="password" size="15" maxlength="30" required>
			</div>
		</div>

		<div class="control-group">
			<label class="control-label" for="password1">Новый пароль: </label>
			<div class="controls">
				<input id="password1" name="password1" type="password" size="15" maxlength="30" required>
			</div>
		</div>
		<div class="control-group">
			<label class="control-label" for="password2">Повторить пароль: </label>
			<div class="controls">
				<input id="password2" name="password2" type="password" size="15" maxlength="30" required>
			</div>
		</div>
		<div class="control-group">
			<div class="controls">
				<input type="submit" class="btn btn-info" name="submit" value="Подтвердить">
			</div>
		</div>
		</form>';	
		$tpl->content .=  '<legend>Звуковое оповещение о новых сообщениях</legend><div class="well"><center>';
		if (!isset($_COOKIE["msg_sound"]) OR isset($_COOKIE["msg_sound"]) AND $_COOKIE["msg_sound"] == 'on') { 
			$tpl->content .=  '<button id="msg_status" class="btn" onclick="msg_status()"><font color=green>Звук включен</font></button>'; 
		} else { 
			$tpl->content .=  '<button id="msg_status" class="btn" onclick="msg_status()"><font color=red>Звук выключен</font></button>'; 
		} 
		$tpl->content .=  '</center></div>';
		$arr = $us->array_user($userinfo['id']);
		$tpl->content .=  '<form method="POST" class="form-horizontal" action=""><fieldset><legend>Подпись</legend>';
		if(!empty($arr[10])) {
			$tpl->content .=  '<div class="well well-large">'.$eng->replaceBBCode($eng->smiles(mysql_real_escape_string($arr[10]), 1, 0))."</div>";
		}
				$tpl->content .=  ''.$eng->bb_panel().'
				<textarea maxlength="300" style="height:70px;" class="span6" name="input_text" id="input_text" rows="5">'.$arr[10].'</textarea>
				<div class="form-actions"><input type="submit" value="Изменить" class="btn btn-info"></div>
		  </fieldset></form>';
		 }
} else
	$tpl->content .= $eng->msg(2, "Вы не авторизованы", 2); 
?>