<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'profile';

#Заголовок страницы
$tpl->changeTitle('Профиль');

#Навигация
$nav[] = array('url' => '/profile', 'name' => 'Профиль');

#Подключаем файл функций
require_once "modules/profile/function.php";

$css[] = 'jquery.toastmessage-min.css';
$javascript[] = 'jquery.toastmessage-min.js';

$getsmiles = $eng->getsmiles();

$escaped_user = (!empty($_GET['user']) ? intval($_GET['user']) : ($userinfo['group'] ? $userinfo['id'] : 0));
	
$sql = mysql_query("SELECT * FROM `users` WHERE id = '{$escaped_user}'");
# Пользователь существует
if (mysql_num_rows($sql) == 1) 
{
	$row = mysql_fetch_assoc($sql);
	$nav[] = array('name' => $row['login']);
	$tpl->content .=  '<table class="table table-striped">
	<table class="table table-bordered">
	<thead>
	<th colspan="2"><center>Профиль</center></th>
	<tr><td><div class="pull-right"><img style="margin-right: 5px; -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px; border: 2px solid '.$us->userstatus($row['id']).';" src="'.$us->avatar($row['id']).'" width="55" height="55"/></div>
	<div class="pull-left">Логин: '.$row['login'].' '; 
	if (isset($userinfo['id']) AND $userinfo['id'] != $row['id'])
	$tpl->content .= '(<a href="createdialog_'.$row['id'].'">Отправить ЛС</a>)';
	$tpl->content .= '<br />Имя: '.$row['name'].'<br />
	ID: '.$row['id'].'</div></td></tr>
	<tr><td>Ник в игре: '.$row['nick'].'</td></tr>
	<tr><td>Скилл: '.$us->skillname($row['skill_id'], 0).'</td></tr>
	<tr><td>SteamID: '.$row['steamid'].'</td></tr>';
	if (!empty($row['vk'])) 
	$tpl->content .= '<tr><td>В контакте: <a target="_blank" rel="nofollow" href="'.$row['vk'].'">'.$row['vk'].'</a></td></tr>';
	$tpl->content .= '<tr><td>Группа: '.$us->groupname($row['group_id'], 0).'</td></tr>
	<tr><td>Друзья: <a href="http://'.$_SERVER['SERVER_NAME'].'/friends_'.$row['id'].'">Перейти к списку друзей</a></td></tr>';
	$queryfr = $db->query("SELECT * FROM `friends` WHERE `id` = '{$row['id']}' AND FIND_IN_SET('{$userinfo['id']}', `friends`)");
	if(!$db->num_rows($queryfr) AND $row['id'] != $userinfo['id'] AND $userinfo['group'])
	$tpl->content .= '<tr><td>Добавить друга: <a href="#addfriend" onclick="addfriend('.$row['id'].')">Послать заявку</a></td></tr>';
	
	$tpl->content .= '</table>';
	$tpl->content .= adminfo($row['id']);
	$sql = $db->query("SELECT * FROM `stats_players` WHERE `user_id` = '{$row['id']}' ORDER BY `server` ASC");
	if($db->num_rows($sql) > 0)
	{
		$servers = array();
		$query = $db->query("SELECT * FROM `servers`");
		while($row = $db->fetch_array($query))
		$servers[$row['id']] = $row['hostname'];
		$tpl->content .= '<br><h3><legend>Игровые профили</legend></h3></br>';	
		$tpl->content .= '<table class="table table-striped table-bordered table-condensed">
		<thead><tr><th>Сервер</th><th>Ранк</th><th>Ник</th><th>Фрагов</th><th>Сыграно</th><th>Коэф.</th><th>Первый раз</th><th>Последний раз</th></tr></thead><tbody>';
		while($row = $db->fetch_array($sql))
		{
			$rquery = $db->query("SELECT COUNT(*) FROM `stats_players` WHERE `server` = '{$row['server']}' AND `frags` >= '{$row['frags']}'");
			$rowr = $db->fetch_array($rquery);
			$row['rank'] = $rowr['COUNT(*)'];

			$maketime1 = round($row['time']/3600);
			$maketime2 = round($row['time']/60);
			
			if($maketime1 > 0)
				$time = $eng->declOfNum($maketime1, array('час','часа','часов'));
			else {
				$time = $eng->declOfNum($maketime2, array('минута','минуты','минут'));
			}
			if($row['lseen'] > (time()-300))
				$lseen = '<font color="green"><b>Играет</b></font>';
			else
				$lseen = $eng->showtime($row['lseen'], 1);
				
			if($maketime2 != 0)
				$coeff = round($row['frags']/$maketime2,2);
			else
				$coeff = 0;
			$fseen = $eng->showtime($row['fseen'], 1);
			$tpl->content .= '<tr><td>'.$servers[$row['server']].'</td><td>'.$row['rank'].'</td><td>'.$row['name'].'</td><td>'.$row['frags'].'</td><td>'.$time.'</td><td>'.$coeff.'</td><td>'.$fseen.'</td><td>'.$lseen.'</td></tr>';
		}
		$tpl->content .= '</tbody></table>';
	}
	$sql = $db->query("SELECT * FROM `add_bans` WHERE `s_id` = '{$row['id']}' ORDER BY `id` DESC LIMIT 10");
	if($db->num_rows($sql) > 0)
	{
		$tpl->content .= '<br><h3>Заявки на разбан</legend></h3></br>';
		$tpl->content .= '<table class="table table-bordered"><thead><th>Сервер</th><th>Ник</th><th>Статус</th><th>Дата</th><th>Действие</th></thead><tbody>';
		$resultcol = array("", "success", "error");
		$userstatuscol = array("На рассмотрении", "<font color='green'>Разбанен</font>", "<font color='red'>Не разбанен</font>");
		while($row = $db->fetch_array($sql)) 
		{ 
			$s_login = $us->username($row['s_id'], 0); 
			$tpl->content .= '<tr class="'.$resultcol[$row['type']].'"><td>'.$row['server'].'</td><td>'.$row['nick'].'</td><td>'.$userstatuscol[$row['type']].'</td><td>'.$eng->showtime(strtotime($row['date']),1).'</td><td><a href="http://'.$_SERVER['SERVER_NAME'].'/gounban.php?id='.$row['id'].'">Просмотр</a></td></tr>';
		}
		$tpl->content .= '</tbody></table>';
	}	
# Пользователь не существует
} else
	$tpl->content .= $eng->msg("2", "Пользователь не существует", "2"); 