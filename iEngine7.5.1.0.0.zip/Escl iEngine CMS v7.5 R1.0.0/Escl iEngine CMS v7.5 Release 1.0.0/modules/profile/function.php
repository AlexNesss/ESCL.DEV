<?php if (!defined('BYESCL'))			exit('Нет доступа');

# bymirror v2 
/*
Описание: Получает информацию о админках пользователя
Параметры: $id (число) - номер пользователя
*/
function adminfo($id) 
{
	global $db,$eng;
	
	$snservers = array();
	$query = $db->query("SELECT * FROM `servers`");
	while($row = $db->fetch_array($query))
		$snservers[$row['id']] = $row['hostname'];
		
	$sql = $db->query("SELECT * FROM `accounts` WHERE `user_id` = '{$id}'");
	$result = '';
	if($db->num_rows($sql)) 
	{
		$result .= '<br><h3><legend>Админки/випки</legend></h3></br>';
		$result .= '<table class="table table-striped table-bordered table-hover table-condensed">
						<thead>
							<tr>
								<th>Ник/SteamID/IP</th>
								<th>Флаги</th>
								<th>Тип</th>
								<th>Сервер</th>
								<th>Дата окончания</th>
							</tr>
						</thead>
					<tbody>';
		while($row = $db->fetch_array($sql)) 
		{
			if(!$row['date_end']) 
			{
				$accstatus = 'Никогда (Права навсегда)';
				$date_end = 9999999999;
			} else {
				$date_out = round(($row['date_end']-time())/3600/24);
				if(time() > $row['date_end'])
					$accstatus = '<font color="red">Аккаунт просрочен</font>';
				else if($date_out == 0)
					$accstatus = '<font color="black">Осталось совсем немного</font>';
				else if($row['date_end'] > time())
					$accstatus = date("d.m.y",$row['date_end']).' (Еще '.$eng->declOfNum($date_out, array("день", "дня", "дней")).')'; 
			}
			$result .= '<tr><td>'.$row['value'].'</td><td>'.$row['option'].'</td><td>'.$row['type'].'</td><td>'.$snservers[$row['server']].'</td><td>'.$accstatus.'</td></tr>';
		}
		$result .= '</tbody></table>';
	}	
	return $result;
}