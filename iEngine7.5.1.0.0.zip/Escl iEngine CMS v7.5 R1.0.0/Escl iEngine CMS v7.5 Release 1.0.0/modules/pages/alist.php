<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'alist';

#Заголовок страницы
$tpl->changeTitle('Список админов');

#Навигация
$nav[] = array('name' => 'Список админов');

if($userinfo['group']) 
{
	$server = htmlspecialchars($_GET['name'], ENT_QUOTES);
	if(!empty($server)) 
	{
		$sql = $db->query("SELECT * FROM `accounts` WHERE `server` = '{$server}' AND (`date_end`> ".time()." OR `date_end` = 0)");
		if ($db->num_rows($sql))
		{
			$gl_adm = 0;
			$zams = 0;
			$adm = 0;
			$vips = 0;
			while ($row = $db->fetch_array($sql))
			{
				if($row['date_end'] == 0) {
					$accstatus = 'Бессрочно';
					$date_end = 9999999999;
				} else {
					$date_out = round(($row['date_end']-time())/3600/24);
					$accstatus = 'до '.$eng->russian_date($row['date_end']);
					$date_end = $row['date_end'];
				}
				if(substr_count($row['option'],'u') > 0) {
					$rights = 'Админ';
					$adm++;
				} else if(substr_count($row['option'],'t') > 0) {
					$rights = 'Вип';
					$vips++;
				} else
					$rights = $row['option'];
					
				$admins[] = array($date_end, '<tr><td>'.$row['value'].'</td><td>'.$row['option'].'</td><td>'.$row['type'].'</td><td><a target="_blank" href="profile_'.$row['user_id'].'">'.$us->username($row['user_id'], 1).'</a></td><td>'.$accstatus.'</td><td>'.$row['comment'].'</td></tr>');
			}
			$tpl->content .= 'На сервере: '.$eng->declOfNum($adm, array("администратор", "администратора", "администраторов")).' и '.$eng->declOfNum($vips, array("вип", "випа", "випов")).'<br /><br />';
			$tpl->content .= '<table class="table table-striped table-bordered table-condensed" ><thead><tr><th>Ник/SteamID/IP</th><th>Флаги</th><th>Тип</th><th>Пользователь</th><th>Срок</th><th>Должность</th></tr></thead><tbody>';
			arsort($admins);
			foreach($admins AS $key => $alist)
				$tpl->content .= $alist[1];
				
			$tpl->content .= '</tbody></table>';
		} else
			$tpl->content .= $eng->msg("2", "Активных админи/вип на сервере не найдено", "2"); 
	} else
		$tpl->content .= $eng->msg("2", "Не введено название сервера", "2"); 
} else
	$tpl->content .= $eng->msg(3, "Вы не авторизованы", 3); 