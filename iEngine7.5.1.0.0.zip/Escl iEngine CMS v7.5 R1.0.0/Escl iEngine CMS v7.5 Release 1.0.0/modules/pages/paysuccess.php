<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'paysuccess';

#Заголовок страницы
$tpl->changeTitle('Оплата прошла успешно');

$nav[] = array('url' => '/pay', 'name' => 'Покупка прав');

$tpl->content .= $eng->msg("1", "Вы успешно оплатили услугу! <a href='/userpanel'>Подробности</a>", "1"); 