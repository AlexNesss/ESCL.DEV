<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'payerror';

#Заголовок страницы
$tpl->changeTitle('Оплата прошла неудачно');
$nav[] = array('url' => '/pay', 'name' => 'Покупка админ/вип');

$tpl->content .= $eng->msg("2", "Ошибка при оплате! <a href='/pay'>Попробовать снова</a>", "2"); 