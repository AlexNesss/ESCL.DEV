<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'logs';

#Заголовок страницы
$tpl->changeTitle('Логи авторизации');

#Навигация
$nav[] = array('name' => 'Логи авторизации');

if($userinfo['group']) 
{
	$sql = $db->query("SELECT * FROM `log_auth` WHERE `user_id` = '{$userinfo['id']}' ORDER BY `id` DESC");
	if($db->num_rows($sql))
	{
		while($row = $db->fetch_array($sql))
		{
			$row['lastseen'] = $eng->showtime($row['lastseen'], 1);
			$tpl->data['logs'][] = $row;
		}
	} else 
		$tpl->data['infomsg'] = $eng->msg(3, "Логов не найдено", 3); 
} else
	$tpl->data['infomsg'] = $eng->msg(3, "Вы не авторизованы", 3); 

$tpl->content .= $tpl->parse("pages/logs.tpl",$tpl->data);