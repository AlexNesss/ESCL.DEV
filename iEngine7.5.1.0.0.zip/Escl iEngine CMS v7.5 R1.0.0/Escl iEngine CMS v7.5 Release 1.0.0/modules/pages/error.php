<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'error';

#Заголовок страницы
$tpl->changeTitle('Страница не найдена');

$tpl->content .= $eng->msg("2", "Страница не найдена", "2"); 