<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'admins';

#Заголовок страницы
$tpl->changeTitle('Панель управление админ/вип');
$nav[] = array('name' => 'Панель управление админ/вип');

if($userinfo['group'] == 4) 
{
	require_once "core/functions/admins.php";
	require_once "modules/admins/function.php";
	
	#Присутствует ли $_POST запрос
	if(!empty($_POST))
		require_once "modules/admins/action.php";

	# POST запрос на создание аккаунта
	if(!empty($_POST['account_create'])) {
		$tpl->content .= '<form method="post" action="">
		<table width="100%" style="border: 4px double rgb(199, 195, 195); padding: 5px; border-collapse:inherit; -webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;"><tbody>
		<tr><td width="50%"><b>Ник/SteamID/IP:</b><br /> <input type="text" name="admin_steamid" placeholder="" value=""></td>
		<td><b>Флаги:</b><br /> <input type="text" name="admin_rights" value="abcdefghijklmnopqrstuzy"></td></tr>
		<tr><td width="50%"><b>Cервер:</b><br />'.format_serverlist($gameservers,$default).'</td>
		<td><b>Срок:</b><br /> <input class="form_on" type="text" name="days" value="30"></td></tr>
		<tr><td width="50%"><b>Должность:</b><br /> <input name="comment" type="text" placeholder="" value=""></td>
		<td><b>Номер пользователя:</b><br /> <input class="form_on" type="text" name="user_id" placeholder="" value=""></td></tr>
		<tr><td width="50%"><b>Тип:</b><br /> 
			<select name="type">
			  <option value="steamid" selected="selected">SteamID/ValveID</option>
			  <option value="ip">IP</option>
			  <option value="nick">Ник</option>
			</select>
		</td></tr> 
		<tr><td width="50%"><label class="checkbox" disabled><input type="checkbox" name="paydate_update" disabled><b> Обновить дату создания</b></label></td></td>
		<td><input type="submit" name="account_сreate2" class="btn btn-success" value="Подтвердить"></td></tr>
		</tbody></table></form><br />';
	}
	# POST запрос на редактирование админки
	else if(!empty($_POST['account_edit_num'])) {
		$id_edit = intval($_POST['account_edit_num']);
		$sql = $db->query("SELECT * FROM `accounts` WHERE `id` = '{$id_edit}'");
		$row = mysql_fetch_assoc($sql);
		$tpl->content .= '<form method="post" action="">
		<input type="hidden" name="account_edit_num2" value="'.$id_edit.'">
		<table width="100%" style="border: 4px double rgb(199, 195, 195); padding: 5px; border-collapse:inherit; -webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;"><tbody>
		<tr><td width="50%"><b>Ник/SteamID/IP:</b><br /> <input type="text" name="admin_steamid" value="'.$row['value'].'"></td>
		<td><b>Флаги:</b><br /> <input type="text" name="admin_rights" value="'.$row['option'].'"></td></tr>
		<tr><td width="50%"><b>Cервер:</b><br />'; $tpl->content .= format_serverlist($gameservers,$row['server']); $tpl->content .= '</td>
		<td><b>Срок:</b><br /> <input class="form_on" type="text" name="days" value="'.$row['day_counts'].'"></td></tr>
		<tr><td width="50%"><b>Должность:</b><br /> <input name="comment" type="text" value="'.$row['comment'].'"></td>
		<td><b>Номер пользователя:</b><br /> <input class="form_on" type="text" name="user_id" value="'.$row['user_id'].'"></td></tr>
		<tr><td width="50%"><b>Пароль:</b><br /> <input name="password" type="text" value="'.$row['password'].'"></td>
		<td width="50%"><b>Тип:</b><br /> 
			<select name="type">
			  <option value="steamid"'.($row['type'] == ' steamid' ? "selected" : "").'>SteamID/ValveID</option>
			  <option value="ip"'.($row['type'] == 'ip' ? " selected" : "").'>IP</option>
			  <option value="nick"'.($row['type'] == 'nick' ? " selected" : "").'>Ник</option>
			</select>
		</td></tr> 
		<tr><td width="50%"><label class="checkbox"><input type="checkbox" name="paydate_update"><b> Обновить дату создания</b></label></td></td>
		<td><input onclick="return confirm(\'Вы точно хотите удалить этот аккаунт?\')" type="submit" class="btn btn-danger" name="delete" value="Удалить акк "> <input type="submit" class="btn btn-success" value="Обновить акк"></td></tr>
		</tbody></table></form><br />';
	}
	
	$tpl->content .= acclist();
} else
	$tpl->content .= $eng->msg("2", "Вы не авторизованы или у вас нет прав доступа", "2");