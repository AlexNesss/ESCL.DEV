<?php if (!defined('BYESCL'))			exit('Нет доступа');

switch($_POST){
 case (isset($_POST['delete']) AND !empty($_POST['account_edit_num2'])):
		$num = intval($_POST['account_edit_num2']);
		$result = deleteacc($num); 
		if($result[0])
			$message = 'Админ/вип успешно удален!<br />';
		else
			$message = 'Админ/вип не был успешно удален!<br />';
		if($result[1])
			$message .= 'Файл конфигурации не был успешно обновлен.';
		else
			$message .= 'Файл конфигурации успешно обновлен.';
		$tpl->content .= $eng->msg("1", $message, "1");
	break;
 case (!empty($_POST['account_edit_num2']) AND !empty($_POST['admin_steamid']) AND !empty($_POST['admin_rights']) AND isset($_POST['selected_server']) AND isset($_POST['days']) AND !empty($_POST['type']) AND !empty($_POST['comment']) AND !empty($_POST['user_id']) AND !empty($_POST['password'])):
		# Фильтруем переменные
		$steamid = $eng->stripinput($_POST['admin_steamid']);
		$admin_rights = substr($eng->stripinput($_POST['admin_rights']),0,21);
		$type = $eng->stripinput($_POST['type']);
		$selected_server = $eng->stripinput($_POST['selected_server']);
		$days = intval($_POST['days']);
		$comment = $eng->stripinput($_POST['comment']);
		$user_adm_id = intval($_POST['user_id']);
		$accid = intval($_POST['account_edit_num2']);
		$upassword = $eng->stripinput($_POST['password']);
		
		$err = array();	
		
		if (!in_array( $type, array('steamid', 'ip', 'nick') ) )
			$err[] = 'Указанный тип отсутствует';

		if (preg_match("/[^a-z]/",$admin_rights))
			$err[] = 'Неверные права доступа';
			
		#if($selected_server > count($gameservers)-1)
			#$err[] = 'Сервера не существует';
			
        $sql = $db->query("SELECT * FROM `users` WHERE `id` = '{$user_adm_id}'") or die(mysql_error());
		if (!$db->num_rows($sql))
            $err[] = 'Пользователь не существует';
			
		$sql = $db->query("SELECT * FROM accounts WHERE `id` = '{$accid}'") or die(mysql_error());
		$row = mysql_fetch_assoc($sql);
		if($row['value'] == $steamid)
			$where_id = " AND id != '{$row['id']}'";
		else 
			$where_id = '';
		$sql = $db->query("SELECT * FROM accounts WHERE value = '{$steamid}' AND server = '{$selected_server}'{$where_id}") or die(mysql_error());
		if ($db->num_rows($sql)) {
            $err[] = 'Админ/вип с введенными данными уже существует!';
        }
		# Если ошибок нет
		if(count($err) == 0) {
			$query = $db->query("SELECT * FROM `accounts` WHERE id = {$accid}");
			$row = mysql_fetch_assoc($query);
			# Если мы обновляем дату активации аккаунта, то по любому активируем акк, задаем время создания акка, ну и так далее
			if(!empty($_POST['paydate_update'])) 
			{
				$date_create = time();
				if($days != 0)
					$date_end = $date_create+($days*24*3600);
				else
					$date_end = 0;	
			} else if ($row['day_counts'] != $days) {
				$date_create = $row['date_create'];
				if($days != 0)
					$date_end = $date_create+($days*24*3600);
				else
					$date_end = 0;
			} else {
				$date_create = $row['date_create'];
				$date_end = $row['date_end'];
			}
			$sql = $db->query("UPDATE `accounts` SET `user_id` = '{$user_adm_id}', `password` = '{$upassword}', `date_create` = '{$date_create}', `day_counts` = '{$days}', `type` = '{$type}', `date_end` = '{$date_end}', `server` = '{$selected_server}', `value` = '{$steamid}', `option` = '{$admin_rights}', `comment` = '{$comment}' WHERE `id` = '{$accid}'") or die(mysql_error());
			if ($sql)
			{
				$query = $db->query("DELETE FROM `buy_order` WHERE `value` = '{$steamid}'");
				$result = upload_config ($selected_server,generate_config($selected_server));
				$tpl->content .= $eng->msg("1", "Админ/вип успешно обновлен!<br />".$result[1]."", "1");
			} else
				$tpl->content .= $eng->msg("2", "Админ/вип не был успешно обновлен!", "2");
		# Если ошибки есть
		} else {
			$errormsg = '';
			foreach($err AS $error)
				$errormsg .= $error."<br>";
				
			$tpl->content .= $eng->msg("2", $errormsg, "2");
		}
	break;
 case (!empty($_POST['account_сreate2']) AND !empty($_POST['admin_steamid']) AND !empty($_POST['admin_rights']) AND isset($_POST['selected_server']) AND isset($_POST['days']) AND !empty($_POST['type']) AND !empty($_POST['comment']) AND !empty($_POST['user_id'])):
		# Фильтруем переменные
		$steamid = $eng->stripinput($_POST['admin_steamid']);
		$admin_rights = substr($eng->stripinput($_POST['admin_rights']),0,21);
		$selected_server = $eng->stripinput($_POST['selected_server']);
		$type = $eng->stripinput($_POST['type']);
		$days = intval($_POST['days']);
		$comment = $eng->stripinput($_POST['comment']);
		$user_adm_id = intval($_POST['user_id']);
		$user_adm_password = $eng->GenerateKey(6);
		
		# Создаем пустой массив ошибок
		$err = array();	

		if (!in_array( $type, array('steamid', 'ip', 'nick') ) )
			$err[] = 'Указанный тип отсутствует';		
			
		#if(!preg_match("/^STEAM_[0-9]:[0-9]:[0-9]{5,10}$/", $steamid) AND !preg_match("/^VALVE_[0-9]:[0-9]:[0-9]{5,11}$/", $steamid)) 
			#$err[] = 'Неверный SteamID/ValveID';
			
		# Валидность права доступа
		if (preg_match("/[^a-z]/",$admin_rights))
			$err[] = 'Неверные права доступа';
			
		# Существует ли сервер
		#if($selected_server > count($gameservers)-1)
			#$err[] = 'Сервера не существует';
			
		# Существует ли аккаунт с введенными данными
		$sql = $db->query("SELECT * FROM accounts WHERE value = '{$steamid}' AND server = '{$selected_server}'") or die(mysql_error());
		if ($db->num_rows($sql))
            $err[] = 'Админ/вип с введенными данными уже существует';
			
        $sql = $db->query("SELECT * FROM users WHERE id = '{$user_adm_id}'") or die(mysql_error());
		if (!$db->num_rows($sql))
            $err[] = 'Пользователь не существует';
			
		# Существует ли аккаунт
		# Если ошибок нет
		if(count($err) == 0) {
			# Осталось подготовить переменные $date_create, $date_end
			$date_create = time();
			if($days != 0)
				$date_end = $date_create+($days*24*3600);
			else
				$date_end = 0;		
			$sql = $db->query("INSERT INTO `accounts` (`id`, `user_id`, `password`, `type`, `date_create`, `day_counts`, `date_end`, `server`, `value`, `option`, `comment`) VALUES (NULL, '{$user_adm_id}', '{$user_adm_password}', '{$type}', '{$date_create}', '{$days}', '{$date_end}', '{$selected_server}', '{$steamid}', '{$admin_rights}', '{$comment}')") or die(mysql_error());
			if ($sql)
			{
				$query = $db->query("DELETE FROM `buy_order` WHERE `value` = '{$steamid}'");
				$result = upload_config ($selected_server,generate_config($selected_server));
				$tpl->content .= $eng->msg("1", "Аккаунт успешно создан <br />".$result[1]."<br />Пароль пользователя: {$user_adm_password}", "1");
			} else
				$tpl->content .= $eng->msg("2", "Аккаунт не был создан", "2");
		# Если ошибки есть
		} else {
			$errormsg = '';
			foreach($err AS $error)
				$errormsg .= $error."<br>";
			$tpl->content .= $eng->msg("2", $errormsg, "2");
		}
	break;
}