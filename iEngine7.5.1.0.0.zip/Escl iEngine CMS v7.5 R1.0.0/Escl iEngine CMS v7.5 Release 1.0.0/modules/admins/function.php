<?php if (!defined('BYESCL'))			exit('Нет доступа');

function acclist()
{
	global $db, $snservers,$eng;
	
	$result = '<form method="post" action=""><center><input onclick="return confirm(\'Вы точно хотите создать новый админ/вип?\')" type="submit" class="btn btn-info" name="account_create" value="Создать админа/випа"></center></form><br />';
	$sql = $db->query("SELECT * FROM `accounts` ORDER BY FIELD(`date_end`,0) ASC, `date_end` ASC");
	if(!$db->num_rows($sql)) 
		return $result.$eng->msg("3", "Админ/вип еще не создано", "3");	
	
	$result .= '<table class="table table-striped table-bordered table-hover table-condensed">
						<thead>
						<tr>
							<th>Ник/SteamID/IP</th>
							<th>Флаги</th>
							<th>Тип</th>
							<th>Сервер</th>
							<th>Срок</th>
							<th>Должность</th>
						</tr>
						</thead>
					 <tbody>';
	while($row = $db->fetch_array($sql)) 
	{
		if(!$row['date_end'])
			$accstatus = 'Навсегда';	
		else {
			$date_out = round(($row['date_end']-time())/3600/24);
			
			if(time() > $row['date_end'])
				$accstatus = '<font color="red">Закончилась админка/випка</font>';
			else if(!$date_out)
				$accstatus = '<font color="black">Осталось совсем немного</font>';
			else if($row['date_end'] > time())
				$accstatus = date("d.m.y",$row['date_end']).' (Еще '.$eng->declOfNum($date_out, array("день", "дня", "дней")).')'; 
		}
		
		$result .= '<tr onclick="prava_admina(\''.$row['id'].'\')">
							<td>'.$row['value'].'</td>
							<td>'.$row['option'].'</td>
							<td>'.$row['type'].'</td>
							<td>'.$row['server'].'</td>
							<td>'.$accstatus.'</td>
							<td>'.$row['comment'].'</td>
						  </tr>';
	
	}
	$result .= '</tbody>
	</table>
	<form action="" method="post" id="edit_account">
		<input type="hidden" value="" id="account_edit_num" name="account_edit_num" >
	</form>';
		
	return $result;
}