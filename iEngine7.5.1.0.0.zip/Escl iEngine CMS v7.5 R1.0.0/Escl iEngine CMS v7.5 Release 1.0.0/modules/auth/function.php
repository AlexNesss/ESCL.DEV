<?php if (!defined('BYESCL'))			exit('Нет доступа');

# bymirror v2 
/*
Описание: Генерация ключа
Параметры: Остутствуют
*/
function GenerateKey() 
{
	$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPRQSTUVWXYZ0123456789";
	$code = "";
	$clen = strlen($chars) - 1;  
	while (strlen($code) < 10)
		$code .= $chars[mt_rand(0,$clen)];  
	return md5($code);
}
	
# bymirror v2 
/*
Описание: Выход из профиля
Параметры: $user_id (число)   - номер пользователя
*/
function logout($user_id)
{
	global $db;
	
	$user_id = intval($user_id);
	$hash = mysql_real_escape_string($_COOKIE['hash']);
	
    session_unset();
    session_destroy();
	setcookie('id', '', 0, "/");
	setcookie('hash', '', 0, "/");
	
	$sql = $db->query("SELECT * FROM `users` WHERE `id` = '{$user_id}' AND FIND_IN_SET('{$hash}', `hash`)");
	if($db->num_rows($sql) > 0)
	{
		$row = $db->fetch_array($sql);
		$check = explode(",", $row['hash']);
		if($key = array_search($hash, $check) AND isset($check[$key])) 
			unset($check[$key]);
		$newhash = implode(',',$check);
		$sql = $db->query("UPDATE `users` SET `hash` = '{$newhash}' WHERE `id` = '{$user_id}';");
	}
	$sql = $db->query("DELETE FROM `log_auth` WHERE `hash` = '{$hash}'");
	
    header("Location: ".SITEDIR);
	exit();
}

# bymirror v2 
/*
Описание: Выход из профиля
Параметры: $login (слово)    - номер пользователя
		   $password (слово) - пароль пользователя
*/
function auth($login,$password) 
{  
	global $db;

	$baninfo = checkbaninfo();
	if($baninfo)
		return array('type' => 'error', 'msg' => 'Вы заблокированы на 15 минут');
	
	$login = $db->escape($login);
	$password = $db->escape($password);
	
	$sql = $db->query("SELECT * FROM `users` WHERE `login` = '{$login}' AND `password` = '{$password}'");
	if ($db->num_rows($sql) > 0) 
	{
		$row = $db->fetch_array($sql);
		$hash = GenerateKey();
		setcookie("hash", $hash, time()+2592000, "/");
		setcookie("id", $row['id'], time()+2592000, "/");
		$check = explode(",", $row['hash']);
		if(count($check) == 5) 
		{
			$sql = $db->query("DELETE FROM `log_auth` WHERE `hash` = '{$check[0]}'");
			unset($check[0]);
		}
		array_push($check, $hash);
		$newhash = implode(',',$check);
		$db->query("UPDATE `users` SET  `hash` = '{$newhash}' WHERE `id` = '{$row['id']}'");
		$data = checkguestinfo();
		$db->query("INSERT INTO `log_auth` (`id`, `user_id`, `hash`, `browser`, `os`, `ip`, `lastseen`) VALUES (NULL, '{$row['id']}', '{$hash}', '{$data['browser']}', '{$data['os']}', '".USER_IP."', '".time()."')");
		return array('type' => 'success');
	} else {
		$count = checkbaninfo(1);
		if($count == 5)
			return array('type' => 'error', 'msg' => "Вы заблокированы на 15 минут.");
		else
			return array('type' => 'error', 'msg' => "Логин или пароль не существует. Это {$count} неудачная попытка ввода пароля. После 5 неудачного входа вы не сможете войти на сайт в течение 15 минут.");
	}
}

# bymirror v2 
/*
Описание: Информация о блокировках
Параметры: $up (число)    - переключатель ~ 1 - добавить ошибку в логи, 2 - проверить наличие в блокировках пользователя
*/
function checkbaninfo($up = 0)
{
	global $db;
	$time = time()-900;
	$db->query("DELETE FROM `err_auth` WHERE `date` < '{$time}'");
	$sql = $db->query("SELECT * FROM `err_auth` WHERE `ip` = '".USER_IP."'");
	if($up)
	{
		if($db->num_rows($sql) > 0)
			$query = "UPDATE `err_auth` SET `count` = `count`+1, `date` = '".time()."' WHERE `ip` = '".USER_IP."'";
		else {
			$query = "INSERT INTO `err_auth` (`id`, `ip`, `count`, `date`) VALUES (NULL, '".USER_IP."', '1', '".time()."')";
			$err = 1;
		}
		$db->query($query);
		if(!isset($err))
		{
			$row = $db->fetch_array($sql);
			$err = $row['count']+1;
		}
		return $err;
	} else {
		$result = false;
		if($db->num_rows($sql) > 0)
		{
			$row = $db->fetch_array($sql);
			if($row['count'] == 5)
				$result = true;
		} 
		return $result;
	}
}

# bymirror v2 
/*
Описание: Узнать браузер и ОС пользователя
Параметры: Отсутствуют
*/
function checkguestinfo()
{
	$useragent = strtolower($_SERVER['HTTP_USER_AGENT']);
	$browsers = array(
		'firefox' => 'Mozilla Firefox',
		'opera' => 'Opera',
		'chrome' => 'Google Chrome',
		'msie' => 'Internet Explorer',
		'safari' => 'Safari',
		'netscape' => 'Netscape',	
		'opera mini' => 'Opera Mini',
		'NetPositive' => 'NetPositive',
		'blackberry' => 'BlackBerry',
		'flock' => 'Flock',
		'konqueror' => 'Konqueror',
		'Nokia' => 'Nokia Браузер',
		'lynx' => 'Lynx',
		'amaya' => 'Amaya',
		'omniweb' => 'Omniweb',
		'aol' => 'AOL'		
	);
	foreach($browsers AS $key => $value)
	{
		if (strpos($useragent, $key) !== false)
		{
			$browser = $value;
			break;
		}
	}
	$oses = array(
		'iPad' => '/(ipad)/',
		'iPhone' => '/(iphone)/',
		'WindowsPhone' => '/(windowsphone)/',
		'Symbian' => '/(symbian)/',
		'Android' => '/(android)/',
		'Windows 3.11' => '/win16/',
		'Windows 95' => '/(windows 95)|(win95)|(windows_95)/',
		'Windows 98' => '/(windows 98)|(win98)/',
		'Windows 2000' => '/(windows nt 5.0)|(windows 2000)/',
		'Windows XP' => '/(windows nt 5.1)|(windows XP)/',
		'Windows 2003' => '/(windows nt 5.2)/',
		'Windows Vista' => '/(windows nt 6.0)|(windows vista)/',
		'Windows 7' => '/(windows nt 6.1)|(windows 7)/',
		'Windows 8' => '/(windows nt 6.2)|(windows 8)/',
		'Windows NT 4.0' => '/(windows nt 4.0)|(winnt4.0)|(winnt)|(windows nt)/',
		'Windows ME' => '/windows me/',
		'Open BSD'=>'/openbsd/',
		'Sun OS'=>'/sunos/',
		'Linux'=>'/(linux)|(x11)/',
		'Safari' => '/(safari)/',
		'Macintosh'=>'/(mac_powerpc)|(macintosh)/',
		'QNX'=>'/qnx/',
		'BeOS'=>'/beos/',
		'OS/2'=>'/os/2/',
		'Бот'=>'/(nuhk)|(googlebot)|(yammybot)|(openbot)|(slurp/cat)|(msnbot)|(ia_archiver)/'
	);
	foreach($oses AS $key => $value)
	{
		if (preg_match($value, $useragent))
		{
			$os = $key;
			break;
		}
	}
	if(!isset($browser))
		$browser = 'Неизвестно';
	if(!isset($os))
		$os = 'Неизвестно';
	return array('browser' => $browser, 'os' => $os);
}