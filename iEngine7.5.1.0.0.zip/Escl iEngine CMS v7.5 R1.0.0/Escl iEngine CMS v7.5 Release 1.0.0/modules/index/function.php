<?php if (!defined('BYESCL'))			exit('Нет доступа');

/*
Описание: Отдает список серверов
*/

function servers() 
{
	global $db;
	
	$sql = $db->query("SELECT * FROM `servers`");
	
	$result = array();
	
	if($db->num_rows($sql)) 
	{
		while($row = $db->fetch_array($sql)) 
		{
			$row['percent'] = ($row['maxplayers'] ? round(($row['players']/$row['maxplayers'])*100) : 0);

			if($row['percent'] <= 40) 		$row['color'] = 'success';
			else if($row['percent'] <= 80) 	$row['color'] = 'warning';
		    else 							$row['color'] = 'danger';
				
			$result['servers'][] = $row;
		}
	}
	return $result;
}

/*
Описание: Отдает список последних тем
*/

function lastthreads()
{
	global $db,$eng,$us;
	
	$result = array();
	
    $sql = $db->query("SELECT `forums_messages`.`id`,`forums_messages`.`thread`, `forums_messages`.`time`, `forums_messages`.`user_id`, `forums_threads`.`title`, `forums_threads`.`for`, `forums_threads`.`view` FROM `forums_messages`, `forums_threads`  WHERE `forums_messages`.`id` IN (SELECT MAX(`id`) FROM `forums_messages` GROUP BY `thread`) AND `forums_threads`.`id` = `forums_messages`.`thread` ORDER BY `forums_messages`.`id` DESC LIMIT 5");
	
	if($db->num_rows($sql)) 
	{   
		$themes = array();
		$prepareusers = array();
		$count = array();
		$msgnum = array();
		
		while($row = $db->fetch_array($sql)) 
		{
			$themes[] = $row;
			$prepareusers[] = $row['user_id'];
			$count[] = $row['thread'];
		}
		
		$count = implode(',', $count);
		
		$sql_count = $db->query("SELECT `thread`, count(`id`)-1 AS `count` FROM `forums_messages` WHERE `thread` IN({$count}) GROUP BY `thread`");
		
		while($row_count = $db->fetch_array($sql_count)) 
			$msgnum[$row_count['thread']] = $row_count['count'];
			
		$users = $us->ausers($prepareusers, 1);
		
		$i = 1;
		
		foreach($themes AS $key => $value) 
		{
			$value['num'] = $i;
			$value['msg'] = $msgnum[$value['thread']];
			$value['time'] = $eng->showtime(strtotime($value['time']), 1);
			$value['login'] = $users[$value['user_id']];		
			$result['thread'][] = $value;
			$i++;
		}
	}
	
	return $result;
}

/*
Описание: Выводит чат
*/

function chat()
{
	global $db,$eng,$us,$getsmiles;
	
	$result = array();
	
	$sql = $db->query("SELECT * FROM `messages` ORDER BY `id` DESC LIMIT 80");
	
	$result['lastmsg'] = 0;
	
	if($db->num_rows($sql))
	{
		$messages = array();
		$prepareusers = array();
		
		while ($row = $db->fetch_array($sql))
		{
			$messages[] = array('id' => $row['id'], 'text' =>  $row['text'], 'time' =>  $row['time'], 'user_id' =>  $row['user_id']);
			$prepareusers[] = $row['user_id'];
		}
		
		$users = $us->ausers($prepareusers, 1);
		
		# Получаем ID последнего сообщения
		$result['lastmsg'] = $messages[0]['id'];
		
		foreach ($messages AS $value)
		{
			$result['chat'][] = array('id' => $value['id'],
									  'user_id' => $value['user_id'],
									  'login' => $users[$value['user_id']],
									  'text' => $eng->replacechat($eng->replace_smiles($value['text'], $getsmiles['search'], $getsmiles['replace'])),
									  'date' => $eng->showtime(strtotime($value['time']), 0),
									  'avatar' => $us->avatar($value['user_id']));
		}
	}
	
	if ($us->agsearch('chatmsg')) 
		$result['chatmsg'] = true;
	
	return $result;
}