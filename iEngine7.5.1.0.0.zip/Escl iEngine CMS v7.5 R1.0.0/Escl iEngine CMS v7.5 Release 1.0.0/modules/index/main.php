<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'main';

#Заголовок страницы
$tpl->changeTitle('Главная страница');

#Подключаем файл функций
require_once "modules/index/function.php";

#Список серверов
$tpl->data['servers'] = $tpl->parse("index/servers.tpl", servers());

#Чат
if ($userinfo['group'] AND $us->agsearch('chat'))
{
	#Подключаем JS
	$javascript[] = 'jquery.mousewheel-3.0.4.pack.js';
	$javascript[] = 'jquery.fancybox-1.3.4.pack.js';
	$javascript[] = 'jquery.easing-1.3.pack.js';
	
	#Подкючаем CSS
	$css[] = 'chat.css?v=1.8';
	$css[] = 'jquery.fancybox-1.3.4.css?v=1.1';

	#Получение смайлов
	$getsmiles = $eng->getsmiles();	
	
	#Выводим чат
	$tpl->data['chat'] = $tpl->parse("index/chat.tpl", chat());
}

#Телевизор
if($userinfo['group']) 
	$tpl->data['tv'] = true;

#Последние темы
if ($userinfo['group'] AND $us->agsearch('forum')) 
	$tpl->data['thread'] = $tpl->parse("index/threads.tpl", lastthreads());

#Статистика
$tpl->data['infostats'] = file_get_contents('tpl/other/info.txt');

$tpl->content .= $tpl->parse("index/index.tpl",$tpl->data);