<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'reg';

#Заголовок страницы
$tpl->changeTitle('Регистрация');
	
#Подключаем файл функций
require_once "modules/reg/function.php";

#Подключаем капчу
require_once "core/classes/keycaptcha.php";

#Регистрируем класс
$kc_o = new KeyCAPTCHA_CLASS();

#Стена
if ($userinfo['group'] == 0)
{
	if(!empty($_POST['login']) AND !empty($_POST['email']) AND !empty($_POST['password']) AND !empty($_POST['capcode']))
	{
		$nav[] = array('name' => 'Регистрация', 'url' => '/reg');
		$nav[] = array('name' => 'Результат');
		$result = validatereg($_POST['login'],$_POST['password'],$_POST['email'],$_POST['capcode']);
		$tpl->content .= $eng->msg($result['type'],$result['msg'],$result['type']);
	} else {
		$nav[] = array('name' => 'Регистрация');
		$tpl->content .= formreg();
	}
} else
	header("Location: ".SITEDIR);