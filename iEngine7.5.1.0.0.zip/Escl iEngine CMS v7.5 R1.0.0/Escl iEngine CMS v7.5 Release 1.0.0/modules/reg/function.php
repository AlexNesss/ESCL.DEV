<?php if (!defined('BYESCL'))			exit('Нет доступа');

function formreg()
{
	global $kc_o;
	$result = '
	<form class="form-horizontal well" method="post" autocomplete="off">
		<input type="hidden" name="capcode" id="capcode" value="false" />
		<div class="control-group">
			<label class="control-label" for="login">Логин:&nbsp;&nbsp;&nbsp;</label>
			<input name="login" id="login" type="text" size="15" maxlength="15" required>
		</div>
		<div class="control-group">
			<label class="control-label" for="email">Почтовый ящик:&nbsp;&nbsp;&nbsp;</label>
			<input name="email" id="email" type="email" size="15" required>
		</div>
		<div class="control-group">
			<label class="control-label" for="password">Пароль:&nbsp;&nbsp;&nbsp;</label>
			<input name="password" id="password" type="text" size="15" maxlength="30" required>
		</div>
		'.$kc_o->render_js().'
		<div class="form-actions">
			<input type="submit" value="Зарегистрироваться" id="postbut" class="btn btn-info">
		</div>
	</form>';

	return $result;
}

function validatereg($login,$password,$email,$captcha)
{
	global $db,$kc_o;
	$err = array();
	
	$login = trim(htmlspecialchars($login, ENT_QUOTES));
	$password = mysql_real_escape_string($password);
	$email = trim(mysql_real_escape_string($email));
	$md5pass = md5($password);
	
	$sql = $db->query("SELECT * FROM `users` WHERE `login` = '{$login}'");
	if ($db->num_rows($sql) > 0) 
		$err[] = 'Введённый логин уже зарегистрирован';
	if (!preg_match('/^[A-Za-z0-9_\+-\.,\[\]\)\(@!\?\$\*~\s]{3,15}$/i', $login))
		$err[] = 'Логин может состоять только из букв латинского алфавитов, пробела, спецсимволов: _+-.,[])(@!?$*~, а также его длина должна быть от 3 до 15 символов';
	if (!preg_match('/^[A-Za-z0-9_\+-\.,\[\]\)\(@!\?\$\*~\s]{6,30}$/i', $password))
		$err[] = 'Пароль может состоять только из букв латинского алфавита, пробела, спецсимволов: _+-.,[])(@!?$*~, а также его длина должна быть от 6 до 30 символов';	
	$sql = $db->query("SELECT * FROM `users` WHERE `email` = '{$email}'");
	if ($db->num_rows($sql) > 0)
		$err[] = 'Введённый вами почтовый ящик уже зарегистрирован';	
	if(!filter_var($email, FILTER_VALIDATE_EMAIL))
		$err[] = 'Неверный почтовый ящик';
	if (!$kc_o->check_result($captcha))
		$err[] = 'Вы неверно собрали картинку';
	if(count($err) == 0) 
	{
		$sql = $db->query("INSERT INTO `users` (`login`,`password`,`email`,`group_id`,`skill_id`) VALUES('{$login}','{$md5pass}','{$email}','2','2')");
		if ($sql)
		{
			mail($email, "Регистрация на сайте ".SITEDIR, "Вы успешно зарегистрированы на сайте http://".$_SERVER['SERVER_NAME'].":\nВаш логин: {$login}\nВаш пароль: {$password}", "From: escl.iecms@".$_SERVER['SERVER_NAME']."\r\n");
			$type = 1;
			$message = "Вы успешно зарегистрированы! Авторизуйтесь на сайте для дальнейших действий.";
		} else {
			$type = 2;
			$message = "Регистрация не удалась";
		}
	} else {
		$type = 2;
		$message = '';
		foreach($err AS $error)
			$message .= $error."<br>";
	}	
	return array('type' => $type, 'msg' => $message);
}