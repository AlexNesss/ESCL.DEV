<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'lostpwd';

#Заголовок страницы
$tpl->changeTitle('Восстановление пароля');
	
$nav[] = array('name' => 'Админки');

if (isset($_POST['password']) AND isset($_POST['password1']) AND isset($_GET['id']) AND isset($_GET['hash']) AND !$userinfo['group']) 
{
    $recovery_id = intval($_GET['id']);
	$recovery_hash = trim(htmlspecialchars(stripslashes($_GET['hash'])));
	$password = $_POST['password'];
    $password1 = $_POST['password1'];
	# Делаем переменные безопасными для использования
	$password = trim(htmlspecialchars(stripslashes($password)));
	$password1 = trim(htmlspecialchars(stripslashes($password1)));
	$mdPassword = md5($password);
	$mdPassword1 = md5($password1);
	# Создаем пустой массив ошибок
	$err = array();
    if (empty($password) or empty($password1)) 
    {
		$tpl->content .=  $eng->msg("2", "Вы ввели не всю информацию", "2"); 
		$tpl->content .=  '<meta http-equiv="refresh" content="3;URL=http://'.$_SERVER['SERVER_NAME'].'/lostpwd.">';
		echo $tpl->content;
		require_once TPL."footer.php";
		exit();
	}
	# пароли не совпадают
	if ($mdPassword != $mdPassword1)
	{
		$err[] = 'Пароли не совпадают';
	}
	# проверка на длину пароля
	if(strlen($password) < 6)
	{
		$err[] = 'Длина пароля должна быть не менее 6 символов';
	}
	# Если ошибок нет
	if(count($err) == 0) {
		$sql = mysql_query ("UPDATE `users` SET `password` = '{$mdPassword}' WHERE `id` = '{$recovery_id}'") or die(mysql_error());
		if ($sql)
		{
			mysql_query ("DELETE FROM `recovery` WHERE `id` = '{$recovery_id}' AND `hash` = '{$recovery_hash}'") or die(mysql_error());
			$tpl->content .=  $eng->msg("1", "Пароль успешно изменен", "1");
			$redirect = '/';
		} else {
			$tpl->content .=  $eng->msg("2", "Смена пароля не была произведена", "2");
			$redirect = '/lostpwd';
		}
	# Если ошибки есть
	} else {
		$errormsg = '';
		foreach($err AS $error)
		{
			$errormsg .= $error."<br>";
		}
		$tpl->content .=  $eng->msg("2", $errormsg, "2");
		$redirect = '/reg';
	}
	$tpl->content .=  '<meta http-equiv="refresh" content="5;URL=http://'.$_SERVER['SERVER_NAME'].''.$redirect.'">';
	echo $tpl->content;
	require_once TPL."footer.php";
	exit();
}
else if (isset($_GET['id']) AND isset($_GET['hash']) AND $userinfo['group'] == 0) {
    $recovery_id = intval($_GET['id']);
	$recovery_hash = trim(htmlspecialchars(stripslashes($_GET['hash'])));
	$sql = mysql_query ("SELECT * FROM `recovery` WHERE `id` = '{$recovery_id}' AND `hash` = '{$recovery_hash}'") or die(mysql_error());
	if (mysql_num_rows($sql) > 0) {
	    $tpl->content .=  '<form name="form" class="form-horizontal well" onsubmit="return validate_p()" method="post" autocomplete="off">
            <div class="control-group"><label class="control-label" for="password">Пароль:&nbsp;&nbsp;&nbsp;</label>
            <input name="password" id="password" type="password" size="15" maxlength="30"> <br /><span style="color:red; margin-left:150px;" id="passwordf"></span></div>
            <div class="control-group"><label class="control-label" for="password1">Новый пароль:&nbsp;&nbsp;&nbsp;</label>
            <input name="password1" id="password1" type="password" size="15" maxlength="30"> <br /><span style="color:red; margin-left:150px;" id="password1f"></span></div>
            <div class="form-actions"><input type="submit" class="btn btn-info" name="submit" value="Отправить"></div>
        </form>';	    
	} else {
	    $tpl->content .=  $eng->msg("2", "Заявки с данными параметрами на восстановление пароля не существует", "2");
		echo $tpl->content;
		require_once TPL."footer.php";
		exit();
	}
}
else if (!empty($_POST['email']) AND $userinfo['group'] == 0) {
    $email = mysql_real_escape_string($_POST['email']);
    if(!preg_match("/^[A-Z0-9._-]+@[A-Z0-9.-]{1,61}\.[A-Z]{2,6}$/i", $email)){ 
        $tpl->content .=  $eng->msg("2", "Формат почтового ящика не корректен", "2");
		echo $tpl->content;
	    require_once TPL."footer.php";
	    exit();
    }
	$sql = mysql_query ("SELECT * FROM `users` WHERE `email` = '{$email}'") or die(mysql_error());
	if (mysql_num_rows($sql)) {
	    $row = mysql_fetch_assoc($sql);
		$hash = md5($eng->GenerateKey(10));
		$sql = mysql_query("INSERT INTO `recovery` (`id`, `hash`) VALUES ('{$row['id']}', '{$hash}');") or die(mysql_error());
		if ($sql) {
		    mail($email, "Восстановление пароля на сайте {$_SERVER['SERVER_NAME']}", "Пройдите по ссылке для восстановления пароля:\nhttp://".$_SERVER['SERVER_NAME']."/index?v=lostpwd&hash=".$hash."&id=".$row['id']."", "From: no-reply@bymirror.ru{$_SERVER['SERVER_NAME']}\r\n"); 
            $tpl->content .=  $eng->msg("1", "На ваш почтовый ящик была выслана инструкция по восстановлению пароля.", "1");
			$tpl->content .=  '<meta http-equiv="refresh" content="4;URL=http://'.$_SERVER['SERVER_NAME'].'">';
	    }
	} else {
	    $tpl->content .=  $eng->msg("2", "Не найдено пользователя с данным почтовым ящиком", "2");
		$tpl->content .=  '<meta http-equiv="refresh" content="3;URL=http://'.$_SERVER['SERVER_NAME'].'/lostpwd">';
	}
}
else if (!$userinfo['group']){
	$tpl->content .=  '<form name="form" class="form-horizontal well" onsubmit="return validate_m()" method="post" autocomplete="off">
		<div class="control-group"><label class="control-label" for="email">Почтовый ящик:&nbsp;&nbsp;&nbsp;</label>
		<input name="email" id="email" type="text" size="15" maxlength="30"> <span style="color:red;" id="emailf"></span></div>
		<div class="form-actions"><input type="submit" class="btn btn-info" name="submit" value="Отправить"></div>
		</form>';
} else
    $tpl->content .=  $eng->msg("2", "Вы уже авторизованы", "2");