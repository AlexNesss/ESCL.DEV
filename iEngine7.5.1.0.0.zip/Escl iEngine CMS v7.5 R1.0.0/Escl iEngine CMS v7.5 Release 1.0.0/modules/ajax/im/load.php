<?php
#Открываем сессию и задаем дефайны
session_start();
define ('BYESCL', true);
define ('FUNCFILE', true);
define ('CLASSDIR', '../../../');

#Подключаем главный файл
require_once CLASSDIR."core/maincore.php";

header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
header("Content-Type: text/javascript; charset=utf-8");

if(isset($_POST['act'])) 
	switch ($_POST['act'])
	{
		#Старые сообщения
		case "old_posts":
			old_posts();
			break;
		#Новые сообщения
		case "new_posts":
			new_posts();
			break;
		default :
			header("Location: index.php");
			exit();
	}

#Новые посты
function new_posts() 
{
	global $db, $userinfo, $us, $eng;
	if(!isset($_POST['first']) OR empty($_POST['dialog'])) exit();
	$first_im_id = intval($_POST['first']);
	$dialog = intval($_POST['dialog']);
	$sql = $db->query("SELECT * FROM `dialogs` WHERE `id` = '{$dialog}' AND !FIND_IN_SET('{$userinfo['id']}',`deleted`) AND (`from` = '{$userinfo['id']}' OR FIND_IN_SET('{$userinfo['id']}',`invites`))");
	if($db->num_rows($sql) > 0)
	{
		$rw = $db->fetch_array($sql);
		$query = "SELECT * FROM `pm` WHERE `id` > '{$first_im_id}' AND `dialog` = '{$dialog}' ORDER BY `id` DESC LIMIT 20";
		if($rw['type'] == 'talk' AND $rw['from'] != $userinfo['id'])
		{
			$talks = explode(",", $rw['invites']);
			$tm = explode(",", $rw['timestamp']);
			$find = array_search($userinfo['id'], $talks);
			$timeset = $tm[$find];
			$query = "SELECT * FROM `pm` WHERE `id` > '{$first_im_id}' AND `dialog` = '{$dialog}' AND `date` > '{$timeset}' ORDER BY `id` DESC LIMIT 20";
		}
		$sql = $db->query($query);
		if($db->num_rows($sql) > 0)
		{
			$messages = array();
			$prepareusers = array();
			$getsmiles = $eng->getsmiles();
			
			while($row = $db->fetch_array($sql))
			{
				$messages[] = $row;
				$prepareusers[] = $row['user_id'];
			}
			$users = $us->ausers($prepareusers, 1);
			$js = '';
			foreach($messages AS $key => $value) 
			{
				$date = $eng->showtime($value['date'], 0); 				
				$js .= "
				<div id='".$value['id']."' class='messages'";
					$views = explode(",", $value['status']);
					if($rw['type'] == 'talk' AND count($views) == 1)
						$js .= " style='background-color: #BDDBF9;'";
					if($rw['type'] == 'dialog' AND ($value['user_id'] == $userinfo['id'] AND count($views) == 1) OR ($value['user_id'] != $userinfo['id'] AND !array_key_exists($userinfo['id'], $views)))
						$js .= " style='background-color: #BDDBF9;'";
						$js .= ">
						<div class='msg_item'>
						<div class='mi_iwrap'>
							<img src='".$us->avatar($value['user_id'])."' class='mi_img'>
						</div>
						<div class='mi_cont'>
							<div class='mi_head'>
								<p class='mi_date'>";
								if($value['user_id'] == $userinfo['id'] OR $us->agsearch('im'))
									$js .= "<span class='icon-remove pmdel' onclick='delete_pm(".$value['id'].")'></span> ";
								$js .= $date."</p>
								<a class='mi_author' target='_blank' href='".SITEDIR."".BASEDIR."/profile_".$value['user_id']."'>".$users[$value['user_id']]."</a>
							</div>
							<div class='mi_body'>
								<div class='mi_text'>".$eng->replace_smiles($value['text'], $getsmiles['search'], $getsmiles['replace'])."</div>
							</div>
						</div>
					</div>
				</div>";			
			}
			echo $js;
			#Делаем сообщения прочитанными
			$db->query("UPDATE `pm` SET `status` = concat(`status`, ',{$userinfo['id']}') WHERE `dialog` = '{$dialog}' AND !FIND_IN_SET('{$userinfo['id']}',`status`)");
		}	
	}
}

#Старые посты
function old_posts() 
{
	global $db, $userinfo, $us, $eng;
	if(empty($_POST['last']) OR empty($_POST['dialog'])) exit();
	$last_im_id = intval($_POST['last']);
	$dialog = intval($_POST['dialog']);
	$sql = $db->query("SELECT * FROM `dialogs` WHERE `id` = '{$dialog}' AND !FIND_IN_SET('{$userinfo['id']}',`deleted`) AND (`from` = '{$userinfo['id']}' OR FIND_IN_SET('{$userinfo['id']}',`invites`))");
	if($db->num_rows($sql) > 0)
	{
		$rw = $db->fetch_array($sql);
		$query = "SELECT * FROM `pm` WHERE `id` < '{$last_im_id}' AND `dialog` = '{$dialog}' ORDER BY `id` DESC LIMIT 20";
		if($rw['type'] == 'talk' AND $rw['from'] != $userinfo['id'])
		{
			$talks = explode(",", $rw['invites']);
			$tm = explode(",", $rw['timestamp']);
			$find = array_search($userinfo['id'], $talks);
			$timeset = $tm[$find];
			$query = "SELECT * FROM `pm` WHERE `id` < '{$last_im_id}' AND `dialog` = '{$dialog}' AND `date` > '{$timeset}' ORDER BY `id` DESC LIMIT 20";
		}
		$sql = $db->query($query);
		if($db->num_rows($sql) > 0)
		{
			$messages = array();
			$prepareusers = array();
			$getsmiles = $eng->getsmiles();
			
			while($row = $db->fetch_array($sql))
			{
				$messages[] = $row;
				$prepareusers[] = $row['user_id'];
			}
			$users = $us->ausers($prepareusers, 1);
			$js = '';
			foreach($messages AS $key => $value) 
			{
				$date = $eng->showtime($value['date'], 0); 				
				$js .= "
				<div id='".$value['id']."' class='messages'";
					$views = explode(",", $value['status']);
					if($rw['type'] == 'talk' AND count($views) == 1)
						$js .= " style='background-color: #BDDBF9;'";
					if($rw['type'] == 'dialog' AND ($value['user_id'] == $userinfo['id'] AND count($views) == 1) OR ($value['user_id'] != $userinfo['id'] AND !array_key_exists($userinfo['id'], $views)))
						$js .= " style='background-color: #BDDBF9;'";
						$js .= ">
						<div class='msg_item'>
						<div class='mi_iwrap'>
							<img src='".$us->avatar($value['user_id'])."' class='mi_img'>
						</div>
						<div class='mi_cont'>
							<div class='mi_head'>
								<p class='mi_date'>";
								if($value['user_id'] == $userinfo['id'] OR $us->agsearch('im'))
									$js .= "<span class='icon-remove pmdel' onclick='delete_pm(".$value['id'].")'></span> ";
								$js .= $date."</p>
								<a class='mi_author' target='_blank' href='".SITEDIR."".BASEDIR."/profile_".$value['user_id']."'>".$users[$value['user_id']]."</a>
							</div>
							<div class='mi_body'>
								<div class='mi_text'>".$eng->replace_smiles($value['text'], $getsmiles['search'], $getsmiles['replace'])."</div>
							</div>
						</div>
					</div>
				</div>";				
			}
			echo $js;
		}	
	}
}
mysql_close();