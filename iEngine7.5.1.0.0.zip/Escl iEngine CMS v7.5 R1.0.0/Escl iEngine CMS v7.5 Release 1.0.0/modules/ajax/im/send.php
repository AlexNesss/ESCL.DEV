<?php
#Открываем сессию и задаем дефайны
session_start();
define ('BYESCL', true);
define ('FUNCFILE', true);
define ('CLASSDIR', '../../../');

#Подключаем главный файл
require_once CLASSDIR."core/maincore.php";

header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache"); 
header("Content-Type: text/javascript; charset=utf-8");

if(isset($_POST['act']) AND $_POST['act']  == 'im_post' AND !empty($_POST['dialog']) AND !empty($_POST['text']))
	im_post();
else
	exit('Нет доступа');

#Отправка сообщения
function im_post() 
{
	global $db, $userinfo, $us, $eng;
	$result = array('status' => 'error');
	if($userinfo['group'] > 0 AND $us->agsearch('immsg')) 
	{
		$dialog = intval($_POST['dialog']);
		$sql = $db->query("SELECT * FROM `dialogs` WHERE `id` = '{$dialog}'");
		if($db->num_rows($sql) > 0)
		{
			$row = $db->fetch_array($sql);
			$invites = explode(",", $row['invites']);
			$deleted = explode(",", $row['deleted']);
			if(!in_array($userinfo['id'], $deleted) AND ($row['from'] == $userinfo['id'] OR in_array($userinfo['id'], $invites)))
			{
				$text = $eng->input($_POST['text']);
				if(!empty($text))
				{
					$db->query("INSERT INTO `pm` (`id`, `dialog`, `user_id`, `date`, `text`, `status`) VALUES (NULL, '{$dialog}', '{$userinfo['id']}', '".time()."', '{$text}', '{$userinfo['id']}');");
					$db->query("UPDATE `dialogs` SET `lastmsg` =  '".mysql_insert_id()."' WHERE `id` = '{$dialog}'");
					$result = array('status' => 'success');
				}
			}
		}
	}
	echo json_encode($result);
}
mysql_close();
?>