<?php
#Открываем сессию и задаем дефайны
session_start();
define ('BYESCL', true);
define ('FUNCFILE', true);
define ('CLASSDIR', '../../../');

#Подключаем главный файл
require_once CLASSDIR."core/maincore.php";

header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache"); 
header("Content-Type: text/javascript; charset=utf-8");

if(isset($_POST['act']) AND $_POST['act'] == 'check')
	im_check();
else
	exit('Нет доступа');

function im_check() {
    global $db, $userinfo;
    if ($userinfo['group'] > 0) 
	{
        $sql = $db->query("SELECT * FROM `dialogs` WHERE !FIND_IN_SET('{$userinfo['id']}',`deleted`) AND (`from` = '{$userinfo['id']}' OR FIND_IN_SET('{$userinfo['id']}',`invites`))");
		$row = $db->fetch_array($sql);
		$id = array();
        while($row = $db->fetch_array($sql))
		{
			$id[] = $row['id'];
		}
		$list = implode(',', $id);
		$sql = $db->query("SELECT count(*) AS `count` FROM `pm` WHERE `user_id` != '{$userinfo['id']}' AND !FIND_IN_SET('{$userinfo['id']}', `status`) AND `dialog` IN({$list})");
		$row = $db->fetch_array($sql);
		echo $row['count'];
    } else
        echo 0;
}
mysql_close();