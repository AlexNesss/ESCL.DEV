<?php
#Открываем сессию и задаем дефайны
session_start();
define ('BYESCL', true);
define ('FUNCFILE', true);
define ('CLASSDIR', '../../../');

#Подключаем главный файл
require_once CLASSDIR."core/maincore.php";

header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache"); 
header("Content-Type: text/javascript; charset=utf-8");

if(isset($_POST['act']) AND $_POST['act'] = 'delpost' AND !empty($_POST['postid']))
	im_post_del();
else
	exit('Нет доступа');

#Удаление сообщения
function im_post_del() 
{
	global $db, $userinfo, $us;
	$result = array('status' => 'error');
	if($userinfo['group'] > 0) 
	{
		$postid = intval($_POST['postid']);
		$sql = $db->query("SELECT * FROM `pm` WHERE `id` = '{$postid}'");
		if($db->num_rows($sql) > 0)
		{
			$row = $db->fetch_array($sql);
			$dialog = $row['dialog'];
			if($row['user_id'] == $userinfo['id'] OR $us->agsearch('imdel'))
			{
				$sql = $db->query("DELETE FROM `pm` WHERE `id` = '{$postid}'");
				$sql = $db->query("SELECT * FROM `pm` WHERE `dialog` = '{$dialog}' ORDER BY `id` DESC LIMIT 1");
				if($db->num_rows($sql) > 0)
				{
					$row = $db->fetch_array($sql);
					$lastid = $row['id'];
				} else 
					$lastid = 0;
				$sql = $db->query("UPDATE `dialogs` SET `lastmsg` = '{$lastid}' WHERE `id` = '{$dialog}'");
				$result = array('status' => 'success');
			}
		}
	}
	echo json_encode($result);
}
mysql_close();