<?php
#Открываем сессию и задаем дефайны
session_start();
define ('BYESCL', true);
define ('FUNCFILE', true);
define ('CLASSDIR', '../../../');

#Подключаем главный файл
require_once CLASSDIR."core/maincore.php";

header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");

if(!isset($_POST['act']) OR (isset($_POST['act']) AND $_POST['act'] != "get_status")) 
	exit('Нет доступа');

echo get_status();

function format_sroklist($sroks, $active = -1, $list = "", $cost = -1)
{
	global $eng;
	
	foreach ($sroks AS $srok => $price)
	{
		$time = (!$srok) ? 'Навсегда' : $eng->declOfNum($srok, array('День','Дня','Дней'));
		
		if($active == $srok)
			$cost = $price;
			
		$list .= "<label class='radio'><input type='radio' name='srok' value='".$srok."' ".($active == $srok ? "checked" : "")."> ".$time."</label>\r\n";
	}
	return "\r\n".$list."\r\n".($cost != -1 ? "<br /><h5>Ваша цена: <font color='green'><b>{$cost}</b></font> рублей</h5>" : "");
}

function format_tarifslist($tarif, $active = -1, $list = "")
{
	foreach ($tarif as $name=>$value)
		$list .= "<label class='radio'><input type='radio' name='tarif' value='".$name."' ".($active == $name ? "checked" : "")."> ".$value['name']." (Флаги: ".$value['flags'].")</label>\r\n";
	return "\r\n".$list."\r\n";
}

function get_status() 
{
	global $db, $msg,$eng;
	
	$step = array(); # пройденные этапы
	
	#Если пост запроса с номером сервера нет то заканчиваем [1 этап] [Должно быть: ничего]
	if(empty($_POST['server'])) 
		return $eng->msg("2", "Сервер не выбран", "2");
	
	#Собираем список серверов у которых доступна оплата
	$server = intval($_POST['server']);
	$sql = $db->query("SELECT * FROM `servers` WHERE `id` = '{$server}' AND `pay` = '1'");
	
	#Если сервера нет заканчиваем
	if(!$db->num_rows($sql)) 
		return $eng->msg("2", "Сервера не существует", "2");
	$step[1] = true;
	
	#Собираем список услуг [2 этап] [Должно быть: номер сервера]
	if(!empty($_POST['server']) AND isset($step[1]))
	{
		$artarifs = array(); # массив с параметрами услуги [Название, Выдаваемые флаги, Цены]
		
		#Собираем список услуг которые есть у данного сервера
		$sql = $db->query("SELECT * FROM `tarifs` WHERE `server_id` = '{$server}'");
		#Если услуг нет заканчиваем
		if(!$db->num_rows($sql)) 
			return $eng->msg("2", "Услуг на сервере не найдено", "2");
		while($row = $db->fetch_array($sql))
			$artarifs[$row['id']] = array('name' => $row['name'], 'flags' => $row['flags'], 'price' => $row['price']);		
			
		echo '<fieldset onchange="onchangepay()">
				<div class="control-group">
					<label class="control-label" for="name">Услуги: </label>
					<div class="controls">
						'.( empty($_POST['tarif']) ? format_tarifslist($artarifs) : format_tarifslist($artarifs, intval($_POST['tarif'])) ).'
					</div>
				</div>
			  </fieldset>';
		$step[2] = true;
	}
	
	#Собираем список сроков [3 этап] [Должно быть: номер сервера, номер услуги]
	if(!empty($_POST['tarif']) AND isset($step[2]))
	{
		$tarif = intval($_POST['tarif']); # Получаем номер услуги
		
		if(!isset($artarifs[$tarif]['price'])) # Если для данного тарифа не найдено сроков и ценников то долой такой тариф =)
			return;
			
		$priceinfo = unserialize($artarifs[$tarif]['price']); # Информация о ценниках и сроках на услуги
		echo '<fieldset onchange="onchangepay()">
				<div class="control-group">
					<label class="control-label">Срок: </label>
					<div class="controls">
						'.( !isset($_POST['srok']) ? format_sroklist($priceinfo) : format_sroklist($priceinfo,intval($_POST['srok']))).'
					</div>
				</div>
			  </fieldset>';
		$step[3] = true;
	}
	
	#Выводим тип админки [4 этап] [Должно быть: номер сервера, номер услуги, время срока]
	if(isset($_POST['srok']) AND isset($step[3]))
	{
		echo '<fieldset onchange="onchangepay()">	
				<div class="control-group">
					<label class="control-label" for="steamid">Тип: </label>
					<div class="controls">
						<label class="radio"><input type="radio" name="type" value="steamid" '.((!empty($_POST['type']) AND $_POST['type'] == 'steamid') ? 'checked' : '').'> SteamID/ValveID</label>
						<label class="radio"><input type="radio" name="type" value="ip" '.((!empty($_POST['type']) AND $_POST['type'] == 'ip') ? 'checked' : '').'> IP</label>
						<label class="radio"><input type="radio" name="type" value="nick" '.((!empty($_POST['type']) AND $_POST['type'] == 'nick') ? 'checked' : '').'> Ник</label>
					</div>
				</div>	
			  </fieldset>';
		$step[4] = true;
	}	

	#Выводим поле для ввода ника/steamid/ip [5 этап] [Должно быть: номер сервера, номер услуги, время срока, тип админки]	
	if(!empty($_POST['type']) AND isset($step[4]))
	{
		$types = array('steamid', 'ip', 'nick');	# Отсутствует указанный тип
		if (!in_array($_POST['type'], $types))
			return;
			
		echo '<fieldset>	
		<div class="control-group">
			<label class="control-label">';
		
		if($_POST['type'] == 'steamid')
			echo 'SteamID/ValveID';

		if($_POST['type'] == 'ip')
			echo 'IP';

		if($_POST['type'] == 'nick')
			echo 'Ник';	
						
		echo ': </label>
					<div class="controls">
						<input name="value" type="text" size="15" value="'. (!empty($_POST['data']) ? htmlspecialchars($_POST['data']) : '') .'" required>
					</div>	
				</div>	
			</fieldset>		
			<div class="controls"><span onclick="checkbuy()" class="btn btn-danger">Купить</span></div>';
	}
}
mysql_close();