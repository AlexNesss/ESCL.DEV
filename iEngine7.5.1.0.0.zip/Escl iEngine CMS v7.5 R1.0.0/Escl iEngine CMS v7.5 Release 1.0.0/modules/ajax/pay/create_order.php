<?php
#Открываем сессию и задаем дефайны
session_start();
define ('BYESCL', true);
define ('FUNCFILE', true);
define ('CLASSDIR', '../../../');

require_once CLASSDIR."core/maincore.php";

if(empty($_POST['tarif']) OR empty($_POST['server']) OR !isset($_POST['srok']) OR empty($_POST['type']))
	exit();

if(!$userinfo['group'])
	exit( json_encode ( array ( 'status' => 'error', 'text' => 'Авторизуйтесь, чтобы совершить оплату' ) ) );
	
$server = intval($_POST['server']);

$sql = $db->query("SELECT * FROM `servers` WHERE `id` = '{$server}' AND `pay` = '1'");

if(!$db->num_rows($sql))
	exit( json_encode ( array ( 'status' => 'error', 'text' => 'Сервера не существует, либо оплата недоступна' ) ) );
	
$tarif = intval($_POST['tarif']);

$sql = $db->query("SELECT * FROM `tarifs` WHERE `id` = '{$tarif}'");

if(!$db->num_rows($sql))
	exit( json_encode ( array ( 'status' => 'error', 'text' => 'Тариф не существует' ) ) );
	
$row = $db->fetch_array($sql);

$option = $row['flags'];

$pricelist = unserialize($row['price']);
 
$srok = intval($_POST['srok']);

if(!isset($pricelist[$srok]))
	exit( json_encode ( array ( 'status' => 'error', 'text' => 'Указанного срока заказа не найдено у данной услуги' ) ) );

$cost = $pricelist[$srok];

$type = filter_input(INPUT_POST, 'type');

if ( !in_array( $type, array('steamid', 'ip', 'nick') ) )
	exit( json_encode ( array ( 'status' => 'error', 'text' => 'Указанный тип отсутствует' ) ) );
	
if(empty($_POST['value']))
	exit( json_encode ( array ( 'status' => 'error', 'text' => 'Не все данные введены' ) ) );
	
switch($type)
{
	case "steamid":		
		$value = filter_input(INPUT_POST, 'value');
		if(!preg_match("/^(STEAM|VALVE)_[0-9]:[0-9]:[0-9]{4,15}$/", $value))
			exit( json_encode ( array ( 'status' => 'error', 'text' => 'Неверный SteamID/ValveID' ) ) );
		break;
	case "ip":
		$value = filter_input(INPUT_POST, 'value');
		if(!filter_var($value, FILTER_VALIDATE_IP))
			exit( json_encode ( array ( 'status' => 'error', 'text' => 'Неверный IP' ) ) );
		break;
	case "nick":
		$value = filter_input(INPUT_POST, 'value', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
		break;
}

$number_order = (int)substr(preg_replace("/\D/","",sha1(microtime(1))),0,mt_rand(7,9));
$order_desc = base64_encode("Оплата админки/випки по счету #{$number_order}");
$prolong = 0;

$sql = $db->query("SELECT * FROM `accounts` WHERE `server` = '{$server}' AND `value` = '{$value}'");

if($db->num_rows($sql))
{
	$row = $db->fetch_array($sql);
	
	if($row['user_id'] != $userinfo['id'])
		exit( json_encode ( array ( 'status' => 'error', 'text' => 'Невозможно продлить чужую админку/випку' ) ) );
		
	$prolong = $row['id'];
	$type = $row['type'];
	
	if($option == $row['option'])
	{
		if(!$row['date_end'])
			exit( json_encode ( array ( 'status' => 'error', 'text' => 'Админка/випка уже продлена навсегда' ) ) );
	} else {
		if($row['date_end'] > time())
		{
			$days = intval(($row['date_end'] - time()) / 86400);
			
			if($days) 
				$srok += round($days * mb_strlen($row['option'],'UTF-8') / mb_strlen($option,'UTF-8') / 2);
		}
	}
}

$db->query("DELETE FROM `buy_order` WHERE (`value` = '{$value}' AND `type` = '{$type}' AND `user_id` = '{$userinfo['id']}') OR `time` < '".(time() - 86400)."'");
	
$db->query("INSERT INTO `buy_order` (`id`, `number_order`, `user_id`, `server`, `value`, `option`, `srok`, `type`, `prolong`, `cost`, `time`) 
	VALUES (NULL, '{$number_order}', '{$userinfo['id']}', '{$server}', '{$value}', '{$option}', '{$srok}', '{$type}', '{$prolong}', '{$cost}', '".time()."')");

$result = array('status' => 'success', 
				'id' => mysql_insert_id(), 
				'order' => $number_order, 
				'cost' => $cost.'.00', 
				'desc' => $order_desc, 
				'purse' => $wmr /* в maincore.php*/);

echo json_encode($result);

mysql_close();