<?php
#Открываем сессию и задаем дефайны
session_start();
define ('BYESCL', true);
define ('FUNCFILE', true);
define ('CLASSDIR', '../../../');

#Подключаем главный файл
require_once CLASSDIR."core/maincore.php";

if( !isset($_POST['LMI_PREREQUEST']) OR (isset($_POST['LMI_PREREQUEST']) AND $_POST['LMI_PREREQUEST'] != 1) )
	exit("НЕИЗВЕСТНЫЙ ИСТОЧНИК ДАННЫХ");

foreach($_POST AS &$val) 
   $val = mysql_real_escape_string(trim($val));
 
extract($_POST, EXTR_SKIP);

if($LMI_PAYEE_PURSE != $wmr)
	exit("ПОДМЕНА КОШЕЛЬКА ОПЛАТЫ");
 
if(empty($LMI_PAYMENT_NO) OR empty($id))
	exit("НЕВЕРНЫЙ НОМЕР ЗАКАЗА");
	
$sql = $db->query("SELECT * FROM `buy_order` WHERE `id` = '{$id}' AND `number_order` = '{$LMI_PAYMENT_NO}'");

if(!$db->num_rows($sql))
	exit("ЗАКАЗ НЕ СУЩЕСТВУЕТ");

$row = $db->fetch_array($sql);

if($LMI_PAYMENT_AMOUNT != $row['cost'])
	exit("НЕВЕРНАЯ СУММА ЗАКАЗА");
	
if($row['prolong'])
{
	$acsql = $db->query("SELECT * FROM `accounts` WHERE `id` = '{$row['prolong']}'");
	
	if(!$db->num_rows($acsql))
		exit('ПРОДЛЕВАЕМЫЙ АККАУНТ НЕ СУЩЕСТВУЕТ');
	
	$acrow = $db->fetch_array($acsql);
	
	$srok = 0;
	
	if($row['srok'])
		$srok = ($row['srok']*86400);
		
	if($srok)
	{
		if($acrow['date_end'] <= time())
			$srok += time();
		else
			$srok += $acrow['date_end'];
	}
	
	$db->query("UPDATE `accounts` SET `server` = '{$row['server']}', `option` = '{$row['option']}', `date_create` = '".time()."', `date_end` = '{$srok}' WHERE `id` = '{$row['prolong']}'");	
} else {
	$srok = 0;
	if($row['srok'])
		$srok = (time()+($row['srok']*86400));
		
	$db->query("INSERT INTO `accounts` 
	(`id`, `user_id`, `password`, `type`, `date_create`, `day_counts`, `date_end`, `server`, `value`, `option`, `comment`) 
	VALUES (NULL, '{$row['user_id']}', '".$eng->GenerateKey(6)."', '{$row['type']}', '".time()."', '{$row['srok']}', '{$srok}', '{$row['server']}', '{$row['value']}', '{$row['option']}', 'Купленный аккаунт')");
}	

$db->query("DELETE FROM `buy_order` WHERE `id` = '{$id}'");

echo "YES";

mysql_close();