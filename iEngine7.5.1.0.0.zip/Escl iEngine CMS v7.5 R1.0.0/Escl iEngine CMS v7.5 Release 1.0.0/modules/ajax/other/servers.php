<?php
#Открываем сессию и задаем дефайны
session_start();
define ('BYESCL', true);
define ('FUNCFILE', true);
define ('CLASSDIR', '../../../');

#Подключаем главный файл
require_once CLASSDIR."core/maincore.php";

header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache"); 
header("Content-Type: text/javascript; charset=utf-8");

if(!isset($_POST['act']) OR  isset($_POST['act']) AND $_POST['act'] != 'servers')
	exit('Нет доступа');
	
$servers = array();
$sql = $db->query("SELECT * FROM `servers`");
while($row = $db->fetch_array($sql))
{
	if($row['maxplayers'] > 0)
		$full_off = round(($row['players']/$row['maxplayers'])*100);
	else
		$full_off = 0;
	switch($full_off)
	{
		case $full_off<=40:
		$full_off_color = 'success';
		break;
		case $full_off<=80:
		$full_off_color = 'warning';
		break;
		case $full_off<=100:
		$full_off_color = 'danger';
		break;
		default:
		$full_off_color = 'success';
		break;
	}
	$servers[$row['id']] = array(
					'hostname' => $row['hostname'], 
					'map' => $row['map'],
					'players' => "<div style='position: relative;'><div class='progress progress-{$full_off_color} progress-striped' style='margin-bottom: 0px;'><div class='bar' style='width: {$full_off}%'></div><div style='position: absolute;width: 100%;'><center><a data-toggle='modal' href='".SITEDIR.BASEDIR."/players_{$row['id']}' data-target='#modalpl{$row['id']}'>{$row['players']}/{$row['maxplayers']}</a></center></div></div></div>"
				);
}
echo json_encode($servers);
mysql_close();