<?php
session_start();
define ('BYESCL', true);
define ('CLASSDIR', '../../../');
require_once CLASSDIR."core/maincore.php";
if(empty($_GET['id']))
	exit('<center>Не введен номер сервера</center>');

$id = intval($_GET['id']);
$sql = mysql_query("SELECT * FROM `servers` WHERE `id` = '{$id}'") or die(mysql_error());
if(!mysql_num_rows($sql))
	exit('<center>Сервера не существует</center>');
	
$row = mysql_fetch_assoc($sql);

if(empty($row['playerslist'])) 
	exit('<center>В данный момент на сервере нет игроков</center>');
	
$i = 1;
$string = unserialize($row['playerslist']);
echo '<table class="table table-striped table-bordered table-condensed">
		<thead>
		<tr>
			<th width="20px"><b>Топ</b></th>
			<th><b>Ник</b></th>
			<th><b>Счёт</b></th>
			<th><b>Время игры</b></th>
		</tr>
		</thead>
		<tbody>';
unset($key); unset($value);
foreach($string AS $key => $value) 
{
	$num = (($i<=3) ? '<img src="http://'.$_SERVER['SERVER_NAME'].'/main/img/'.$i.'pl.gif" />' : $i);
	$value['time'] = sprintf('%02d:%02d:%02d', $value['time']/3600, ($value['time'] % 3600)/60, ($value['time'] % 3600) % 60); 
	echo '<tr><td>'.$num.'</td><td>'.$key.'</td><td>'.$value['frags'].'</td><td>'.$value['time'].'</td></tr>';
	$i++;
}
echo '</tbody>
</table>';