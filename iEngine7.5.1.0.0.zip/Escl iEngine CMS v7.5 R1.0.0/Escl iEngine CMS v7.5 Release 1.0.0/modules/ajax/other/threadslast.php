<?php
#Открываем сессию и задаем дефайны
session_start();
define ('BYESCL', true);
define ('FUNCFILE', true);
define ('CLASSDIR', '../../../');

#Подключаем главный файл
require_once CLASSDIR."core/maincore.php";

header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache"); 
header("Content-Type: text/javascript; charset=utf-8");

if(!isset($_POST['act']) OR  isset($_POST['act']) AND $_POST['act'] != 'threadslast')
{
	exit('Нет доступа');
}

$threads = array();

$sql = $db->query("SELECT `forums_messages`.`id`,`forums_messages`.`thread`, `forums_messages`.`time`, `forums_messages`.`user_id`, `forums_threads`.`title`, `forums_threads`.`for`, `forums_threads`.`view` FROM `forums_messages`, `forums_threads`  WHERE `forums_messages`.`id` IN (SELECT MAX(`id`) FROM `forums_messages` GROUP BY `thread`) AND `forums_threads`.`id` = `forums_messages`.`thread` ORDER BY `forums_messages`.`id` DESC LIMIT 5");

if($db->num_rows($sql) > 0) 
{ 
	$themes = array();
	$prepareusers = array();
	$count = array();
	$msgnum = array();
	
	while($row = $db->fetch_array($sql)) 
	{
		$themes[] = $row;
		$prepareusers[] = $row['user_id'];
		$count[] = $row['thread'];
	}
	
	$count_themes = implode(',', $count);
	
	$sql_count = $db->query("SELECT `thread`, count(`id`)-1 AS `count` FROM `forums_messages` WHERE `thread` IN({$count_themes}) GROUP BY `thread`");
	
	while($row_count = $db->fetch_array($sql_count)) 
		$msgnum[$row_count['thread']] = $row_count['count'];
		
	$users = $us->ausers($prepareusers, 1);
	
	$i = 1;
	foreach($themes AS $key => $value) 
	{
		$threads[$i] = array (
				'title' => '<a href="'.SITEDIR.''.BASEDIR.'/topic_'.$value['thread'].'"> '.$value['title'].'</a><br /><a class="linklastthread" href="'.SITEDIR.''.BASEDIR.'/forums_for_'.$value['for'].'"> Посмотреть раздел</a>',
				'otv' => 'Ответов: '.$msgnum[$value['thread']].'<br />Просмотров: '.$value['view'],
				'lastmsg' => '<i class="icon-time"></i> '.$eng->showtime(strtotime($value['time']), 1).'<br /><a class="linknormal" href="'.SITEDIR.''.BASEDIR.'/topic_'.$value['thread'].'_new">Посл. сообщение:</a> <a href="'.SITEDIR.''.BASEDIR.'/profile_'.$value['user_id'].'">'.$users[$value['user_id']].'</a>'
			);
		$i++;
	}
}
echo json_encode($threads);
mysql_close();