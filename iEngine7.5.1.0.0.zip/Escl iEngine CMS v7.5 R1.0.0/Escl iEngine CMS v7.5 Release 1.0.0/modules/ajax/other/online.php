<?php
#Открываем сессию и задаем дефайны
session_start();
define ('BYESCL', true);
define ('CLASSDIR', '../../../');

#Подключаем главный файл
require_once CLASSDIR."core/maincore.php";

header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache"); 
header("Content-Type: text/javascript; charset=utf-8");

if(isset($_POST['act']) AND $_POST['act'] == 'online')
	echo $us->who_online();
else {
	exit('Нет доступа');
}
mysql_close();