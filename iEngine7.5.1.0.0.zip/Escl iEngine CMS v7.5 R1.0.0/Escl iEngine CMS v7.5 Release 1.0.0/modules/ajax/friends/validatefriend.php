<?php
#��������� ������ � ������ �������
session_start();
define ('BYESCL', true);
define ('FUNCFILE', true);
define ('CLASSDIR', '../../../');

#���������� ������� ����
require_once CLASSDIR."core/maincore.php";

header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache"); 
header("Content-Type: text/javascript; charset=utf-8");

if(empty($_POST['user_id']))
	exit('��� �������');

$result = array('status' => 'error');

if($userinfo['group']) 
{
	$val_user = intval($_POST['user_id']);
	
	$sql = $db->query("SELECT * FROM `friends` WHERE `id` = '{$val_user}' AND FIND_IN_SET('{$userinfo['id']}', `invites`)"); // ���������
	
	if($db->num_rows($sql))
	{
		$row = $db->fetch_array($sql); 
		
		$sql = $db->query("SELECT * FROM `friends` WHERE `id` = '{$userinfo['id']}' AND FIND_IN_SET('{$val_user}', `toinvites`)"); // ��������
		
		if($db->num_rows($sql))
		{		
			$row_my = $db->fetch_array($sql);
			
			$row['invites'] = explode(",",$row['invites']);
			$row_my['toinvites'] = explode(",", $row_my['toinvites']);
			
			unset($row['invites'][array_search($userinfo['id'], $row['invites'])]);
			unset($row_my['toinvites'][array_search($val_user, $row_my['toinvites'])]); 	
			
			$row['invites'] = implode(",",$row['invites']);
			$row_my['toinvites'] = implode(",", $row_my['toinvites']);	

			$newfriend_my = (!empty($row_my['friends']) ? $row_my['friends'].','.$val_user : $val_user);
			$newfriend	= (!empty($row['friends']) ? $row['friends'].','.$userinfo['id'] : $userinfo['id']);
			
			$db->query("UPDATE `friends` SET `friends` = '{$newfriend}', `invites` = '{$row['invites']}' WHERE `id` = '{$val_user}'");		
			$db->query("UPDATE `friends` SET `friends` = '{$newfriend_my}', `toinvites` = '{$row_my['toinvites']}' WHERE `id` = '{$userinfo['id']}'");				
			$result = array('status' => 'success');
		}
	}
}
echo json_encode($result);
mysql_close();