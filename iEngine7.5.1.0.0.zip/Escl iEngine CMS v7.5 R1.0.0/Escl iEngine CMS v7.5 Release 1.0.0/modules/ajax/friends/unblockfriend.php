<?php
#Открываем сессию и задаем дефайны
session_start();
define ('BYESCL', true);
define ('FUNCFILE', true);
define ('CLASSDIR', '../../../');

#Подключаем главный файл
require_once CLASSDIR."core/maincore.php";

header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache"); 
header("Content-Type: text/javascript; charset=utf-8");

if(empty($_POST['user_id']))
	exit('Нет доступа');

$result = array('status' => 'error');

if($userinfo['group']) 
{
	$val_user = intval($_POST['user_id']);
	
	$sql = $db->query("SELECT * FROM `friends` WHERE `id` = '{$userinfo['id']}' AND FIND_IN_SET('{$val_user}', `blocked`)");
	
	if($db->num_rows($sql))
	{
		$row_my = $db->fetch_array($sql); 
		

			$row_my['blocked'] = explode(",",$row_my['blocked']);
			
			unset($row_my['blocked'][array_search($val_user, $row_my['blocked'])]);	
			
			$row_my['blocked'] = implode(",",$row_my['blocked']);	
			
			$db->query("UPDATE `friends` SET `blocked` = '{$row_my['blocked']}' WHERE `id` = '{$userinfo['id']}'");		
			$result = array('status' => 'success');
	}
}
echo json_encode($result);
mysql_close();