<?php
#Открываем сессию и задаем дефайны
session_start();
define ('BYESCL', true);
define ('FUNCFILE', true);
define ('CLASSDIR', '../../../');

#Подключаем главный файл
require_once CLASSDIR."core/maincore.php";

header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache"); 
header("Content-Type: text/javascript; charset=utf-8");

if(empty($_POST['user_id']))
	exit('Нет доступа');

$result = array('status' => 'error');

if($userinfo['group']) 
{
	$val_user = intval($_POST['user_id']);
	
	$sql = $db->query("SELECT * FROM `friends` WHERE `id` = '{$userinfo['id']}' AND FIND_IN_SET('{$val_user}', `friends`)");
	
	if($db->num_rows($sql))
	{
		$row_my = $db->fetch_array($sql); 
		
		$sql = $db->query("SELECT * FROM `friends` WHERE `id` = '{$val_user}' AND FIND_IN_SET('{$userinfo['id']}', `friends`)");
		
		if($db->num_rows($sql))
		{		
			$row = $db->fetch_array($sql);
			
			$row_my['friends'] = explode(",",$row_my['friends']);
			$row['friends'] = explode(",", $row['friends']);
			
			unset($row_my['friends'][array_search($val_user, $row_my['friends'])]);
			unset($row['friends'][array_search($userinfo['id'], $row['friends'])]); 	
			
			$row_my['friends'] = implode(",",$row_my['friends']);
			$row['friends'] = implode(",", $row['friends']);	
			
			$db->query("UPDATE `friends` SET `friends` = '{$row_my['friends']}' WHERE `id` = '{$userinfo['id']}'");		
			$db->query("UPDATE `friends` SET `friends` = '{$row['friends']}' WHERE `id` = '{$val_user}'");				
			$result = array('status' => 'success');
		}
	}
}
echo json_encode($result);
mysql_close();