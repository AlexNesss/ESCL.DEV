<?php
#Открываем сессию и задаем дефайны
session_start();
define ('BYESCL', true);
define ('FUNCFILE', true);
define ('CLASSDIR', '../../../');

#Подключаем главный файл
require_once CLASSDIR."core/maincore.php";

header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache"); 
header("Content-Type: text/javascript; charset=utf-8");

if(empty($_POST['user_id']))
	exit('Нет доступа');

$result = array('status' => 'error');

if($userinfo['group']) 
{
	$val_user = intval($_POST['user_id']);
	
	if($val_user != $userinfo['id'])
	{
		$sql = $db->query("SELECT * FROM `friends` WHERE `id` IN('{$val_user}','{$userinfo['id']}')");
		if($db->num_rows($sql) == 2)
		{
			$block = false;
			
			while($row = $db->fetch_array($sql)) 
			{
				$row['friends'] = explode(",", $row['friends']);
				$row['toinvites'] = explode(",", $row['toinvites']);
				$row['invites'] = explode(",", $row['invites']);
				$row['blocked'] = explode(",", $row['blocked']);
				
				$find_user = (($row['id'] == $val_user) ? $userinfo['id'] : $val_user);
				
				if (in_array($find_user, $row['friends']) OR in_array($find_user, $row['toinvites']) OR in_array($find_user, $row['invites']) OR in_array($find_user, $row['blocked']))
					$block = true;
					
				$row['toinvites'] = implode(",", $row['toinvites']);
				$row['invites'] = implode(",", $row['invites']);
				
				if($row['id'] == $userinfo['id'])
					$row_my['invites'] = $row['invites'];
				else
					$row_on['toinvites'] = $row['toinvites'];
			} 
			
			if(!$block)
			{
				$newinv_my = (!empty($row_my['invites']) ? $row_my['invites'].','.$val_user : $val_user);
				$newinv	= (!empty($row_on['toinvites']) ? $row_on['toinvites'].','.$userinfo['id'] : $userinfo['id']);
				
				$db->query("UPDATE `friends` SET `invites` = '{$newinv_my}' WHERE `id` = '{$userinfo['id']}'");		
				$db->query("UPDATE `friends` SET `toinvites` = '{$newinv}' WHERE `id` = '{$val_user}'");	
				$result = array('status' => 'success');				
			}
		} else if($db->num_rows($sql)){
			$block = false;
			$row = $db->fetch_array($sql);
			
			$row['friends'] = explode(",", $row['friends']);
			$row['toinvites'] = explode(",", $row['toinvites']);
			$row['invites'] = explode(",", $row['invites']);
			$row['blocked'] = explode(",", $row['blocked']);
			
			$find_user = (($row['id'] == $val_user) ? $userinfo['id'] : $val_user);
			
			if (in_array($find_user, $row['friends']) OR in_array($find_user, $row['toinvites']) OR in_array($find_user, $row['invites']) OR in_array($find_user, $row['blocked']))
				$block = true;
			
			if(!$block)
			{
				$row['toinvites'] = implode(",", $row['toinvites']);
				$row['invites'] = implode(",", $row['invites']);			
			
				if($row['id'] == $userinfo['id'])
				{
					$newinv_my = (!empty($row['invites']) ? $row['invites'].','.$val_user : $val_user);
					$db->query("UPDATE `friends` SET `invites` = '{$newinv_my}' WHERE `id` = '{$userinfo['id']}'");	
					$db->query("INSERT INTO `friends` (`id`, `friends`, `invites`, `toinvites`, `blocked`) VALUES ('{$val_user}', '', '', '{$userinfo['id']}', '')");
				} else {
					$newinv	= (!empty($row['toinvites']) ? $row['toinvites'].','.$userinfo['id'] : $userinfo['id']);
					$db->query("UPDATE `friends` SET `toinvites` = '{$newinv}' WHERE `id` = '{$val_user}'");
					$db->query("INSERT INTO `friends` (`id`, `friends`, `invites`, `toinvites`, `blocked`) VALUES ('{$userinfo['id']}', '', '{$val_user}', '', '')");					
				}
				
				$result = array('status' => 'success');
			}
			
		} else {
			$db->query("INSERT INTO `friends` (`id`, `friends`, `invites`, `toinvites`, `blocked`) VALUES ('{$val_user}', '', '', '{$userinfo['id']}', '')");
			$db->query("INSERT INTO `friends` (`id`, `friends`, `invites`, `toinvites`, `blocked`) VALUES ('{$userinfo['id']}', '', '{$val_user}', '', '')");
			
			$result = array('status' => 'success');
		}
	}
}
echo json_encode($result);
mysql_close();