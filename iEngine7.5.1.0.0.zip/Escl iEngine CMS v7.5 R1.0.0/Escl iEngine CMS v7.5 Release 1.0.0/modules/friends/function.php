<?php
if(!defined("BYESCL")) 
{
	header("Location: index.php");
	exit();
}

# bymirror v2 
/*
Описание: Выводит полный список друзей
Параметры: Остутствуют
*/
function viewfriends($user_id)
{
	global $db, $us, $eng, $nav;
	
	$nav[] = array('name' => 'Мои друзья');
	
	$sql = $db->query("SELECT * FROM `friends` WHERE `id` = '{$user_id}'");
	
	if(!$db->num_rows($sql))
		return '<legend>Ваши друзья</legend>'.$eng->msg(3, "Друзья отстутствуют", 3); 
		
	$row = $db->fetch_array($sql);
		
	$result = '';
	
	if(!empty($row['toinvites']))
	{
		$users = $us->ausers(explode(",", $row['toinvites']), 1);
		$result .= '<legend>Вам предложили подружиться ('.count($users).')</legend>
		<table class="table table-bordered">
			<thead>
				<th>Ник</th>
				<th width="200px">Действие</th>
			</thead>
		<tbody>';
		foreach($users AS $key => $value)
		{
			$result .= '<tr>
							<td><img class="avatarmini" src="'.$us->avatar($key).'"/> <a href="'.SITEDIR.''.BASEDIR.'/profile_'.$key.'">'.$value.'</td>
							<td><a class="btn-link" onclick="validatefriend('.$key.')">Одобрить</a> | <a class="btn-link" onclick="blockfriend('.$key.')">Заблокировать</a></td>
						</tr>';			
		}
		$result .= '</tbody>
		</table>';
	}
	
	$result .= '<legend>Ваши друзья</legend>';
	
	if(empty($row['friends']))
		$result .= $eng->msg(3, "Друзья отстутствуют", 3); 
	else {	
		$query = $db->query("SELECT * FROM `users` WHERE `id` IN({$row['friends']}) ORDER BY `group_id` DESC");
		if ($db->num_rows($query)) 
		{	
			$groups = $us->gnamelist();
			$result .= '<table class="table table-bordered">
				<thead>
					<th>Ник</th>
					<th>Группа</th>
					<th width="200px">Действие</th>
				</thead>
			<tbody>';
			while($row_list = $db->fetch_array($query)) 
			{
				$result .= '<tr>
								<td><img class="avatarmini" src="'.$us->avatar($row_list['id']).'"/> <a href="'.SITEDIR.''.BASEDIR.'/profile_'.$row_list['id'].'">'.$row_list['login'].'</td>
								<td>'.$groups[$row_list['group_id']].'</td> 
								<td><a href="'.SITEDIR.''.BASEDIR.'/createdialog_'.$row_list['id'].'">Отправить ЛС</a> <i onclick="if (confirm(\'Вы подтверждаете удаление?\')) delfriend('.$row_list['id'].')" class="icon-remove pull-right"></i></td>
							</tr>';
			}
			$result .= '</tbody>
			</table>';
		} else
			$result .= $eng->msg(3, "Друзья отстутствуют. Для добавления перейдите в один из профилей пользователей.", 3); 
	}

	if(!empty($row['invites']))
	{
		$users = $us->ausers(explode(",", $row['invites']), 1);
		$result .= '<legend>Исходящие заявки ('.count($users).')</legend>
		<table class="table table-bordered">
			<thead>
				<th>Ник</th>
				<th width="200px">Действие</th>
			</thead>
		<tbody>';
		foreach($users AS $key => $value)
		{
			$result .= '<tr>
							<td><img class="avatarmini" src="'.$us->avatar($key).'"/> <a href="'.SITEDIR.''.BASEDIR.'/profile_'.$key.'">'.$value.'</td>
							<td><a class="btn-link" onclick="delinvite('.$key.')">Отменить</a></td>
						</tr>';			
		}
		$result .= '</tbody>
		</table>';
	}
	
	if(!empty($row['blocked']))
	{
		$users = $us->ausers(explode(",", $row['blocked']), 1);
		$result .= '<legend>Ваши блокировки ('.count($users).')</legend>
		<table class="table table-bordered">
			<thead>
				<th>Ник</th>
				<th width="200px">Действие</th>
			</thead>
		<tbody>';
		foreach($users AS $key => $value)
		{
			$result .= '<tr>
							<td><img class="avatarmini" src="'.$us->avatar($key).'"/> <a href="'.SITEDIR.''.BASEDIR.'/profile_'.$key.'">'.$value.'</td>
							<td><a class="btn-link" onclick="if (confirm(\'Вы действительно хотите разблокировать?\')) unblockfriend('.$key.')">Разблокировать</a></td>
						</tr>';			
		}
		$result .= '</tbody>
		</table>';
	}	
	
	return $result;
}

function usviewfriends($user_id)
{
	global $db, $us, $eng, $userinfo, $nav;
	
	$user_id = intval($user_id);
	
	$sql = $db->query("SELECT * FROM `users` WHERE `id` = '{$user_id}'");
	if(!$db->num_rows($sql))
		return $eng->msg(2, "Пользователь не найден", 2); 
	
	if($userinfo['id'] == $user_id)
		$nav[] = array('name' => 'Мои друзья');	
	else {
		$row = $db->fetch_array($sql);
		$nav[] = array('name' => 'Друзья '.$row['login']);	
	}
	$sql = $db->query("SELECT * FROM `friends` WHERE `id` = '{$user_id}'");
	$row = $db->fetch_array($sql);
	
	if(!$db->num_rows($sql))
		return $eng->msg(3, "Друзья отстутствуют", 3); 
		
	if(empty($row['friends']))
		return $eng->msg(3, "Друзья отстутствуют", 3); 
	
	$sql = $db->query("SELECT * FROM `users` WHERE `id` IN({$row['friends']}) ORDER BY `group_id` DESC");
	
	if ($db->num_rows($sql) > 0) 
	{	
		$groups = $us->gnamelist();
		$result = '<table class="table table-bordered">
			<thead>
				<th>Ник</th>
				<th>Группа</th>
				<th>Действие</th>
			</thead>
		<tbody>';
		while($row = $db->fetch_array($sql)) 
		{
			$result .= '<tr>
							<td><img class="avatarmini" src="'.$us->avatar($row['id']).'"/> <a href="'.SITEDIR.''.BASEDIR.'/profile_'.$row['id'].'">'.$row['login'].'</td>
							<td>'.$groups[$row['group_id']].'</td> 
							<td><a href="'.SITEDIR.''.BASEDIR.'/createdialog_'.$row['id'].'">Отправить ЛС</a></td>
						</tr>';
		}
		$result .= '</tbody>
		</table>';
	} else
		$result = $eng->msg(3, "Друзья отстутствуют", 3); 
	return $result;
}