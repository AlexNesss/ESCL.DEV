<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'friends';

#Заголовок страницы
$tpl->changeTitle('Список друзей');
	
$nav[] = array('name' => 'Список друзей');

#Подключаем файл функций
require_once "modules/friends/function.php";

if ($userinfo['group'] > 0)
{
	$css[] = 'jquery.toastmessage-min.css';
	$javascript[] = 'jquery.toastmessage-min.js';
	if(!empty($_GET['id']))
		$tpl->content .= usviewfriends($_GET['id']);
	else
		$tpl->content .= viewfriends($userinfo['id']);
} else
	$tpl->content .= $eng->msg(2, "Вы не авторизованы", 2); 