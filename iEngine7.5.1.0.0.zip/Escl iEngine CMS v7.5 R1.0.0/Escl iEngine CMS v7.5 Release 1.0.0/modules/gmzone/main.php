<?php if (!defined('BYESCL'))			exit('Нет доступа');

#Название страницы
$page = 'userpanel';

#Заголовок страницы
$tpl->changeTitle('Админ/вип');

$nav[] = array('name' => 'Админ/вип');

if ($userinfo['group'])
{
	$sql = $db->query("SELECT * FROM `accounts` WHERE `user_id` = '{$userinfo['id']}'");
	if($db->num_rows($sql)) 
	{
		$snservers = array();
		$query = $db->query("SELECT * FROM `servers`");
		while($row = $db->fetch_array($query))
			$snservers[$row['id']] = $row['hostname'];
			
		$tpl->content .=  '<table class="table table-striped table-bordered table-hover table-condensed">
								<thead>
									<tr>
										<th>Ник/SteamID/IP</th>
										<th><font color="red">Пароль</font></th>
										<th>Тип</th>
										<th>Флаги</th>
										<th>Сервер</th>
										<th>Дата окончания</th>
									</tr>
								</thead>
								<tbody>';
		while($row = $db->fetch_array($sql)) 
		{
			if($row['date_end'])
			{
				$date_out = round(($row['date_end']-time())/3600/24);
				
				if(time() > $row['date_end'])
					$accstatus = '<font color="red">Аккаунт просрочен</font>';
				else if(!$date_out)
					$accstatus = '<font color="black">Осталось совсем немного</font>';
				else if($row['date_end'] > time())
					$accstatus = date("d.m.y",$row['date_end']).' (Еще '.$eng->declOfNum($date_out, array("день", "дня", "дней")).')'; 
			} else
				$accstatus = 'Никогда (Права навсегда)';
				
			$tpl->content .=  '<tr><td>'.$row['value'].'</td><td>'.$row['password'].'</td><td>'.$row['type'].'</td><td>'.$row['option'].'</td><td>'.$snservers[$row['server']].'</td><td>'.$accstatus.'</td></tr>';
		}
		$tpl->content .=  '</tbody></table>';	
	} else
	$tpl->content .=  $eng->msg("3", "У вас нет админки/випки!", "3"); 
	$tpl->content .=  $eng->msg("Как правильно вводить пароль:",
	"Если вы купили админку/випку на наших серверах, то вам нужно ввести в консоль строку вида: <b>setinfo _adm \"ваш_пароль\"</b><br />", "3");
	$tpl->content .=  $eng->msg("FAQ Админка/випка:",
	"Основное меню админки: <b>amxmodmenu</b><br />
	Дополнительное меню админки: <b>admin_menu</b><br />
	Основное меню випки: <b>vip_menu</b><br />", "4");
} else
	$tpl->content .= $eng->msg(2, "Вы не авторизованы", 2); 