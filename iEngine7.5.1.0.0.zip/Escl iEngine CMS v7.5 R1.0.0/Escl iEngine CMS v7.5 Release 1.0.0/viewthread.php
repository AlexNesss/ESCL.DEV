<?php
session_start();
define ('BYESCL', true);
require_once "core/maincore.php";

$page = 'topic';
$nav[] = array('name' => 'Форумы', 'url' => '/forums');
# Преобразуем входящие $_GET параметры в число
if (!empty($_GET['topic']))
    $escaped_topic = intval($_GET['topic']);
	
if (!empty($_GET['postedit']))
    $escaped_postedit = intval($_GET['postedit']);

# Переход к последнему сообщению
if ($userinfo['group'] > 0 AND !empty($_GET['topic']) AND !empty($_GET['view']) AND $_GET['view'] == 'getnewpost' AND !empty($escaped_topic)) {
    $query = mysql_query ("SELECT id FROM `forums_messages` WHERE `thread` = {$escaped_topic} ORDER BY `id` DESC LIMIT 1");
	# Если тема с данным номером сущетсвует то
	if(mysql_num_rows($query) > 0) {
		# Получаем массив запроса $query
		$row = mysql_fetch_assoc($query);
		# Узнаем количество сообщений в теме
		$sql = mysql_query ("SELECT id FROM `forums_messages` WHERE `thread` = {$escaped_topic}");
		# Если сообщений меньше или равно 20 то
		if (mysql_num_rows($sql) <= 20) {
		    header("Location: http://".$_SERVER['SERVER_NAME']."/topic_".$escaped_topic."#post".$row['id']."");
		} else {
			# Если сообщений более 20 то делим общее количество сообщений в теме на 20
		    $num_page = mysql_num_rows($sql)/20;
			# Если получилось целое число то
			if (is_int($num_page)) { 
				$num_page = (int)($num_page);
			# А если не получилось то прибавляем единицу к номеру страницы
			} else { 
				$num_page = (int)($num_page+1);	
			}
			# Перекидываем по ссылке, в соответствии с $num_page
			header("Location: http://".$_SERVER['SERVER_NAME']."/topic_".$escaped_topic."_page".$num_page."#post".$row['id']."");
		}
	}
}
# Отправка сообщения
if ($userinfo['group'] > 0 AND !empty($_POST['input_text']) AND !empty($escaped_topic)) {
	# Фильтруем текст сообщения
	$text = mysql_real_escape_string($eng->stripinput($_POST['input_text']));
	# Делаем IP пользователя переменной
	$ip = USER_IP;
	# Узнаем есть ли тема с данным номером
	$query = mysql_query ("SELECT * FROM `forums_threads` WHERE `id` = {$escaped_topic}");
	if (mysql_num_rows($query) > 0) {
		# Получаем массив темы
		$row = mysql_fetch_assoc($query);
		# Если тема не закрыта, или пользователь админ то
		if ($row['closed'] != 1 OR $userinfo['group'] == 4) {
			# Если текст сообщения не пустой
			if (!empty($text)) {
				mysql_query ("INSERT INTO `forums_messages` (`id`, `thread`, `text`, `time`, `user_id`, `ip`) VALUES (NULL, '{$escaped_topic}', '{$text}', CURRENT_TIMESTAMP, '{$userinfo['id']}', '$ip')") or die(mysql_error());
			}
			# Отправляем к последнему сообщению
			header("Location: ".BASEDIR."topic_".$escaped_topic."_new");
		}
	}
}
# Редактирование сообщения	
if (!empty($escaped_postedit) AND $userinfo['group'] > 0) {
	$sql = mysql_query("SELECT * FROM `forums_messages` WHERE `id` = {$escaped_postedit}");
	if(mysql_num_rows($sql) > 0) {
		$row = mysql_fetch_assoc($sql);
		if($row['user_id'] == $userinfo['id'] OR $userinfo['group'] == 4) {
			if(!empty($_POST['input_text'])) {
				$text = mysql_real_escape_string($eng->stripinput($_POST['input_text']));
				if (!empty($text)) {
					mysql_query ("UPDATE `forums_messages` SET `text` = '{$text}' WHERE `id` = {$escaped_postedit}") or die(mysql_error());
				}
				header("Location: ".BASEDIR."topic_".$row['thread']."");
			} else {
				$text = str_replace("<br />", "\r\n", $row['text']);
				$edit = '<form method="POST" class="form-horizontal" action="" onsubmit="return validate_input();"><fieldset><legend>Редактирование сообщения <a style="float:right; font-weight: normal;" class="btn btn-warning  btn-mini" href="http://'.$_SERVER['SERVER_NAME'].'/topic_'.$row['thread'].'">Назад</a></legend>
							'.$eng->bb_panel().'
							<textarea maxlength="10000" style="height:190px;" class="span6" name="input_text" id="input_text" rows="5">'.$text.'</textarea>
							<div class="form-actions"><input type="submit" value="Изменить" class="btn btn-info"><span style="color:red" id="input_textf"></span></div>
					  </fieldset></form>';
			}
		} else {
			$edit = $eng->msg("2", "У вас нет прав доступа", "2");
		}
	} else {
		$edit = $eng->msg("2", "Сообщение не существует", "2");
	}
	if(isset($edit)) {
		require_once TPL."header.php";
		echo $edit;
		require_once TPL."footer.php";
		exit();
	}
}

require_once TPL."header.php";

if ($userinfo['group'] > 0) {
	# Если имеется $escaped_topic
    if (!empty($escaped_topic)) {
		if($escaped_topic == 80 AND ($userinfo['group'] == 2 OR $userinfo['group'] == 1)) {
			echo $eng->msg("2", "У вас нет прав доступа", "2");
			require_once TPL."footer.php";
			exit();
		}
		# Делаем выносящие мозг операции по определению текущей страницы
        if (isset($_GET['page'])) $page_sel=(intval($_GET['page'])-1); else $page_sel=0;
		# Определяем номер сообщения в теме, с которого начнем поиск в запросе
        $start=abs($page_sel*20);
		# Получаем 20 сообщений темы на данной странице
    	$sql = mysql_query("SELECT * FROM `forums_messages` WHERE `thread` = {$escaped_topic} ORDER BY `id` ASC LIMIT $start,20");
		# Собираем информацию о теме
		$sql_name = mysql_query("SELECT * FROM `forums_threads` WHERE `id` = {$escaped_topic}");
		# Если сообщения есть то
		if (mysql_num_rows($sql_name) > 0) {
			if (mysql_num_rows($sql) > 0) {
				# Если присутствует POST запрос на действие с темой и запрос от админа то
				if(isset($_POST['thread_status']) AND $userinfo['group'] == 4) {
					# Изменение заголовка
					if($_POST['thread_status'] == 5) {
						if(isset($_POST['name_edit_thread'])) {
							$title = mysql_real_escape_string($eng->stripinput($_POST['name_edit_thread']));
							if(!empty($title)) {
								$sql = mysql_query("UPDATE `forums_threads` SET `title` = '{$title}' WHERE `id` = {$escaped_topic}");
								echo $eng->msg("1", "Заголовок изменен", "1");
								echo '<meta http-equiv="refresh" content="2;URL=http://'.$_SERVER['SERVER_NAME'].'/topic_'.$escaped_topic.'">';
							} else { 
								echo $eng->msg("4", "Не все поля были заполнены", "4");
								echo '<meta http-equiv="refresh" content="2;URL=http://'.$_SERVER['SERVER_NAME'].'/topic_'.$escaped_topic.'">';
							}
						} else {
							$sql_name = mysql_query("SELECT * FROM `forums_threads` WHERE `id` = {$escaped_topic}");
							$row = mysql_fetch_assoc($sql_name);
							echo '<form method="POST" class="form-horizontal" action=""><fieldset>
							<legend>Редактирование названия темы <a style="float:right; font-weight: normal;" class="btn btn-warning  btn-mini" href="http://'.$_SERVER['SERVER_NAME'].'/topic_'.$escaped_topic.'">Назад</a></legend>
							<div class="control-group"><label class="control-label" for="name">Название:&nbsp;&nbsp;&nbsp;</label><input class="span6" type="text" name="name_edit_thread" id="name" value="'.$row['title'].'" ></div>
							<input type="hidden" name="thread_status" value="5">
							<div class="form-actions"><input type="submit" value="Изменить" class="btn btn-info"></div>
							</fieldset></form>';
						}
					}
					# Открытие темы
					else if($_POST['thread_status'] == 1) {
						$sql_name = mysql_query("SELECT * FROM `forums_threads` WHERE `id` = {$escaped_topic}");
						$row = mysql_fetch_assoc($sql_name);
						if ($row['closed'] == 1) {
							$sql = mysql_query("UPDATE `forums_threads` SET `closed` = '0' WHERE `id` = {$escaped_topic};");
							echo $eng->msg("1", "Тема открыта", "1");
							echo '<meta http-equiv="refresh" content="2;URL=http://'.$_SERVER['SERVER_NAME'].'/topic_'.$escaped_topic.'">';
						}
					}
					# Закрытие темы
					else if($_POST['thread_status'] == 2) {
						$sql_name = mysql_query("SELECT * FROM `forums_threads` WHERE `id` = {$escaped_topic}");
						$row = mysql_fetch_assoc($sql_name);
						if ($row['closed'] == 0) {
							$sql = mysql_query("UPDATE `forums_threads` SET `closed` = '1' WHERE `id` = {$escaped_topic};");
							echo $eng->msg("1", "Тема закрыта", "1");
							echo '<meta http-equiv="refresh" content="2;URL=http://'.$_SERVER['SERVER_NAME'].'/topic_'.$escaped_topic.'">';
						}
					}
					# Перемещение темы
					else if($_POST['thread_status'] == 3) {
						if(isset($_POST['forum_id'])) {
							$id = intval($_POST['forum_id']);
							if(!empty($id)) {
								$sql = mysql_query("UPDATE `forums_threads` SET `for` = {$id} WHERE `id` = {$escaped_topic}");
								echo $eng->msg("1", "Тема перемещена", "1");
								echo '<meta http-equiv="refresh" content="2;URL=http://'.$_SERVER['SERVER_NAME'].'/topic_'.$escaped_topic.'">';
							} else { 
								echo $eng->msg("4", "Не все поля были заполнены", "4");
								echo '<meta http-equiv="refresh" content="2;URL=http://'.$_SERVER['SERVER_NAME'].'/topic_'.$escaped_topic.'">';
							}
						} else {
							$sql_name = mysql_query("SELECT * FROM `forums_for`");
							echo '<form action="" method="post" autocomplete="off">
							<legend>Редактирование форума темы <a style="float:right; font-weight: normal;" class="btn btn-warning  btn-mini" href="http://'.$_SERVER['SERVER_NAME'].'/viewthread.php?topic='.$escaped_topic.'">Назад</a></legend>
							<div class="control-group"><div class="controls">
							<input type="hidden" name="thread_status" value="3">
							<select name="forum_id">';
							while($row = mysql_fetch_array($sql_name)) {
								echo '<option'; if($escaped_topic == $row['id']) { echo ' selected'; } echo ' value="'.$row['id'].'">'.$row['name'].'</option>';
							}
							echo '</select></div> <div class="form-actions"><input type="submit" class="btn btn-info" name="submit" value="Изменить"></div></div></form>';
						}
					}
					# Закрепление темы
					else if($_POST['thread_status'] == 4) {
						$sql_name = mysql_query("SELECT * FROM `forums_threads` WHERE `id` = {$escaped_topic}");
						$row = mysql_fetch_assoc($sql_name);
						if ($row['status'] != 2) {
							$sql = mysql_query("UPDATE `forums_threads` SET `status` = '2' WHERE `id` = {$escaped_topic};");
							echo $eng->msg("1", "Тема закреплена", "1");
							echo '<meta http-equiv="refresh" content="2;URL=http://'.$_SERVER['SERVER_NAME'].'/topic_'.$escaped_topic.'">';
						} else {
							$sql = mysql_query("UPDATE `forums_threads` SET `status` = '1' WHERE `id` = {$escaped_topic};");
							echo $eng->msg("1", "Тема опущена", "1");
							echo '<meta http-equiv="refresh" content="2;URL=http://'.$_SERVER['SERVER_NAME'].'/topic_'.$escaped_topic.'">';
						}
					}
					require_once TPL."footer.php";
					exit();
				}
				# Просмотр страницы темы
				else
				{
					# Увеличиваем количество просмотров темы
					mysql_query("UPDATE `forums_threads` SET `view`=`view`+1 WHERE `id` = {$escaped_topic}");
					# Получаем массив информации о теме
					$row = mysql_fetch_assoc($sql_name);
					# Берем статус темы в переменную
					$status = $row['closed'];
					# Список действий для администратора
					if($userinfo['group'] ==4) {
						  echo '<div class="btn-group pull-right"><button class="btn dropdown-toggle" data-toggle="dropdown">Действие <span class="caret"></span></button><ul class="dropdown-menu">';
						  if($row['closed'] == 1) { echo '<form method="POST" id="lol1" action=""><input type="hidden" name="thread_status" value="1"><li><a href="javascript:void(0);" onClick="document.getElementById(\'lol1\').submit();">Открыть тему</a></li></form>'; }
						  if($row['closed'] == 0) { echo '<form method="POST" id="lol2" action=""><input type="hidden" name="thread_status" value="2"><li><a href="javascript:void(0);" onClick="document.getElementById(\'lol2\').submit();">Закрыть тему</a></li></form>'; }
						  echo '<form method="POST" id="lol3" action=""><input type="hidden" name="thread_status" value="3"><li><a href="javascript:void(0);" onClick="document.getElementById(\'lol3\').submit();">Переместить тему</a></li></form>'; 
						  echo '<form method="POST" id="lol4" action=""><input type="hidden" name="thread_status" value="4"><li><a href="javascript:void(0);" onClick="document.getElementById(\'lol4\').submit();">Поднять/опустить тему</a></li></form>';
						  echo '<form method="POST" id="lol5" action=""><input type="hidden" name="thread_status" value="5"><li><a href="javascript:void(0);" onclick="document.getElementById(\'lol5\').submit();">Редактировать заголовок</a></li></form></ul></div>';
					}
					# Сколько сообщений в данной теме
					$sql_num=mysql_query("SELECT count(*) FROM `forums_messages` WHERE `thread` = {$escaped_topic}");
					# Всякие абракадабры по выводу нумерации страниц
					$rowtotal = mysql_fetch_row($sql_num);	
					$total_rows = $rowtotal[0]; 
					
					$pagination = $eng->pagination($total_rows, 20, $page_sel, '/topic_'.$escaped_topic.'_page');
					

					# Заголовок темы
					echo '<div class="navbar"><div class="navbar-inner"><span class="brand" ><small>'.$row['title'].'</small></span></div></div>
					<table width="100%" style="table-layout: fixed;" cellpadding="6">';
							echo $pagination;
							# Номер первого сообщения
							$num = $start+1;
							# Выводим все сообщения
							while($row = mysql_fetch_array($sql)) {
								# Дата добавления поста
								$date = $eng->showtime(strtotime($row['time']), 1); 
								# Массив пользователя
								$arr = $us->array_user($row['user_id']);
								# Стаж
								$staj = $eng->declOfNum(round((time()-strtotime($arr[7]))/3600/24), array("день", "дня", "дней"));
								# Количество сообщений
								$messages_num = mysql_query("SELECT id FROM `forums_messages` WHERE `user_id` = {$row['user_id']}");
								# Поблагодарил
								$best_post_sam = mysql_query("SELECT * FROM `forums_messages` WHERE FIND_IN_SET( {$row['user_id']}, `likes`)");
								$blagodaril = $eng->declOfNum(mysql_num_rows($best_post_sam), array("раз", "раза", "раз"));
								# Поблагодарили
								//$best_post_ego = mysql_query("SELECT * FROM `forums_messages` WHERE FIND_IN_SET( {$row['user_id']}, `likes`) AND `user_id` = {$row['user_id']}");								
								echo '<tr id="post'.$row['id'].'" class="toppost">
								<td width="170px">'.$us->userstatusicon($arr[0]).' <a target="_blank" href="http://'.$_SERVER['SERVER_NAME'].'/profile_'.$arr[0].'">'.$us->username($arr[0], 1).'</a> </td>
								<td><span class="pull-left"><i class="icon-time"></i> '.$date.'</span><span class="pull-right">'; 
								# IP пользователя для админов
								if($userinfo['group'] == 4) { 
									echo 'IP: '.$row['ip'].'&nbsp;&nbsp;&nbsp;'; 
								} 
								echo '<a href ="javascript:prompt(\'Ссылка на данное сообщение:\', \'http://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'].'#post'.$row['id'].'\');">#'.$num.'</a></span></td></tr>
								<tr width="100%" style="padding-bottom:5px;">
								<td valign="top" class="leftpostbody"><a target="_blank" href="http://'.$_SERVER['SERVER_NAME'].'/profile_'.$arr[0].'"><img style="-webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px;" src="'.$us->avatar($arr[0]).'" /></a><span><br />Сообщений: '.mysql_num_rows($messages_num).'<br />Поблагодарил: '.$blagodaril.'<br />Группа: '.$us->groupname($arr[6], 1).'<br />Стаж: '.$staj.'<br />Ник: '.$arr[5].'<br />Имя: '.$arr[4].'</span></td >
								<td class="rightpostbody" valign="top">'.$eng->replaceBBCode($eng->smiles(mysql_real_escape_string(''.$row['text'].''), 1, 0)).'';
								# Подпись
								if(!empty($arr[10])) {
									echo '<hr>'.$eng->replaceBBCode($eng->smiles(mysql_real_escape_string($arr[10]), 1, 0));
								}
								echo '</td></tr>';
								# Лайки
								unset($userslist);
								if(!empty($row['likes'])) {
									$userslist = array();
									$sql_l = mysql_query ("SELECT * FROM `users` WHERE `id` IN({$row['likes']})");
									while($row_l=mysql_fetch_array($sql_l)) {
										$userslist[] = '<a href="'.BASEDIR.'/profile_'.$row_l['id'].'">'.$us->username($row_l['id'],1).'</font></a>';
									}
								}
								echo '<tr class="bottompost" id="bpost'.$row['id'].'"'; if(!isset($userslist)) { echo ' style="display:none;"'; } echo '><td>Поблагодарили: </td><td id="like_post'.$row['id'].'">';
								if(isset($userslist)) {
									echo implode(', ', $userslist);
								}
								echo '</td></tr>';
								echo '<tr class="bottompanelpost">
								<td colspan="2" class="bottompost"><a class="btn btn-mini" style="font-weight:normal;" href="javascript:window.scrollTo(0,0);" type="button">Вверх</a> '; if($userinfo['id'] != $row['user_id']) { echo '<a class="btn btn-mini" style="font-weight:normal;" target="_blank" href="http://'.$_SERVER['SERVER_NAME'].'/createdialog_'.$row['user_id'].'" type="button">Отправить ЛС</a>'; } echo '<a class="btn btn-mini pull-right" style="font-weight:normal;" onclick="reply_post()" href="javascript:void(0)" >Ответить</a>';
								# Удаление поста
								if($userinfo['group'] == 4 OR $row['user_id'] == $userinfo['id']) {
									if($num == 1) {
										echo '<a class="btn btn-mini pull-right" style="font-weight:normal;" href="javascript:void(0)" onclick="delete_post('.$row['id'].', 1)" type="button">Удалить тему</a> <a class="btn btn-mini pull-right" style="font-weight:normal;" href="http://'.$_SERVER['SERVER_NAME'].'/forums_postedit_'.$row['id'].'">Редактировать</a>';
									} else {
										echo '<a class="btn btn-mini pull-right" style="font-weight:normal;" href="javascript:void(0)" onclick="delete_post('.$row['id'].', 0)" type="button">Удалить</a> <a class="btn btn-mini pull-right" style="font-weight:normal;" href="http://'.$_SERVER['SERVER_NAME'].'/forums_postedit_'.$row['id'].'">Редактировать</a>';
									}
								}
								$arrlikes = explode(",", $row['likes']);
								if ($row['user_id'] != $userinfo['id'] AND !in_array($userinfo['id'], $arrlikes)) {
									echo '<a class="btn btn-mini pull-right" id="thanks'.$row['id'].'" style="font-weight:normal;" href="javascript:void(0)" onclick="LikeAction('.$row['id'].')" type="button">Спасибо</a>';
								}
								echo '</td></tr>';
								$num++;
							}
					echo '</tbody></table>';
					
					echo $pagination;
					
					# Форма ответа
					if ($userinfo['group'] == 4 OR $status != 1){
						echo '<br />'; 
						if ($userinfo['group'] == 4 AND $status == 1){
							echo $eng->msg("3", "Тема закрыта, но у вас все равно есть право оставлять в ней сообщения", "3");
						}
						echo $eng->bb_panel();
						echo '<div class="create_message">
						<form method="post" name="form_msg" id="form_msg" onsubmit="return validate_input();">
						<div class="iwrap"><textarea autocomplete="off" style="height:70px;" id="input_text" name="input_text"></textarea></div>
						<div class="ibwrap">
						<input type="submit" class="btn btn-info" value="Отправить" /><p class="smiles">';
						echo $eng->smiles(0, 0, 0);
						echo '</p>
						</div>
						</form>
						<span style="color:red" id="input_textf"></span>
						</div>';
					}
				}
			} else {
				echo $eng->msg("3", "Страница не найдена", "3");
			}
		} else {
			echo $eng->msg("2", "Темы не существует", "2");
		}
	} else {
	    echo $eng->msg("2", "Не введен номер темы", "2");
	}
} else {
    echo $eng->msg("2", "Вы не авторизованы", "2");
}
require_once TPL."footer.php";