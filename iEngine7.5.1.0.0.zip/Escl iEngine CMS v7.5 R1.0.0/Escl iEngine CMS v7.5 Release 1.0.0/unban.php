<?php
session_start();
define ('BYESCL', true);
require_once "core/maincore.php";

#Название страницы
$page = 'unban_menu';

$snservers = array();
$sql = $db->query("SELECT * FROM `servers`");
while($row = $db->fetch_array($sql))
	$snservers[$row['id']] = $row['hostname'];

if (!empty($_GET['id']))
    $escaped_zid = intval($_GET['id']);

if (empty($escaped_zid) AND empty($_GET['act']) AND $userinfo['group'] == 4)
	header("Location: http://".$_SERVER['SERVER_NAME']."/unban_ap");
$nav[] = array('name' => 'Заявки на разбан', 'url' => '/forums');
//обработчик POST
if (!empty($_GET['act']) AND $_GET['act'] == 'admin' AND $userinfo['group'] == 4 AND isset($_GET['delete']) AND !empty($escaped_zid)){
	$sql = $db->query("DELETE FROM add_bans WHERE  `id` = '{$escaped_zid}'");
	header("Location: http://".$_SERVER['SERVER_NAME']."/unban.php?act=admin");
}

if ($userinfo['group'] AND !empty($_GET['act']) AND $_GET['act'] == 'create' AND isset($_POST['server']) AND !empty($_POST['nick']) AND !empty($_POST['steam_id']) AND !empty($_POST['reason']) AND !empty($_POST['info']) AND !empty($_POST['snapshot']) AND !empty($_POST['demo']))
{
	$server = $eng->stripinput($_POST['server']);
	$nick = $eng->stripinput($_POST['nick']);
	$steam_id = $eng->stripinput($_POST['steam_id']);
	$reason = $eng->stripinput($_POST['reason']);
	$info = $eng->stripinput($_POST['info']);
	$snapshot = $eng->stripinput($_POST['snapshot']);
	$demo = $eng->stripinput($_POST['demo']);
	$sql = $db->query("INSERT INTO  `add_bans` (`id` ,`s_id` ,`server` ,`nick` ,`steam_id` ,`reason` ,`info` ,`snapshot` ,`demo` ,`date` ,`type` ,`read`)VALUES (NULL ,  '{$userinfo['id']}',  '{$server}',  '{$nick}',  '{$steam_id}',  '{$reason}',  '{$info}',  '{$snapshot}',  '{$demo}', CURRENT_TIMESTAMP ,  '0',  '0');");
    header("Location: http://".$_SERVER['SERVER_NAME']."/unban.php?result=1");
}

if(!empty($_POST['process']) AND !empty($escaped_zid) AND $userinfo['group'] > 0) {
	$process = intval($_POST['process']);
	if ($process == 'new')
		$sql = $db->query("UPDATE  `add_bans` SET  `type` =  '0', `read` = '0', `admin_id` = '0', `comment` = '' WHERE  `id` = {$escaped_zid}");
	else if ($process == '2') {
		if(!empty($_POST['text_edit_unban'])) {
			$com_unban = $eng->stripinput($_POST['text_edit_unban']);
			$sql = $db->query("UPDATE  `add_bans` SET  `type` =  {$process}, `read` = '1' , `admin_id` = {$userinfo['id']}, `comment` = '{$com_unban}' WHERE  `id` = {$escaped_zid}");
		} else
			$sql = $db->query("UPDATE  `add_bans` SET  `type` =  {$process}, `read` = '1', `admin_id` = {$userinfo['id']}, `comment` = '' WHERE  `id` = {$escaped_zid}");
	} else
		$sql = $db->query("UPDATE  `add_bans` SET  `type` =  {$process}, `read` = '1', `admin_id` = {$userinfo['id']}, `comment` = '' WHERE  `id` = {$escaped_zid}");
}
# Удаление комментария бана
if($userinfo['group'] AND !empty($_POST['id_del'])) {
    $del_news = intval($_POST['id_del']);
	$sql = $db->query("SELECT * FROM `bans_com` WHERE `id` = {$del_news} ORDER BY id DESC");
	$row = $db->fetch_array($sql);
	if ($db->num_rows($sql) AND $userinfo['id'] == $row['user_id'] OR $userinfo['group'] == 4) {
        $sql = $db->query("DELETE FROM `bans_com` WHERE `id` = {$del_news}");
	}
}    

# Добавление комментария
if ($userinfo['group'] AND !empty($_POST['input_text'])) {
    $textpm = mysql_real_escape_string($eng->stripinput($_POST['input_text']));
    $sql = $db->query("SELECT * FROM `add_bans` WHERE `id` = {$escaped_zid}");
	if ($db->num_rows($sql))
	    $db->query ("INSERT INTO `bans_com` (`id` ,`bans_id` ,`user_id`, `text`)VALUES (NULL ,  '{$escaped_zid}',  '{$userinfo['id']}',  '{$textpm}')");
}	

require_once TPL."header.php";

if ($userinfo['group'])
{
    //парочка массивов
	$resultcol = array("", "success", "error");
	$statuscol = array("Новая","Не прочитано", "Прочитано");
	$admstatuscol = array("Не рассмотрена", "Рассмотрена (игрок разбанен)", "Рассмотрена (игрок не разбанен)");
    if (isset($_GET['result']) AND $_GET['result'] == '0') {
		echo $eng->msg("4", "Не все поля были заполнены", "4");
        echo '<meta http-equiv="refresh" content="2;URL=http://'.$_SERVER['SERVER_NAME'].'/unban.php?act=create">';
	} else if(!empty($_GET['result']) AND $_GET['result'] == '1') {
		echo $eng->msg("1", "Заявка успешно создана", "1");
        echo '<meta http-equiv="refresh" content="2;URL=http://'.$_SERVER['SERVER_NAME'].'/unban.php">';
	}
	//список заявок для юзеров
    else if (!empty($_GET['act']) AND $_GET['act'] == 'list') {
		$sql = $db->query("SELECT * FROM `add_bans` LIMIT 1");
		if ($db->num_rows($sql)) 
		{
			echo '<table class="table table-bordered"><thead><th>Игровой сервер</th><th>Ник игрока</th><th>Статус</th><th>Действие</th></thead><tbody>';
			$userstatuscol = array("На рассмотрении", "Разбанен", "Не разбанен");
			if (isset($_GET['page'])) $page_sel=(intval($_GET['page'])-1); else $page_sel=0;
			$start=abs($page_sel*20);
			$sql = $db->query("SELECT * FROM `add_bans` ORDER BY `id` DESC LIMIT $start,20");
			while($row = mysql_fetch_array($sql)) { 
				$s_login = $us->username($row['s_id'], 0); 
				echo '<tr class="'.$resultcol[$row['type']].'"><td>'.$snservers[$row['server']].'</td><td>'.$row['nick'].'</td><td>'.$userstatuscol[$row['type']].'</td><td><a href="http://'.$_SERVER['SERVER_NAME'].'/unban.php?id='.$row['id'].'">Подробнее »</a></td></tr>';
			}
			echo '</tbody></table>';
			$sql=$db->query("SELECT count(*) FROM `add_bans`");
			$row=mysql_fetch_row($sql);
			$total_rows=$row[0];
			echo $eng->pagination($total_rows, 20, $page_sel, '/unban_list_page');	
		} else
			echo $eng->msg("3", "Заявок еще не создано", "3");
    } else if (!empty($_GET['act']) AND $_GET['act'] == 'create'){
          echo '<form method="POST" action="">
<table class="table table-bordered">
	<thead>
		<tr>
			<th colspan="2"><center>Создание заявки</center></th>
		</tr>
	</thead>
	<tbody>
		
	    <tr>
	        <div class="control-group">
			<td width="180px"><label class="control-label" for="server"><b>[!] Игровой сервер:</b></label></td>
			<td><select class="input-block-level" name="server" id="server">';
			foreach($snservers AS $key => $value)
			echo '<option value="'.$key.'">'.$value.'</option>';
			echo '</select></td></div>
		</tr>
		<tr>
			<td width="180px" for="nick"><b>[!] Ваш ник во время бана:</b></td>
			<td><input class="input-block-level" name="nick" id="nick" type="text" placeholder="Ник в момент бана" required></td> 
		</tr>
		<tr>
			<td width="180px" for="steam_id"><b>[!] ValveID/SteamID:</b></td>
			<td><input class="input-block-level" name="steam_id" id="steam_id" type="text" placeholder="Если не знаете, то введите status в консоли на любом из серверов" required></td> 
		</tr>			
		<tr>
			<td width="180px" for="reason"><b>[!] Причина бана:</b></td>
			<td><input class="input-block-level" name="reason" id="reason" type="text" placeholder="Причина бана" required></td> 
		</tr>	
		<tr>
			<td width="180px" for="info"><b>Информация (из консоли):</b></td>
			<td><textarea maxlength="2000" class="input-block-level" name="info" id="info" placeholder="Информацыя о бане из консоли" rows="5"></textarea></td> 
		</tr>
		<tr>
			<td width="180px" for="snapshot"><b>Скриншоты:</b></td>
			<td><input class="input-block-level" name="snapshot" id="snapshot" type="text" placeholder="Ссылки на скриншоты через запятую, не более 5"></td> 
		</tr>
		<tr>
			<td width="180px" for="demo"><b>Демо:</b></td>
			<td><input class="input-block-level" name="demo" id="demo" type="text" placeholder="Ссылка на демо"></td> 
		</tr>
		<tr>
			<td><input type="submit" value="Отправить заявку" class="btn btn-large btn-success"></td>
			<td><p class="text-error"><b>[!]</b> - Обязательные поля, в случае не заполнения полей, заявка не будет создана!<br><b>От правильности заполнения формы заявки будет зависеть скорость её рассмотрения и решение администрации по вашему запросу.</b></p></br></td>
				</tbody> 
</table>
</form>';
    } else if ($userinfo['group'] != 4 AND !empty($_GET['act']) AND $_GET['act'] == 'admin')
	    echo $eng->msg("2", "У вас нет прав доступа к панели администратора", "2");
	else if (!empty($_GET['act']) AND $_GET['act'] == 'admin' AND !empty($escaped_zid) AND $userinfo['group'] == 4){
	    #панель администратора, Подробнее » заявки
		$sql = $db->query("SELECT * FROM `add_bans` WHERE id = '{$escaped_zid}'");
        if ($db->num_rows($sql) == 1) {
		    $row = $db->fetch_array($sql);
			$s_login = $us->username($row['s_id'], 0);
			$date = date("d.m.Y в H:i", strtotime($row['date']));
	        echo '<table class="table table-bordered">
	        <thead>
			<th colspan="2"><center>Заявка на разбан № '.$escaped_zid.'</center></th>
			</div></form>
			<tr><td>Игровой сервер:</td><td>'.$snservers[$row['server']].'</td></tr>
			<tr><td>Ник во время бана:</td><td>'.$row['nick'].'</td></tr>
			<tr><td>SteamID/ValveID:</td><td>'.$row['steam_id'].'</td></tr>
			<tr><td>Причина бана:</td><td>'.$row['reason'].'</td></tr>
			<tr><td>Информация (из консоли):</td><td>'.$row['info'].'</td></tr>
			<tr><td>Скриншоты:</td><td>'.$row['snapshot'].'</td></tr>
			<tr><td>Демо:</td><td>'.$row['demo'].'</td></tr>
			<tr><td>Заявка создана:</td><td>'.$date.'</td></tr>';
			if ($row['read'] AND !empty($row['admin_id']))
				echo '<tr><td>Рассмотрел:</td><td>Администратор: '.$us->username($row['admin_id'], 0).'</td></tr>';
			echo' <tr><td>Статус заявки:</td><td>'.$admstatuscol[$row['type']].'</td></tr>';
			if(!empty($row['comment'])) { echo '<tr><td><font color="red">Комментарий</font>:</td><td>'.$row['comment'].'</td></tr>'; }
			echo '<tr><td>Управление заявкой:</td><td><div class="input-append"><form method="POST" action=""><fieldset><select name="process" onchange="if (this.options[this.selectedIndex].value == \'2\') { UnToggle(add_comm) } else { ToToggle(add_comm)}"><option value="new">Пометить непрочитанным</option><option value="1">Игрок разбанен</option><option value="2">Игрок не разбанен</option></select><input type="submit" value="ОК" class="btn"></div></td></tr>
			<tr id="add_comm" style="display:none;"><td>Комментарий:</td><td><textarea maxlength="2000" class="span6" name="text_edit_unban" rows="5"></textarea></fieldset></form></td></tr>
			</table>';
			if ($db->num_rows($sql) OR $userinfo['group'])
				echo '<h2>Комментарии</h2>';
			if ($userinfo['group']) 
			{
				echo '<div class="create_message">
				<form method="post" name="form_msg" id="form_msg">
				<div class="iwrap"><input autocomplete="off" maxlength="1000" id="input_text" name="input_text" type="text"></div>
				<div class="ibwrap">
					<input type="submit" class="btn btn-info" value="Отправить" />
					<p class="smiles">'.$eng->smiles(0, 0, 0).'</p>
				</div>
				</form>
				<span style="color:red" id="input_textf"></span>
				</div>';
			}
			if ($db->num_rows($sql)) 
			{
				$page_sel = (isset($_GET['page']) ? (intval($_GET['page'])-1) : 0);
				$sql = $db->query("SELECT * FROM `bans_com` WHERE `bans_id` = '{$escaped_zid}' ORDER BY `id` DESC LIMIT ".abs($page_sel*20).",20");
				if ($db->num_rows($sql)) 
				{
					# Вывод комментариев
					while($row = mysql_fetch_array($sql)) 
					{
						$date = $eng->showtime(strtotime($row['date']), 1); 
						echo '<ul class="commentlist">
							<li class="clidata">
								<div class="cdata">
									<img style="-webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px;" src="'.$us->avatar($row['user_id']).'" class="avatar avatar-33 photo" height="33" width="33">				
									<strong><a target="_blank" href="/profile_'.$row['user_id'].'" rel="external nofollow" class="url">'.$us->username($row['user_id'],1).'</a>';
									if ($userinfo['group'] == 4 OR $userinfo['group'] AND $row['user_id'] == $userinfo['id'])
										echo '<form class="pull-right" method="POST" action=""><input type="hidden" name="id_del" value="'.$row['id'].'"><input class="btn btn-small" type="submit" onclick="return confirmDelete();" value="Удалить"></form>';

									echo '</strong>
									<small class="commentmetadata">'.$date.'</small>
								</div>
								<div class="ctext">
									<p>'.$eng->smiles(mysql_real_escape_string($row['text']), 1, 0).'</p>
								</div>
							</li>
						</ul>';
					}
				} else if($page_sel > 1)
					echo '<br />'.$eng->msg("3", "Комментариев на данной странице нет", "3");

				$sql = $db->query("SELECT count(*) FROM `bans_com` WHERE `bans_id` = {$escaped_zid}");
				$row = $db->fetch_row($sql);
				$total_rows = $row[0];
				echo $eng->pagination($total_rows, 20, $page_sel, '/unbans_adm_'.$escaped_zid.'_page');					
			}	
		} else
		    echo $eng->msg("2", "Запись не найдена", "2");
	} else if (!empty($escaped_zid)) {
		#пользователь, Подробнее » заявки
		$sql = $db->query("SELECT * FROM `add_bans` WHERE id = '{$escaped_zid}'");
		
        if ($db->num_rows($sql)) 
		{
		    $row = $db->fetch_array($sql);
			
			if ($userinfo['id'] == $row['s_id'])
			{
				$userstatuscol = array("Не рассмотрена", "Рассмотрена (вы разбанены)", "Рассмотрена (вы не разбанены)");
				if($row['read'] == 1)
					$db->query("UPDATE `add_bans` SET  `read` =  '2' WHERE  `id` = '{$escaped_zid}'");
			} else
				$userstatuscol = array("Не рассмотрена", "Рассмотрена (игрок разбанен)", "Рассмотрена (игрок не разбанен)");
		
			$date = $eng->showtime(strtotime($row['date']), 1);
		    echo '<table class="table table-bordered">
	        <thead>
			<th colspan="2"><center>Заявка на разбан № '.$escaped_zid.'</center></th>
			</div></form>
			<tr><td>Игровой сервер:</td><td>'.$snservers[$row['server']].'</td></tr>
			<tr><td>Ник во время бана:</td><td>'.$row['nick'].'</td></tr>
			<tr><td>SteamID/ValveID:</td><td>'.$row['steam_id'].'</td></tr>
			<tr><td>Причина бана:</td><td>'.$row['reason'].'</td></tr>
			<tr><td>Информация (из консоли):</td><td>'.$row['info'].'</td></tr>
			<tr><td>Скриншоты:</td><td>'.$row['snapshot'].'</td></tr>
			<tr><td>Демо:</td><td>'.$row['demo'].'</td></tr>
			<tr><td>Заявка создана:</td><td>'.$date.'</td></tr>';
			if ($row['read'] AND !empty($row['admin_id']))
				echo '<tr><td>Рассмотрел:</td><td>Администратор: '.$us->username($row['admin_id'], 0).'</td></tr>';
				
			echo '<tr><td>Статус заявки:</td><td>'.$userstatuscol[$row['type']].'</td></tr>';
			if(!empty($row['comment'])) 
				echo '<tr><td><font color="red">Комментарий</font>:</td><td>'.$row['comment'].'</td></tr>';
			
			echo '</table>';
			if ($db->num_rows($sql) OR $userinfo['group'])
				echo '<h2>Комментарии</h2>';
				
			$getsmiles = $eng->getsmiles();	
			if ($userinfo['group']) 
			{
				echo '<div class="create_message">
				<form method="post" name="form_msg" id="form_msg">
					<div class="iwrap"><input autocomplete="off" maxlength="1000" id="input_text" name="input_text" type="text"></div>
					<div class="ibwrap">
					<input type="submit" class="btn btn-info" value="Отправить" /><p class="smiles">
						'.$eng->viewsmiles($getsmiles['img'], 'InsertSmile').'
					</p>
					</div>
				</form>
				<span style="color:red" id="input_textf"></span>
				</div>';
			}
			if ($db->num_rows($sql)) 
			{
				$page_sel = (isset($_GET['page']) ? (intval($_GET['page'])-1) : 0);
				# Вычисляем первый оператор для LIMIT
				$sql = $db->query("SELECT * FROM `bans_com` WHERE `bans_id` = '{$escaped_zid}' ORDER BY `id` DESC LIMIT ".abs($page_sel*20).",20");
				if ($db->num_rows($sql)) 
				{
					# Вывод комментариев
					while($row = mysql_fetch_array($sql)) 
					{
						$date = $eng->showtime(strtotime($row['date']), 1); 
						echo '<ul class="commentlist">
							<li class="clidata">
								<div class="cdata">
									<img style="-webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px;" src="'.$us->avatar($row['user_id']).'" class="avatar avatar-33 photo" height="33" width="33">				
									<strong><a target="_blank" href="/profile_'.$row['user_id'].'" rel="external nofollow" class="url">'.$us->username($row['user_id'],1).'</a>';
									if ($userinfo['group'] == 4 OR ($userinfo['group'] AND $row['user_id'] == $userinfo['id']))
										echo '<form class="pull-right" method="POST" action=""><input type="hidden" name="id_del" value="'.$row['id'].'"><input class="btn btn-small" type="submit" onclick="return confirmDelete();" value="Удалить"></form>';
									
									echo '</strong>
									<small class="commentmetadata">'.$date.'</small>
								</div>
								<div class="ctext">
									<p>'.$eng->smiles(mysql_real_escape_string($row['text']), 1, 0).'</p>
								</div>
							</li>
						</ul>';
					}
				} else if($page_sel > 1)
					echo '<br />'.$eng->msg("3", "Комментариев на данной странице нет", "3");
				
				$sql = $db->query("SELECT count(*) FROM `bans_com` WHERE `bans_id` = {$escaped_zid}");
				$row = $db->fetch_row($sql);
				$total_rows = $row[0];
				echo $eng->pagination($total_rows, 20, $page_sel, '/unbans_'.$escaped_zid.'_page');				
			}			
		} else
		echo '<br />'.$eng->msg("2", "Запись не найдена", "2");

	} else if (!empty($_GET['act']) AND $_GET['act'] == 'admin' AND $userinfo['group'] == 4){
	    //панель админа
	    $sql = $db->query("SELECT * FROM `add_bans` ORDER BY id DESC");
		if ($db->num_rows($sql) > 0) {
		    echo '<table class="table table-bordered"><thead><th>От кого (аккаунт на проекте)</th><th>Игровой сервер</th><th>Статус</th><th><center>Действие<center></th></thead><tbody>';
			
		    while($row = mysql_fetch_array($sql)) {
			    $s_login = $us->username($row['s_id'], 0);
			    echo '<tr class="'.$resultcol[$row['type']].'"><td><a href="http://'.$_SERVER['SERVER_NAME'].'/unban.php?act=admin&id='.$row['id'].'">'.$s_login.'</a></td><td>'.$snservers[$row['server']].'</td><td>'.$statuscol[$row['read']].'</td><td><center><a rel="nofollow" target="_blank" class="icon-remove" title="Удалить заявку" href="http://'.$_SERVER['SERVER_NAME'].'/unban.php?act=admin&id='.$row['id'].'&delete" onclick="return confirmDelete();"></a> <a rel="nofollow" target="_blank" class="icon-eye-open" title="Просмотреть эту заявку" href="http://'.$_SERVER['SERVER_NAME'].'/unban.php?act=admin&id='.$row['id'].'"></a> <a rel="nofollow" target="_blank" class="icon-info-sign" title="Поручить заявку на рассмотрение другому руководящему" href="/im"></a></center></td></tr>';
			}
			echo '</tbody></table>';
		} else {
		    echo $eng->msg("3", "Записей не найдено", "3");

	    }
	} else if (empty($escaped_zid) AND empty($_GET['act'])) {
	    //заявки пользователя
		$sql = $db->query("SELECT * FROM `add_bans` WHERE s_id='{$userinfo['id']}' ORDER BY id DESC");
		echo '<a style="float:right;" class="btn" href="http://'.$_SERVER['SERVER_NAME'].'/unban.php?act=create">Подать заявку</a><br /> <br />';
	   	if ($db->num_rows($sql) > 0) {
	   	    echo '<table class="table table-bordered"><thead><th>Сервер</th><th>Ник</th><th>Статус</th><th>Действие</th></thead><tbody>';
	   		$userstatuscol = array("На рассмотрении", "Вы разбанены", "Вы не разбанены");
	   	    while($row = mysql_fetch_array($sql)) 
			{
    		    $s_login = $us->username($row['s_id'], 0);
    		    echo '<tr class="'.$resultcol[$row['type']].'"><td>'.$snservers[$row['server']].'</td><td>'.$row['nick'].'</td><td>'.$userstatuscol[$row['type']].'</td><td><a href="http://'.$_SERVER['SERVER_NAME'].'/unban?id='.$row['id'].'">Подробнее »</a></td></tr>';
    		}
    		echo '</tbody></table>';
    	} else
    	    echo $eng->msg("3", "Записей не найдено", "3");
			
			echo $eng->msg("FAQ Заявки на разбан:",
	        "Информация о бане, находиться в <b>консоле</b><br />
	        Путь демо лежит: <b>Ваша cs/cstrike/name.dem</b><br />
	        Путь скриншота лежит: <b>Ваша cs/cstrike/name.bmp</b><br />", "1");

	}
} else
    echo $eng->msg("2", "Вы не авторизованы или у вас нет прав доступа", "2");

require_once TPL."footer.php";