<?php if (!defined('BYESCL'))			exit('Нет доступа'); ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo $tpl->getTitle(); ?></title>
    <meta name="keywords" content="<?php echo $tpl->getKey(); ?>">
    <meta name="description" content="<?php echo $tpl->getDesc(); ?>">
    <meta name="robots" content="index,follow">
    <meta name="generator" content="<?php echo $version; ?>" />
    <link rel="shortcut icon" href="<?php echo IMG; ?>favicon.ico">

    <!-- Стили -->
    <link href="<?php echo CSS; ?>bootstrap.css?v=2.1" rel="stylesheet">
    <?php
	if (isset($css) AND count($css) > 0) 
	{
		for($i=0;$i<count($css);$i++)
			echo '<link href="'.CSS.$css[$i].'" rel="stylesheet">'."\n";
	}
    ?>
	
    <!--[if lt IE 9]>
        <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
	
    <!-- Подключение JS Bootstrap -->
    <script src="<?php echo JS; ?>jquery.js"></script>
    <script src="<?php echo JS; ?>bootstrap.js"></script>
    <script src="<?php echo JS; ?>jquery.animate-colors.js"></script>
    <script src="<?php echo JS; ?>jquery.cookie.js"></script>
    <script src="<?php echo JS; ?>favicon.ico.js"></script>
    <script src="<?php echo JS; ?>fdg5.js?v=4.9"></script>
    <?php
	if (isset($javascript) AND count($javascript) > 0) 
	{
		for($i=0;$i<count($javascript);$i++)
			echo '<script src="'.JS.$javascript[$i].'"></script>'."\n";
	}
    ?>
	<!--Позже убрать-->
	<script src="<?php echo JS; ?>autoresize.jquery.js"></script>
    <script src="<?php echo JS; ?>jquery.mousewheel-3.0.4.pack.js"></script>
    <script src="<?php echo JS; ?>jquery.fancybox-1.3.4.pack.js"></script>
	<script src="<?php echo JS; ?>jquery.easing-1.3.pack.js"></script>
</head>
<?php
echo '<body>
	<div class="navbar navbar-inverse">
      <div class="navbar-inner">
        <div class="container-fluid">
          <div class="nav-collapse collapse">';
               if ($userinfo['group'] > 0) {
               echo '<ul class="nav pull-right" id="authorized">
                  <li id="fat-menu" class="dropdown">
                     <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                     <img style="margin-right: 5px;" src="'.$us->avatar($userinfo['id']).'" width="20" height="20"/> '.$userinfo['login'].' <b class="caret"></b></a>
                     <ul class="dropdown-menu">';
							  if ($userinfo['id'] == 1)
								echo '<li><a href="'.BASEDIR.'ap">Админ панель</a></li>'."\n";
							  if ($userinfo['group'] == 4)
								echo '<li><a href="'.BASEDIR.'admins">Управление админ/вип</a></li>'."\n";
                              echo '<li class="divider"></li>
                              <li><a href="'.BASEDIR.'logout">Выход</a></li>
                     </ul>
                  </li>
                 </ul>';
               }
			  echo'<div class="btn btn-primary"><font color="white">Name of project</font></div><i class="divider-vertical"></i>
			  <a class="btn btn-inverse" href="/"><i class="icon-home icon-white"></i> <font color="white"> Главная</font></a>
			  <a class="btn btn-inverse" href="/news"><i class="icon-list-alt icon-white"></i> <font color="white"> Новости</font></a>
			  <a class="btn btn-inverse" href="/users"><i class="icon-user icon-white"></i> <font color="white"> Пользователи</font></a>
			  <a class="btn btn-inverse" href="/forums"><i class="icon-comment icon-white"></i> <font color="white"> Форум</font></a>
			  <a class="btn btn-inverse" href="/unban_list"><i class="icon-eye-open icon-white"></i> <font color="white"> Заявки на разбан</font></a>
			  <a class="btn btn-inverse" href="/bans_1"><i class="icon-warning-sign icon-white"></i> <font color="white"> Банлист</font></a>
          </div>
        </div>
      </div>
    </div>

<div id="templatemo_body_wrapper">
<div id="templatemo_main_wrapper">
<div id="templatemo_content_outer">
<div id="templatemo_content_inner">
<div id="sidebar">
<div class="sidebar_box">'."\n";
if ($userinfo['group'] > 0) 
{
	$sql = $db->query("SELECT * FROM `friends` WHERE `id` = '{$userinfo['id']}' AND `toinvites` != ''");
	echo '	<div class="leftblock">
		<h3 class="blockzag">Аккаунт ['.$userinfo['login'].'] [iE7_ID:'.$userinfo['id'].']</h3>
		<div class="bodyblock">
		<ul class="nav nav-list">
		<li'; echo ($page == 'profile') ? " class='active'" : ""; echo'><a href="'.SITEDIR.''.BASEDIR.'/profile_'.$userinfo['id'].'"><i class="icon-user"></i> Профиль</a></li>
		<li'; echo ($page == 'friends') ? " class='active'" : ""; echo'><a href="'.SITEDIR.''.BASEDIR.'/friends"><i class="icon-star-empty"></i> Друзья'; echo ($db->num_rows($sql) ? " <font class='pull-right' color='#ff8800'>[Есть новые]</font>" : " "); echo'</a></li>
		<li'; echo ($page == 'pm') ? " class='active'" : ""; echo'><a href="'.SITEDIR.''.BASEDIR.'/im"><i class="icon-envelope"></i> Сообщения <span id="num_msg"></span></a></li>'."\n";
		echo '<li'; echo ($page == 'logs') ? " class='active'" : ""; echo'><a href="'.SITEDIR.''.BASEDIR.'/logs"><i class="icon-refresh"></i> Логи авторизации</a></li>'."\n";
		echo '<li'; echo ($page == 'settings') ? " class='active'" : ""; echo'><a href="'.SITEDIR.''.BASEDIR.'/settings"><i class="icon-wrench"></i> Настройки</a></li>'."\n";
		echo '<li'; echo ($page == 'bans') ? " class='active'" : ""; echo'><a href="'.SITEDIR.''.BASEDIR.'/bans_1"><i class="icon-warning-sign"></i> <font color="red">Банлист [Game serv]</font></a></li>'."\n";
		echo '<li class="divider"></li>';
		if ($userinfo['group'] == 4)
		echo '<li><center><b><font color="red"><i class="icon-off"></i> Администратирование <i class="icon-chevron-down"></i></font></b></center></li>'."\n";
		if ($userinfo['group'] == 4)
		echo '<li class="divider"></li>';
		if ($userinfo['id'] == 1)
		echo '<li><a href="'.BASEDIR.'ap"><i class="icon-check"></i> Админ-панель Escl CMS [iE7]</a></li>'."\n";
		if ($userinfo['id'] == 1)
		echo '<li><a href="'.BASEDIR.'ap?act=servers"><i class="icon-check"></i> Управление серверами [iE5]</a></li>'."\n";
		if ($userinfo['id'] == 1)
		echo '<li><a href="'.BASEDIR.'ap?act=news"><i class="icon-check"></i> Управление новостями [iE7]</a></li>'."\n";
		if ($userinfo['group'] == 4)
		echo '<li><a href="'.BASEDIR.'admins"><i class="icon-check"></i> Управление Admin/VIP [iE5]</a></li>'."\n";
		if ($userinfo['group'] == 4)
		echo '<li><a href="'.BASEDIR.'check"><i class="icon-check"></i> Привязка профиля [iE5]</a></li>'."\n";
		if ($userinfo['group'] == 4) 
		{
			echo '<li class="divider"></li>';
		}
		if ($userinfo['group'] == 4) 
		{
			$query = "SELECT count(*) AS `count` FROM `add_bans` WHERE `read` = 0";
			$link = 'unban_ap';
			$name = 'Управление [Unban]';
		} else {
			$query = "SELECT count(*) AS `count` FROM `add_bans` WHERE `read` = 1 AND `s_id` = '{$userinfo['id']}'";
			$link = 'unban';
			$name = 'Мои заявки на разбан';
		}
		$sql = $db->query($query);
		$row = $db->fetch_array($sql);
		echo '<li'; echo ($page == 'unban') ? " class='active'" : ""; echo'><a href="'.SITEDIR.''.BASEDIR.'/'.$link.'"><i class="icon-eye-open"></i> '.$name; echo ($row['count'] > 0) ? ' (<font color="#7f521d">'.$row['count'].'</font>)' : ""; echo'</a></li>'."\n";
		echo '<li><a href="/stats"><i class="icon-signal"></i> Статистика [Game serv]</a></li>
		<li><a href="/userpanel"><i class="icon-shopping-cart"></i> Мои Admin/VIP [Game serv]</a></li>';
		echo '<li class="divider"></li>';
		if($page == 'main')
			echo '<li><a onclick="$(\'#film\').toggle();if($(\'#film\').is(\':visible\')){$(\'#statustv\').html(\'[Вкл]\');$(\'#statustv\').css({\'color\':\'green\'});}else{$(\'#statustv\').html(\'[Выкл]\'); $(\'#statustv\').css({\'color\':\'red\'});}"><i class="icon-film"></i> Телевизор <font color="red" id="statustv">[Выкл]</font></a></li>'."\n";
		echo '<li><a onclick="$(\'#music\').toggle();if($(\'#music\').is(\':visible\')){$(\'#statusmusic\').html(\'[Вкл]\');$(\'#statusmusic\').css({\'color\':\'green\'});}else{$(\'#statusmusic\').html(\'[Выкл]\'); $(\'#statusmusic\').css({\'color\':\'red\'});}"><i class="icon-music"></i> Радио <font color="red" id="statusmusic">[Выкл]</font></a></li>'."\n";		
		echo '<li class="divider"></li>';
		echo '<li><a href="'.SITEDIR.''.BASEDIR.'/logout"><i class="icon-off"></i> Выход</a></li>'."\n";
	echo '</div>
	</div>'."\n";
} else {
    echo '<div class="leftblock">
		<h3 class="blockzag">Авторизация</h3>
	    <div class="bodyblock">
		  <form action="auth" method="post" class="form-signin">
			<input type="text" name="login" class="input-block-level" placeholder="Логин">
			<input type="password" name="password" class="input-block-level" placeholder="Пароль">
			<center>
			<div class="btn-toolbar">
            <div class="btn-group">
			<button class="btn btn-mini btn-success" type="submit">Войти</button>
            <button class="btn btn-mini btn-warning" formaction="/lostpwd">Забыл пароль</button>
           <button class="btn btn-mini btn-danger" formaction="/reg">Регистрация</button>
          </div>
          </div>
		  </center>
		  </form>
	    </div>
	  </div>'."\n";
}

echo '<div class="leftblock">'."\n";
echo '	<h3 class="blockzag">Навигация</h3>';
echo '<p>
<ul class="nav nav-list">
  <li><a href="http://www.escl-professional.ru/"><i class="icon-home"></i> Главная страница проекта</a></li>
  <li class="active"><a href="/"><i class="icon-hdd icon-white"></i> Игровой комплекс</a></li>
  <li><a href="http://bans.escl-professional.ru/"><i class="icon-exclamation-sign"></i> Банлист [ESCL-BANS]</a></li>
  <li><a href="http://boost.escl-professional.ru/"><i class="icon-tasks"></i> Раскрутка серверов [BOOST]</a></li>
  <li><a href="http://network.escl-professional.ru/"><i class="icon-th"></i> Рабочая сеть (NetWork)</a></li>
  <li><a href="http://community.escl-professional.ru/"><i class="icon-flag"></i> Game Community</a></li>
  <li><a href="http://shop.escl-professional.ru/"><i class="icon-shopping-cart"></i> Магазин цифровых товаров</a></li>
</ul>
</p>
</div>';

echo '<div class="leftblock">'."\n";
echo '<h3 class="blockzag">Авторизованные</h3>';
echo '<div class="bodyblock marginleft20 usonline">';
echo $us->who_online();
echo '</div>
</div>';

$sql = $db->query("SELECT * FROM `news` ORDER BY `id` DESC LIMIT 3");
if ($db->num_rows($sql) > 0) 
{
	echo '	<div class="leftblock">
	<h3 class="blockzag">Последние новости</h3>
		<div class="bodyblock">';	
	echo '<ul class="nav nav-list">'."\n";
		while($row = $db->fetch_array($sql))
			echo '<li><a href="'.SITEDIR.''.BASEDIR.'/news_'.$row['id'].'"><i class="icon-hand-right"></i> '.$row['name'].'</a></li>'."\n";
	echo '</ul>
		</div>
	</div>';
}
{
echo '<div class="leftblock">'."\n";
echo '<h3 class="blockzag">ESCL-TeamSpeek 3 Сервер</h3>';
echo '<div class="bodyblock">';
echo '<ul class="nav nav-list">';
echo '<center><img src="/main/img/ts.png"/></center>'."\n";
echo '<td><b>Адрес: [109.120.161.43]</b></td>'."\n";
echo '<br><td><b>Хост: [ESCL-PROFESSIONAL]</b></td>'."\n";
echo '<br><td><b>Слоты: [+32 slots]</b></td>'."\n";
echo '<br><td><b>License: [No License]</b></td>'."\n";
echo '<br><td><b>Статус: [<font color="red">OFFLINE</font>]</b></td>'."\n";
echo '<li class="divider"></li>';
echo '<center><a class="btn btn-mini btn-inverse" href="ts3server://ваш ts3 сервер"><font color="red">NO_CONNECT TO TS3 SERVER</font></a></center>'."\n";
echo '</div>
</div>';
}
echo '<div class="leftblock">'."\n";
echo '	<h3 class="blockzag">Информация</h3>';
echo '	<div class="bodyblock marginleft20"><i class="icon-user"></i> <b>Гл. Администратор:</b> <a target="_blank" href="'.SITEDIR.''.BASEDIR.'/profile_1"><font color="red">Ваш ник</font></a><br />
	<img width="18px" src="/main/img/skype.png"/> <b><a href="skype:ваш скайп?add">ваш скайп</a></b><br />
	<img width="18px" src="/main/img/wmr.png"/> <b>RXXXXXXXXXXXX</b>
</div>';
echo '</div>';

if ($userinfo['group'] > 0) 
{ 
	echo '<div class="leftblock hide" id="music">'."\n";
	echo '<h3 class="blockzag">Радио</h3>';
	echo '<div class="bodyblock marginleft20" >
	<iframe style="border:1px solid rgb(214, 214, 214);overflow:hidden;border-radius:5px;-webkit-border-radius:5px;-moz-border-radius: 5px;" frameborder="0" scrolling="no" src="http://lovi.fm/mini/?c=4&a=0&r=1&h=300&s=21,1361,23,1539,22,26,31,73,1301,29,1381,110,272,757,24,1432" width="215" height="300"></iframe></div>';
	echo '</div>';
}
echo '</div>
</div>
<div id="templatemo_content">'."\n";
if (isset($nav) AND count($nav) > 0) 
{
	echo '<ul class="breadcrumb"><li><a href="'.SITEDIR.''.BASEDIR.'">Главная</a> <span class="divider">/</span></li>';
	for ($i=0; $i < count($nav); $i++)
	{
		if(isset($nav[$i]['url']))
			echo '<li><a href="'.SITEDIR.''.BASEDIR.''.$nav[$i]['url'].'">'.$nav[$i]['name'].'</a>'; 
		else
			echo '<li class="active">'.$nav[$i]['name'];
		echo ($i != count($nav)-1) ? '<span class="divider">/</span>' : ''; 
		echo '</li>';
	}
	echo '</ul>';
}