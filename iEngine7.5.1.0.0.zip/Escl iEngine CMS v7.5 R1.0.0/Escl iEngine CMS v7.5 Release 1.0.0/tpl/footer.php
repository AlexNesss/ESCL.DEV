<?php if (!defined('BYESCL'))			exit('Нет доступа'); 

echo '</div> <!-- конец content -->
<div class="cleaner" id="misc"></div>
</div> <!-- конец inner content -->
</div> <!-- конец outer content -->
<div id="templatemo_content_bottom">
<div id="Go_Top">▲ Наверх</div>
</div>
<div class="c1" id="templatemo_footer">
<a class="btn btn-primary btn-mini" href="javascript:ToggleBar(0);"><font color="lightblue"><b>Изменить разрешение</b></font></a>
<br><br>
<link href="/main/footer/css/footer_block.css?v=3340083913&client=0" rel="stylesheet" type="text/css">
 <!-- footer -->
 <div id="footer">
 <div class="footer_content">
 <div id="footerLogo"><img src="/main/footer/img/footerLogo_escl.png" width="96" height="26" border="0" alt="Логотип Escl" /></div>
 <div id="footerText">
 &copy; Проект <a href="http://www.escl-professional.ru/"><b>ESCL-PROFESSIONAL.RU</b></a>. Все права защищены (All rights reserved). Лицензия и права на проект пренадлежат WWW.ESCL-PROFESSIONAL.RU. <br> <font color="red">Сайт работает на Escl iEngine CMS [Version 7.5 Release 1.0.0]</font> </div>
 </div>
 </div>

 <!-- /footer -->


</div>
<script src="//mc.yandex.ru/metrika/watch.js" type="text/javascript"></script><script type="text/javascript">try { var yaCounter19531540 = new Ya.Metrika({id:19531540}); } catch(e) { }</script><noscript><div><img src="//mc.yandex.ru/watch/19531540" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<p class="muted"><span class="text-warning"></span></p>';
echo '</div> <!-- конец footer -->
</div> <!-- конец templatemo_main_wrapper -->
</div>  <!-- конец templatemo_body_wrapper -->'."\n";
echo '</body>
</html>';
mysql_close();