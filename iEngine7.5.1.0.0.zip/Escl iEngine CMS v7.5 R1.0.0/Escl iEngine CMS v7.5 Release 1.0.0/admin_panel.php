<?php
session_start();
define ('BYESCL', true);
require_once "core/maincore.php";
$page = 'admin';

require_once TPL."header.php";

if ($userinfo['group'] > 0 AND $userinfo['id'] == 1) {
	if (isset($_GET['create']) && isset($_GET['ip']) && isset($_GET['port'])) {
		$ip = mysql_real_escape_string($eng->stripinput($_GET['ip']));
		$port = mysql_real_escape_string($eng->stripinput($_GET['port']));
		$sql = $db->query("INSERT INTO `servers` (ip, port) VALUE ('$ip','$port')");
		if ($sql) {
			echo $eng->msg("1", "Сервер успешно добавлен", "1"); 
		} else {
			echo $eng->msg("4", "Ошибка при создании сервера", "4"); 
		}
	} elseif (isset($_GET['ip']) && isset($_GET['port'])) {
		$ip = mysql_real_escape_string($eng->stripinput($_GET['ip']));
		$port = mysql_real_escape_string($eng->stripinput($_GET['port']));
		$serverid = intval($_GET['servid']);
		$sql = $db->query("UPDATE  `servers` SET  `ip` =  {$ip}, `port` = {$port}  WHERE `id` = {$serverid}");
		if ($sql) {
			echo $eng->msg("1", "Сервер успешно обновлен", "1"); 
		} else {
			echo $eng->msg("4", "Ошибка при изменении сервера", "4"); 
		}
	}
    # Управление новостями
    if (!empty($_GET['act']) AND $_GET['act'] == 'news') {
	    # Редактирование новости
	    if (!empty($_GET['id'])) {
		    $id_edit = intval($_GET['id']);
			$sql = mysql_query("SELECT * FROM `news` WHERE `id` = '{$id_edit}'");
			if(mysql_num_rows($sql) > 0) {
			    # Отправили данные на изменение новости
			    if(isset($_POST['text_edit_news']) and isset($_POST['name_edit_news'])) {
    				$text = mysql_real_escape_string($eng->stripinput($_POST['text_edit_news']));
    				$name = mysql_real_escape_string($eng->stripinput($_POST['name_edit_news']));
    				if(!empty($name) AND !empty($text)) {
    			   	    $edit_new = mysql_query("UPDATE `news` SET `name` = '{$name}', `text` = '{$text}' WHERE `news`.`id` = {$id_edit};");
    				    echo $eng->msg("1", "Новость успешно изменена", "1"); 
						echo '<meta http-equiv="refresh" content="2;URL=http://'.$_SERVER['SERVER_NAME'].'/ap?act=news">';
    				} else { 
						echo $eng->msg("4", "Не все поля были заполнены", "4"); 
						echo '<meta http-equiv="refresh" content="2;URL=http://'.$_SERVER['SERVER_NAME'].'/ap?act=news">';
					}
    		    } else {
					$row = mysql_fetch_assoc($sql);
					$text = str_replace("<br />", "\r\n", $row['text']);
			    	echo '<form method="POST" class="form-horizontal" action=""><fieldset>
    		    	        <legend>Редактирование новости <a style="float:right; font-weight: normal;" class="btn btn-warning  btn-mini" href="http://'.$_SERVER['SERVER_NAME'].'/ap?act=news">Назад</a></legend>
    		    		    <div class="control-group"><label class="control-label" for="name">Название:&nbsp;&nbsp;&nbsp;</label><input class="span6" type="text" name="name_edit_news" id="name" value="'.$row['name'].'" ></div>
            	            <div class="control-group"><label class="control-label" for="textarea">Текст:&nbsp;&nbsp;&nbsp;</label><textarea class="span6" name="text_edit_news" id="textarea" rows="5">'.$text.'</textarea></div>
    			    		<div class="form-actions"><input type="submit" value="Редактировать новость" class="btn btn-info"></div>
    	    	          </fieldset></form>';
			    }
			} else { 
				echo $eng->msg("2", "Новость не найдена", "2"); 
			}
		} else {
    		# Удаление новости
            if(!empty($_POST['id_del'])) {
    			$del_news = intval($_POST['id_del']);
    	   	    $sql = mysql_query("DELETE FROM `news` WHERE `id` = {$del_news}");
				echo $eng->msg("1", "Новость успешно удалена", "1"); 
            }    
    		# Добавление новости
    		else if(isset($_POST['text_add_news']) and isset($_POST['name_add_news'])) {
				$text = mysql_real_escape_string($eng->stripinput($_POST['text_add_news']));
				$name = mysql_real_escape_string($eng->stripinput($_POST['name_add_news']));
    			if(!empty($name) AND !empty($text)) {
    			    $add_new = mysql_query("INSERT INTO `news` (text,user_id,name,date) VALUE ('$text','{$userinfo['id']}','$name','".time()."')");
					echo $eng->msg("1", "Новость успешно добавлена", "1"); 
    			} else
    			    echo $eng->msg("4", "Не все поля были заполнены", "4"); 
    		}


    	    $sql = mysql_query("SELECT * FROM `news` ORDER BY `id` ASC");
    		echo '<form method="POST" id = "add_news" style = "display: none;" class="form-horizontal" action=""><fieldset>
    		        <legend>Добавление новости <a style="float:right; font-weight: normal;" class="btn btn-warning  btn-mini" onClick="Toggle(add_news)">Скрыть</a></legend>
    			    <div class="control-group"><label class="control-label" for="name">Название:&nbsp;&nbsp;&nbsp;</label><input class="span6" type="text" name="name_add_news" id="name" value="" ></div>
                    <div class="control-group"><label class="control-label" for="textarea">Текст:&nbsp;&nbsp;&nbsp;</label><textarea class="span6" name="text_add_news" id="textarea" rows="5"></textarea></div>
    				<div class="form-actions"><input type="submit" value="Добавить новость" class="btn btn-info"></div>
    	          </fieldset></form>
    		      <legend>Список новостей <button class="btn pull-right" onClick="Toggle(add_news)">Добавить новость</button></legend>
    			  <table class="table table-bordered"><thead><th>Название</th><th>Дата добавления</th></thead><tbody>';
			 
			 if (isset($_GET['page'])) $page_sel=(intval($_GET['page'])-1); else $page_sel=0;
			  $start=abs($page_sel*20);
			  $sql = mysql_query("SELECT * FROM `news` ORDER BY `id` DESC LIMIT $start,20");
			  while($cur = mysql_fetch_array($sql)) { echo '<tr><td><a href="http://'.$_SERVER['SERVER_NAME'].'/ap?act=news&id='.$cur['id'].'">'.$cur['name'].'</a></td> <td>'.$cur['date'].'</td> <td><form method="POST" action=""><input type="hidden" name="id_del" value="'.$cur['id'].'"><input type="submit" onclick="return confirmDelete();" value="Удалить"></form></td></tr>'; }        
			  echo '</tbody></table>';
			  $sql=mysql_query("SELECT count(*) FROM `news`");
			  $row=mysql_fetch_row($sql);
			  $total_rows=$row[0];
			  $num_pages=ceil($total_rows/20);
				if ($num_pages > 1) {
					echo '<div class="pagination pagination-centered"><ul>';
					for($i=1;$i<=$num_pages;$i++) { 
						if ($i-1 == $page_sel) { 
							echo '<li class="active"><a>'.$i.'</a></li>'; 
						} else { 
							echo '<li><a href="http://'.$_SERVER['SERVER_NAME'].'/ap?act=news&page='.$i.'">'.$i."</a></li>"; 
						}
					}
					echo "</ul></div>\n";
				}
		}
	}
	# Управление пользователями
    else if (!empty($_GET['act']) AND $_GET['act'] == 'users') {
	    # Редактирование пользователя
	    if (!empty($_GET['id'])) {
		    $id_edit = intval($_GET['id']);
			$sql = mysql_query("SELECT * FROM `users` WHERE `id` = '{$id_edit}'");
			if(mysql_num_rows($sql) > 0) {
		        if (isset($_POST['login']) AND isset($_POST['group_id']) AND isset($_POST['email']) AND isset($_POST['name']) AND isset($_POST['nick']))	{
                    $group_id = $_POST['group_id'];
					$login = $_POST['login'];
					$email = $_POST['email'];
					$name = $_POST['name'];
					$nick = $_POST['nick'];
					$vk = $_POST['vk'];
                    if (empty($email) or empty($name) or empty($group_id) or empty($login)) 
                    {
                        echo $eng->msg("4", "Не все поля были заполнены, повторите попытку $email $name $group_id $login", "4"); 
						echo '<meta http-equiv="refresh" content="2;URL=http://'.$_SERVER['SERVER_NAME'].'/ap?act=users&id='.$id_edit.'">';
						require_once TPL."footer.php";
						exit();
                    }
					$group_id = intval($group_id);
					$login = trim(htmlspecialchars(stripslashes($login)));
					$email = trim(htmlspecialchars(stripslashes($email)));
					$name = trim(htmlspecialchars(stripslashes($name)));
					$nick = trim(htmlspecialchars(stripslashes($nick)));
					$vk = trim(htmlspecialchars(stripslashes($vk)));
					# Создаем пустой массив ошибок
					$err = array();
                    # Проверка на существование пользователя с таким же логином
                    $sql = mysql_query("SELECT id FROM users WHERE login='{$login}'");
                    $sqln = mysql_query("SELECT login FROM users WHERE id='{$id_edit}'");
    				$row = mysql_fetch_assoc($sqln);
            		if (mysql_num_rows($sql) > 0 AND $row['login'] != $login) {
                        $err[] = 'Введённый вами логин уже зарегистрирован';
                    }
                    # Проверка на существование группы пользователя
                    $sql = mysql_query("SELECT group_id FROM groups WHERE group_id='{$group_id}'");
            		if (mysql_num_rows($sql) == 0) {
                        $err[] = 'Группы не существует';
                    }
					# Есть ли пользователь с введенным почтовым ящиком
					$sql = mysql_query("SELECT id, email FROM users WHERE email='{$email}'") or die(mysql_error());
                    $sqln = mysql_query("SELECT email FROM users WHERE id='{$id_edit}'");
    				$row = mysql_fetch_assoc($sqln);
					if (mysql_num_rows($sql) > 0 AND $row['email'] != $email) {
						$err[] = 'Введённый вами почтовый ящик уже зарегистрирован';
					}
					# Валиден ли логин
					if (!preg_match('/^[A-Za-z0-9_\+-\.,\[\]\)\(@!\?\$\*~\s]{3,15}$/i', $login)) {
						$err[] = 'Логин не должен содержать запрещенные символы и его длина должна быть от 3 до 15 символов';
					} 
					# Валиден ли почтовый ящик
					if(!preg_match("/^[A-Z0-9._-]+@[A-Z0-9.-]{1,61}\.[A-Z]{2,6}$/i", $email)){ 
						$err[] = 'Формат почтового ящика не корректен';
					} 
					# Валидна ли ссылка на профиль вконтакте
					if(!preg_match("/http:\/\/vk\.com\/[a-zA-Z0-9_.]{1,40}$/", $vk) AND !empty($vk)){ 
						$err[] = 'Формат ссылки на профиль ВКонтакте не корректен';
					} 	
					# Если ошибок нет
					if(count($err) == 0) {
						$sql = mysql_query ("UPDATE `users` SET  `login` =  '{$login}', `email` =  '{$email}', `name` =  '{$name}', `nick` =  '{$nick}', `vk` =  '{$vk}', `group_id` =  '{$group_id}' WHERE id = '{$id_edit}'");
						if ($sql)
						{
							echo $eng->msg("1", "Данные пользователя ".$login." успешно обновлены", "1");
							$redirect = '/ap?act=users';
						} else {
							echo $eng->msg("2", "Данные не были обновлены", "2");
							$redirect = '/ap?act=users';
						}
					# Если ошибки есть
					} else {
						$errormsg = '';
						foreach($err AS $error)
						{
							$errormsg .= $error."<br>";
						}
						echo $eng->msg("2", $errormsg, "2");
						$redirect = '/ap?act=users';
					}
					echo '<meta http-equiv="refresh" content="3;URL=http://'.$_SERVER['SERVER_NAME'].''.$redirect.'">';
					require_once TPL."footer.php";
					exit();
				} else {
					$row = mysql_fetch_assoc($sql);
					$gresult = mysql_query('SELECT * FROM `groups` ORDER BY `group_id` ASC');
					echo '<table class="table table-bordered"><legend>Редактирование профиля '.$row['login'].'  <a style="float:right; font-weight: normal;" class="btn btn-warning  btn-mini" href="http://'.$_SERVER['SERVER_NAME'].'/ap?act=users" ">Назад</a></legend>
					<form  action="" method="post" autocomplete="off"><p><label for="login">Логин: <br></label><input name="login" id="login" type="text" size="15" maxlength="20" value="'.$row['login'].'"></p>
					<p><label>Группа: <br></label><select name="group_id">';
					while($rowg = mysql_fetch_array($gresult)) { 
						if ($rowg['group_id'] == $row['group_id']){ 
							echo '<option selected value="'.$rowg['group_id'].'">'.$us->groupname($rowg['group_id'], 0).'</option>'; 
						} else { 
							echo '<option value="'.$rowg['group_id'].'">'.$us->groupname($rowg['group_id'], 0).'</option>'; 
						} 
					}
					echo '</select></p>
					<p><label>Skill: <br></label><select name="skill_id">';
					while($rowg = mysql_fetch_array($gresult)) { 
						if ($rowg['skill_id'] == $row['skill_id']){ 
							echo '<option selected value="'.$rowg['skill_id'].'">'.$us->skillname($rowg['skill_id'], 0).'</option>'; 
						} else { 
							echo '<option value="'.$rowg['skill_id'].'">'.$us->skillname($rowg['skill_id'], 0).'</option>'; 
						} 
					}
					echo '</select></p>
					<p><label for="email">Почтовый ящик: <br></label><input name="email" id="email" type="text" size="15" maxlength="30" value="'.$row['email'].'"></p>
					<p><label for="name">Имя: <br></label><input name="name" id="name" type="text" size="15" maxlength="15" value="'.$row['name'].'"></p>
					<p><label for="nick">Ник в игре: <br></label><input name="nick" id="nick" type="text" size="15" maxlength="25" value="'.$row['nick'].'"></p>
					<p><label for="vk">Профиль Вконтакте: <br></label><input name="vk" id="vk" type="text" size="15" maxlength="60" type="text" value="'.$row['vk'].'"></p>
					<p><input type="submit" class="btn btn-info" name="submit" value="Подтвердить"></p></form></table>';
				}
			} else { 
				echo $eng->msg("2", "Пользователь не найден", "2"); 
			}
		}
	    # Поиск пользователя
	    else if (!empty($_POST['search'])) {
	        $search = mysql_real_escape_string($eng->stripinput($_POST['search']));
            $sql = mysql_query("SELECT * FROM users WHERE login LIKE '%{$search}%' ORDER BY `id` ASC LIMIT 50");
		    echo '<form class="input-append pagination-centered" method="POST"><input type="text" name="search" value="'.$search.'" class="span3"><input type="submit" value="Поиск" class="btn"></form><br /><div class="pagination-centered">Найдено записей: '.mysql_num_rows($sql).'</div><br />';
		    if (mysql_num_rows($sql) > 0) {
		        echo '<table class="table table-bordered"><thead><th>#</th><th>Ник</th><th>Группа</th></thead><tbody>';
                while($row=mysql_fetch_array($sql)) {
	                $groupname= $us->groupname($row['group_id'], 0);
                    echo '<tr><td><span class="badge">'.$row['id'].'</span></td><td><img style="margin-right: 5px;" src="'.$us->avatar($row['id']).'" width="20" height="20"/> <a href="http://'.$_SERVER['SERVER_NAME'].'/ap?act=users&id='.$row['id'].'">'.$row['login'].'</td> <td>'.$groupname.'</td></tr>';
                }
			    echo '</tbody></table>';
		    } else {
		        echo $eng->msg("3", "Результатов не найдено", "3"); 
		    }
	    }
		# список пользователей
	    else {
            echo '<form class="input-append pagination-centered" method="POST"><input type="text" name="search" class="span3"><input type="submit" value="Поиск" class="btn"></form><br />
    		<table class="table table-bordered"><thead><th>#</th><th>Ник</th><th>Группа</th></thead><tbody>';
            if (isset($_GET['page'])) $page_sel=(intval($_GET['page'])-1); else $page_sel=0;
            $start=abs($page_sel*20);
            $sql = mysql_query("SELECT * FROM `users` ORDER BY `id` ASC LIMIT $start,20");
            while($row=mysql_fetch_array($sql)) {
    	        $groupname= $us->groupname($row['group_id'], 0);
                echo '<tr><td><span class="badge">'.$row['id'].'</span></td><td><img style="margin-right: 5px;" src="'.$us->avatar($row['id']).'" width="20" height="20"/> <a href="http://'.$_SERVER['SERVER_NAME'].'/ap?act=users&id='.$row['id'].'">'.$row['login'].'</td> <td>'.$groupname.'</td></tr>';
            }
        	echo '</tbody></table>';
            $sql=mysql_query("SELECT count(*) FROM `users`");
            $row=mysql_fetch_row($sql);
            $total_rows=$row[0];
            $num_pages=ceil($total_rows/20);
    	    echo '<div class="pagination pagination-centered"><ul>';
            for($i=1;$i<=$num_pages;$i++) {
				if ($i-1 == $page_sel) {
					echo '<li class="active"><a>'.$i.'</a></li>';
				} else {
					echo '<li><a href="http://'.$_SERVER['SERVER_NAME'].'/ap?act=users&page='.$i.'">'.$i."</a></li>";
				}
            }
    	    echo "</ul></div>\n";
	    }
	}
	# Управление серверами
    else if (!empty($_GET['act']) AND $_GET['act'] == 'servers') {
		if(isset($_GET['do']) AND $_GET['do'] == 'create')
		{
				echo '<legend>Добавление сервера  <a style="float:right; font-weight: normal;" class="btn btn-warning  btn-mini" href="http://'.$_SERVER['SERVER_NAME'].'/ap?act=servers" ">Назад</a></legend>';
				echo '<form class="form-horizontal" action="" method="get" autocomplete="off">	
						<div class="control-group">
							<label class="control-label" for="ip">IP: </label>
							<div class="controls">
								<input name="ip" id="ip" type="text" value="" required="">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="port">PORT: </label>
							<div class="controls">
								<input name="port" id="port" type="text" value="" required="">
								<input name="create" id="create" type="hidden" value="create" required="">
							</div>		
						</div>
						<div class="control-group">
							<div class="controls">
								<input type="submit" class="btn btn-info" name="submit" value="Добавить">
							</div>
						</div>
						</form>';
		} elseif(!empty($_GET['servid'])) {
			if(isset($_GET['del']) && isset($_GET['servid'])) {
				$serverid = intval($_GET['servid']);
		   	    $sql = mysql_query("DELETE FROM `servers` WHERE `id` = {$serverid}");
				echo $eng->msg("1", "Сервер успешно удален", "1"); 

			} else 
			$servid = intval($_GET['servid']);
			if (!empty($servid)) {
				$sql = $db->query("SELECT * FROM `servers` WHERE `id` = '{$servid}'");
				if($db->num_rows($sql) > 0) 
				{
					$row = $db->fetch_array($sql);
					echo '<legend>Редактирование сервера '.$row['hostname'].'  <a style="float:right; font-weight: normal;" class="btn btn-warning  btn-mini" href="http://'.$_SERVER['SERVER_NAME'].'/ap?act=servers" ">Назад</a></legend>';
					echo '<form class="form-horizontal" action="" method="get" autocomplete="off">
							<div class="control-group">
								<label class="control-label" for="ip">IP: </label>
								<div class="controls">
									<input name="ip" id="ip" type="text" value="'.$row['ip'].'" required="">
								</div>
							</div>
							<div class="control-group">
								<label class="control-label" for="port">PORT: </label>
									<div class="controls">
										<input name="port" id="port" type="text" value="'.$row['port'].'" required="">
										<input name="servid" id="servid" type="hidden" value="'.$row['id'].'" required="">
									</div>
							</div>
							<div class="control-group">
								<div class="controls">
									<input type="submit" class="btn btn-info" name="submit" value="Изменить">
								</div>
							</div>
							</form>';
							echo '<a href="http://'.$_SERVER['SERVER_NAME'].'/ap?act=servers&servid='.$row['id'].'&del" class="btn btn-danger">Удалить сервер</a>';
				} else if (!isset($_GET['del'])) {
					echo $eng->msg("3", "Сервера не найдено", "3"); 
				}
			}
		} else {
			echo '<center><a href="http://'.$_SERVER['SERVER_NAME'].'/ap?act=servers&do=create" class="btn btn-info">Добавить новый</a></center><br />';
			$sql = $db->query("SELECT * FROM `servers`");
			if($db->num_rows($sql) > 0) 
			{
				echo '<table class="table table-striped table-bordered table-condensed blockservers">
								<thead>
									<tr>	
										<th>№</th>	
										<th>Название сервера</th>
										<th>Адрес</th>
										<th width="100px">Управление</th>
									</tr>
								</thead>
							<tbody>';
				while($row = $db->fetch_array($sql)) 
				{
					echo "<tr>
									<td>{$row['id']}</td>	
									<td>{$row['hostname']}</td>
									<td>{$row['ip']}:{$row['port']}</td>
									<td><a href='http://".$_SERVER['SERVER_NAME']."/ap?act=servers&servid={$row['id']}'>Редактировать</a></td>
								</tr>\n";
				}
				echo '</tbody></table>';
			} else {
				echo $eng->msg("3", "Серверов нет", "3"); 
			}
		}
	}
	# Управление чатом
    else if (!empty($_GET['act']) AND $_GET['act'] == 'chat') {
    	# Удаление сообщения
        if(!empty($_POST['id_del'])) {
    		$del_chat = intval($_POST['id_del']);
    	   	$sql = mysql_query("DELETE FROM `messages` WHERE `id` = {$del_chat}");
            echo $eng->msg("1", "Сообщение удалено", "1"); 
        }    
    	# Очистка чата
        if(!empty($_POST['chat_clear']) AND $_POST['chat_clear'] == 1) {
    	   	$sql = mysql_query("TRUNCATE TABLE `messages`");
            echo $eng->msg("1", "Чат успешно очищен", "1"); 
			echo '<meta http-equiv="refresh" content="2;URL=http://'.$_SERVER['SERVER_NAME'].'/ap?act=chat">';
        }  
	    else
		{
	        echo '<legend>Управление чатом</legend>';
	        echo '<pre class="pagination-centered"><form method="POST" action=""><input type="hidden" name="chat_clear" value="1"><input type="submit" onclick="return confirmClear();" value="Очистить чат"></form></pre>';
	        echo '<legend>Последняя тридцатка сообщений</legend>';
	    	$sql = mysql_query("SELECT * FROM `messages` ORDER BY `id` DESC LIMIT 30");
	    	if (mysql_num_rows($sql) > 0) {
                while($row=mysql_fetch_array($sql)) {
			        if (strlen($row['text']) > 50) { 
						$text = ''.mb_substr($row['text'], 0, 50, 'UTF-8').'...'; 
					} else { 
						$text = $row['text']; 
					}
		            echo '<pre><b>'.$us->username($row['user_id'], 0).'</b> &raquo; '.$text.' <span style="float:right;"><form method="POST" action=""><input type="hidden" name="id_del" value="'.$row['id'].'"><input type="submit" value="Удалить"></form></span> </pre>';
	            }
		    } else { 
				echo $eng->msg("3", "Сообщений нет", "3");
			}
		}
	}
   else {
   	 echo '<br><h3><ul class="breadcrumb">Панель управления [AdminPANEL]</legend></ul></h3></br>';
		echo '<pre><table><tr><td valign="top" width="250px">';
		$sql = mysql_query("SELECT id FROM `users`") or die(mysql_error());
		echo 'Всего пользователей: '.mysql_num_rows($sql).'';
		$sql = mysql_query("SELECT * FROM `pm`") or die(mysql_error());
 		echo '<br />Всего сообщений: '.mysql_num_rows($sql).'';
		$sql = mysql_query("SELECT * FROM `messages`") or die(mysql_error());
	 	echo '<br />Сообщений в чате: '.mysql_num_rows($sql).'';
		$sql = mysql_query("SELECT * FROM `news`") or die(mysql_error());
 		echo '<br />Всего новостей: '.mysql_num_rows($sql).'';
		$sql = mysql_query("SELECT * FROM `add_bans` WHERE `type` != 0") or die(mysql_error());
	 	echo '<br />Рассмотрено банов: '.mysql_num_rows($sql).'';
		$sql = mysql_query("SELECT * FROM `news_com`") or die(mysql_error());
	 	echo '<br />Оставлено комментариев: '.mysql_num_rows($sql).'';
 	    echo '</center>';
		echo '</td><td valign="top">';
		echo '<ul class="unstyled"><li><a href="http://'.$_SERVER['SERVER_NAME'].'/ap?act=users">Управление пользователями</a></li><li><a href="http://'.$_SERVER['SERVER_NAME'].'/ap?act=chat">Управление чатом</a></li><li><a href="http://'.$_SERVER['SERVER_NAME'].'/ap?act=news">Управление новостями</a></li><li><a href="http://'.$_SERVER['SERVER_NAME'].'/gounban_ap">Управление банами</a></li><li><a href="http://'.$_SERVER['SERVER_NAME'].'/ap?act=servers">Управление серверами</a></li><li><a href="check">Присваивание профиля</a></li></ul>';
		echo '</td></tr></table></pre>';
	}
} else {
	echo $eng->msg("2", "У вас нет прав доступа", "2"); 
}
require_once TPL."footer.php";